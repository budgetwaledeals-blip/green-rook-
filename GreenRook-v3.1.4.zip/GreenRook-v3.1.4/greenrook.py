#!/usr/bin/env python3
"""GREEN ROOK - desktop antivirus.   Run:  python greenrook.py"""
import os
import queue
import shutil
import socket
import subprocess
import sys
import threading
import time
import traceback
import tkinter as tk
import tkinter.font as tkfont
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gr_health
import gr_icons
import gr_report
import gr_selftest
import gr_shield
import gr_trust
import gr_tor
import gr_ultra
from gr_core import (INSTALL_DIR, APP_NAME, VERSION, AESGCM, IS_MAC, IS_WIN, MALICIOUS, SUSPICIOUS, Broker,
                     CameraGuard, Config, Engine, EventBus, FileGuard, PackError, Vault, WebGuard, data_dir, iter_files,
                     psutil, safe_delete, system_protected)
from gr_launch import DEFAULT_ADDRESS, bind_instance_socket, send_instance_request, serve_instance_requests
from gr_guards import (MODES, RULES, NetworkGuard, PersistenceGuard, ProcessGuard, RansomwareShield, TamperGuard,
                       USBGuard, check_pin, ensure_watchdog, hash_pin, main_running, removable_mounts, rule_mode, run_watchdog,
                       verify_manifest)
from gr_ui import (ACCENT, BAD, BG, CARD, CARD2, FAINT, FG, FONT, GOOD, INFO, LINE, MONO, MUTED, SIDE, WARN, Btn, Hero,
                   BAD_BG, GOOD_BG, WARN_BG, SELECTED, PromptDialog, ScanRook, ScrollFrame, Seg, Switch, Toast, blend, card, draw_icon, icon_badge, label, status_badge)

# What each live protection is called, in plain words. (key, name, what it does, icon, how often it looks)
SHIELDS = [
    ("realtime", "File watcher", "Checks every new or changed file in Downloads, Desktop and Temp as soon as it appears.", "eye", "every 2.5 s"),
    ("process_guard", "Program blocker", "Checks each program the moment it starts and pauses the dangerous ones.", "bolt", "every 0.6 s"),
    ("ransomware_guard", "Ransomware shield", "Spots files being locked or mass-changed and stops the program doing it.", "lock", "every 1.5 s"),
    ("persistence_guard", "Start-up watcher", "Warns when something adds itself to start-up or the task scheduler.", "clock", "every 4 s"),
    ("usb_guard", "USB drive scanner", "Scans any USB stick or external drive the moment you plug it in.", "usb", "every 3 s"),
    ("network_guard", "Network watcher", "Blocks hidden remote control, worm-style scanning and known bad connections.", "globe", "every 4 s"),
    ("camera_guard", "Camera alerts", "Tells you when an app turns on your webcam, so you can allow or stop it.", "camera", "every 1.5 s"),
    ("tamper_protection", "Self-protection", "Stops malware from switching Green Rook off, and restarts it if it is killed.", "shield", "every 15 s"),
]
PAGES = [("keep", "Home", "home"), ("sweep", "Scan", "scan"), ("vault", "Quarantine", "lock"), ("ultra", "Ultra Rook", "vpn"),
         ("tower", "Camera & USB", "camera"), ("rules", "Attack blocker", "block"), ("patrol", "Running programs", "list"),
         ("ramparts", "Health check", "pulse"), ("shield", "Privacy shield", "shield"), ("chronicle", "History", "clock"), ("armory", "Settings", "sliders")]
VERDICT_WORD = {MALICIOUS: "Dangerous", SUSPICIOUS: "Suspicious"}


class StateTree(ttk.Treeview):
    """Treeview with a centered, unobtrusive empty state that updates on insert/delete."""
    def __init__(self, master, empty_text=None, **kw):
        super().__init__(master, **kw)
        self.empty_label = None
        if empty_text:
            self.empty_label = tk.Label(master, text=empty_text, font=(FONT, 9), fg=FAINT, bg=CARD,
                                        padx=8, pady=4, cursor="arrow")
            self.empty_label.bind("<Button-1>", lambda e: self.focus_set())
            self._sync_empty()
            self.bind("<Configure>", lambda e: self._sync_empty())

    def _sync_empty(self):
        if self.empty_label is None:
            return
        if self.get_children(""):
            self.empty_label.place_forget()
        else:
            self.empty_label.place(relx=.47, rely=.5, anchor="center")
            self.empty_label.lift()

    def insert(self, parent, index, iid=None, **kw):
        if "tags" not in kw and len(self.get_children(parent)) % 2:
            kw["tags"] = ("stripe",)
        result = super().insert(parent, index, iid=iid, **kw)
        self._sync_empty()
        return result

    def delete(self, *items):
        if not items:
            self._sync_empty()
            return None
        result = super().delete(*items)
        self._sync_empty()
        return result


def short(p, n=70):
    return p if len(p) <= n else p[:n // 2 - 2] + "..." + p[-(n // 2 - 2):]


def open_path(p):
    try:
        if IS_WIN:
            os.startfile(p)  # noqa
        elif IS_MAC:
            subprocess.Popen(["open", p])
        else:
            subprocess.Popen(["xdg-open", p])
    except Exception:
        pass


def plural(n, word):
    return f"{n:,} {word}{'' if n == 1 else 's'}"


class App(tk.Tk):
    def __init__(self, restarted=False, instance_inbox=None):
        super().__init__()
        try:
            if IS_WIN:
                import ctypes
                ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
        self.title("Green Rook Antivirus")
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        w, h = min(1240, sw - 60), min(840, sh - 90)         # always fits the screen, even small laptops
        self.geometry(f"{w}x{h}+{max(0, (sw - w) // 2)}+{max(0, (sh - h) // 3)}")
        self.minsize(min(1100, w), min(660, h))
        self.configure(bg=BG)
        tkfont.nametofont("TkDefaultFont").configure(family=FONT, size=10)

        self.ui_q = queue.Queue()
        self.instance_inbox = instance_inbox if instance_inbox is not None else queue.Queue()
        self._interface_error_shown = False
        self.folder = data_dir()
        self.cfg = Config(self.folder / "config.json")
        self.bus = EventBus(self.folder / "events.log", self.ui_q)
        self.engine = Engine(self.cfg, self.bus)
        self.vault = Vault(self.folder, self.cfg, self.bus)
        self.broker = Broker(self.ui_q, self.cfg)
        self.web = WebGuard(self.engine.intel)
        a = (self.cfg, self.engine, self.vault, self.broker, self.bus)
        self.file_guard = FileGuard(*a, self.cfg.get("realtime"))
        self.proc_guard = ProcessGuard(*a, self.cfg.get("process_guard"))
        self.ransom_guard = RansomwareShield(*a, self.cfg.get("ransomware_guard"))
        self.persist_guard = PersistenceGuard(*a, self.cfg.get("persistence_guard"))
        self.usb_guard = USBGuard(*a, self.cfg.get("usb_guard"))
        self.net_guard = NetworkGuard(*a, self.web, self.cfg.get("network_guard"))
        self.cam_guard = CameraGuard(self.cfg, self.broker, self.bus, self.cfg.get("camera_guard"))
        self.tamper = TamperGuard(self.cfg, self.bus, True)
        self.ultra_watch = gr_ultra.UltraRookWatch(self.cfg, self.bus)
        self.tor = gr_tor.TorRunner(self.folder)
        gr_tor.recover_after_crash(self.cfg, self.tor)          # if we crashed while the PC pointed at Tor, put the old proxy back
        self.tor_watch = gr_tor.TorWatch(self.cfg, self.bus, self.tor)
        self.ultra_profiles = gr_ultra.Profiles(self.cfg, self.vault, self.folder)
        self.ultra_busy = False
        self.services = {"realtime": self.file_guard, "process_guard": self.proc_guard, "ransomware_guard": self.ransom_guard,
                         "persistence_guard": self.persist_guard, "usb_guard": self.usb_guard, "network_guard": self.net_guard,
                         "camera_guard": self.cam_guard}
        for s in (*self.services.values(), self.tamper, self.ultra_watch, self.tor_watch):
            s.start()

        self.dialog, self.prompts = None, []
        self.scan_thread, self.scan_cancel, self.scan_items, self.scan_name = None, threading.Event(), {}, ""
        self.scan_started_at, self.scan_current_count, self.scan_active = None, 0, False
        self.scan_clock_job = None
        self.silent_scan = False
        self.all_hits, self.scan_total = [], 0
        self.pages, self.nav = {}, {}
        self.switches, self.shield_status = {}, {}

        self.style_widgets()
        self.build_layout()
        self.apply_icon(save_shortcuts=False)
        self.show("keep")
        self.refresh_dashboard()
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.start_watchdog()
        self.after(100, self.pump)
        self.after(3000, self.status_tick)
        self.after(60000, self.sched_tick)
        self.bus.emit("INFO", "System", f"Green Rook {VERSION} started")
        if restarted:
            self.bus.emit("THREAT", "Tamper Guard", "Green Rook was stopped unexpectedly and restarted by its watchdog")
            self.bus.notify("bad", "Green Rook was restarted", "Something stopped it. See the History page.")
        if self.cfg.tampered:
            self.bus.emit("THREAT", "Tamper Guard", "Settings file failed its integrity check - safe defaults were restored")
            self.bus.notify("bad", "Settings were tampered with", "Safe defaults have been restored.")
        bad = verify_manifest()
        if bad:
            self.bus.emit("THREAT", "Tamper Guard", "Program files differ from the original install: " + ", ".join(bad))
            self.bus.notify("bad", "Green Rook files were modified", ", ".join(bad))
        rejected = self.engine.intel.load_all()["rejected"]
        if rejected:
            self.bus.notify("bad", "A security update was rejected", ", ".join(n for n, _ in rejected) + " was ignored (edited or not from a trusted publisher).")

    # -- app icon ---------------------------------------------------------------------------------------
    def apply_icon(self, save_shortcuts=True):
        """Show the chosen icon in the window, the taskbar and the sidebar (and, when asked, on the Desktop / Start Menu shortcuts)."""
        choice = self.cfg.get("app_icon") or "green"
        p = gr_icons.paths(choice)
        try:
            self.icon_img = tk.PhotoImage(file=str(p["png"]))
            self.iconphoto(True, self.icon_img)
            self.logo_img = tk.PhotoImage(file=str(p["logo"]))
            self.logo_label.config(image=self.logo_img)
        except tk.TclError:
            pass
        if save_shortcuts:
            gr_icons.install_for_shortcuts(choice)

    def pick_icon(self, choice):
        self.cfg.set("app_icon", choice)
        self.apply_icon()
        self.paint_icon_choices()
        self.bus.emit("INFO", "Appearance", f"App icon changed to {choice}")

    def pick_own_icon(self):
        f = filedialog.askopenfilename(title="Choose your own icon (a square PNG picture)", filetypes=[("PNG picture", "*.png")])
        if not f:
            return
        try:
            gr_icons.make_custom(f)
        except gr_icons.IconError as e:
            return self.say(str(e), kind="error")
        self.pick_icon("custom")
        self.say("Your icon is now in use. Desktop and Start Menu shortcuts may take a moment (or a restart of Explorer) to show it.")

    def paint_icon_choices(self):
        cur = self.cfg.get("app_icon") or "green"
        for name, box in self.icon_boxes.items():
            box.config(highlightbackground=ACCENT if name == cur else CARD, highlightthickness=3)

    # -- look and layout ------------------------------------------------------------------
    def style_widgets(self):
        s = ttk.Style(self)
        s.theme_use("clam")
        s.configure("Treeview", background=CARD, fieldbackground=CARD, foreground=FG, rowheight=36, borderwidth=0, font=(FONT, 10),
                    bordercolor=CARD, lightcolor=CARD, darkcolor=CARD)
        s.configure("Treeview.Heading", background=CARD2, foreground=MUTED, borderwidth=0, font=(FONT, 9, "bold"), relief="flat", padding=(10, 9))
        s.map("Treeview", background=[("selected", SELECTED)], foreground=[("selected", FG)])
        s.map("Treeview.Heading", background=[("active", SIDE)])
        s.configure("Vertical.TScrollbar", background=CARD2, troughcolor=CARD, bordercolor=CARD, lightcolor=CARD2, darkcolor=CARD2,
                    arrowcolor=MUTED, relief="flat", gripcount=0)
        s.map("Vertical.TScrollbar", background=[("active", LINE), ("pressed", LINE)])
        s.configure("Horizontal.TProgressbar", troughcolor=CARD2, background=ACCENT, bordercolor=CARD2, lightcolor=ACCENT, darkcolor=ACCENT, thickness=10)

    def build_layout(self):
        side = tk.Frame(self, bg=SIDE, width=232)
        side.pack(side="left", fill="y")
        side.pack_propagate(False)
        logo = tk.Frame(side, bg=SIDE)
        logo.pack(fill="x", padx=18, pady=(20, 14))
        self.logo_label = tk.Label(logo, bg=SIDE, bd=0)
        self.logo_label.pack(side="left")
        lt = tk.Frame(logo, bg=SIDE)
        lt.pack(side="left", padx=10)
        label(lt, "Green Rook", 14, True, FG, SIDE).pack(anchor="w")
        label(lt, "Antivirus", 9, color=MUTED, bg=SIDE).pack(anchor="w")

        groups = [
            ("PROTECT", ("keep", "sweep", "vault")),
            ("LIVE SHIELDS", ("ultra", "tower", "rules", "patrol")),
            ("PRIVACY & HEALTH", ("ramparts", "shield")),
        ]
        page_map = {key: (name, icon) for key, name, icon in PAGES}
        nav_area = tk.Frame(side, bg=SIDE)
        nav_area.pack(fill="both", expand=True, padx=(0, 4), pady=(2, 8))
        for group, keys in groups:
            label(nav_area, group, 8, True, FAINT, SIDE).pack(anchor="w", padx=19, pady=(6, 2))
            for key in keys:
                name, icon = page_map[key]
                row = tk.Frame(nav_area, bg=SIDE, cursor="hand2", takefocus=1, highlightthickness=1, highlightbackground=SIDE)
                row.pack(fill="x", padx=(8, 10), pady=0)
                bar = tk.Frame(row, bg=SIDE, width=3)
                bar.pack(side="left", fill="y", padx=(2, 0), pady=4)
                ic = tk.Canvas(row, width=20, height=20, bg=SIDE, highlightthickness=0, takefocus=0)
                ic.pack(side="left", padx=(10, 8), pady=5)
                t = label(row, name, 10, True, MUTED, SIDE)
                t.pack(side="left")
                for w in (row, bar, ic, t):
                    w.bind("<Button-1>", lambda e, k=key: self.show(k))
                row.bind("<Return>", lambda e, k=key: self.show(k))
                row.bind("<space>", lambda e, k=key: self.show(k))
                row.bind("<FocusIn>", lambda e, r=row, k=key: self._nav_focus(r, k, True))
                row.bind("<FocusOut>", lambda e, r=row, k=key: self._nav_focus(r, k, False))
                self.nav[key] = (row, bar, ic, t, icon)
                draw_icon(ic, icon, 10, 10, 16, MUTED, 2)

        label(nav_area, "MORE", 8, True, FAINT, SIDE).pack(anchor="w", padx=19, pady=(6, 2))
        for key in ("chronicle", "armory"):
            name, icon = page_map[key]
            row = tk.Frame(nav_area, bg=SIDE, cursor="hand2", takefocus=1, highlightthickness=1, highlightbackground=SIDE)
            row.pack(fill="x", padx=(8, 10), pady=0)
            bar = tk.Frame(row, bg=SIDE, width=3)
            bar.pack(side="left", fill="y", padx=(2, 0), pady=4)
            ic = tk.Canvas(row, width=20, height=20, bg=SIDE, highlightthickness=0, takefocus=0)
            ic.pack(side="left", padx=(10, 8), pady=5)
            t = label(row, name, 10, True, MUTED, SIDE)
            t.pack(side="left")
            for w in (row, bar, ic, t):
                w.bind("<Button-1>", lambda e, k=key: self.show(k))
            row.bind("<Return>", lambda e, k=key: self.show(k))
            row.bind("<space>", lambda e, k=key: self.show(k))
            row.bind("<FocusIn>", lambda e, r=row, k=key: self._nav_focus(r, k, True))
            row.bind("<FocusOut>", lambda e, r=row, k=key: self._nav_focus(r, k, False))
            self.nav[key] = (row, bar, ic, t, icon)
            draw_icon(ic, icon, 10, 10, 16, MUTED, 2)

        foot = tk.Frame(side, bg=SIDE, padx=14, pady=12)
        foot.pack(side="bottom", fill="x")
        self.badge = tk.Label(foot, text="", font=(FONT, 9, "bold"), fg=MUTED, bg=CARD2, padx=9, pady=7,
                              anchor="w", highlightthickness=1, highlightbackground=LINE)
        self.badge.pack(fill="x")
        label(foot, f"Version {VERSION}", 8, color=FAINT, bg=SIDE).pack(anchor="w", pady=(6, 0), padx=2)

        self.content = tk.Frame(self, bg=BG)
        self.content.pack(side="left", fill="both", expand=True)
        for key, fn in [("keep", self.page_keep), ("sweep", self.page_sweep), ("vault", self.page_vault), ("ultra", self.page_ultra),
                        ("tower", self.page_tower), ("rules", self.page_rules), ("patrol", self.page_patrol),
                        ("ramparts", self.page_ramparts), ("shield", self.page_shield), ("chronicle", self.page_chronicle), ("armory", self.page_armory)]:
            f = tk.Frame(self.content, bg=BG)
            f.place(relwidth=1, relheight=1)
            inner = tk.Frame(f, bg=BG, padx=28, pady=20)
            inner.pack(fill="both", expand=True)
            self.pages[key] = f
            fn(inner)

    def _nav_focus(self, row, key, focused):
        active = getattr(self, "active_page", "keep") == key
        bg = CARD2 if focused and not active else (CARD if active else SIDE)
        row.config(bg=bg, highlightbackground=ACCENT if focused else (LINE if active else SIDE))
        for w in row.winfo_children():
            try:
                w.config(bg=bg)
            except tk.TclError:
                pass
        if len(row.winfo_children()) >= 3:
            row.winfo_children()[-1].config(fg=FG if active or focused else MUTED)
            ic = row.winfo_children()[-2]
            ic.delete("all")
            draw_icon(ic, self.nav[key][4], 10, 10, 16, ACCENT if active else (FG if focused else MUTED), 2)
        if len(row.winfo_children()) >= 1:
            row.winfo_children()[0].config(bg=ACCENT if active else bg)

    def show(self, key):
        self.active_page = key
        self.pages[key].tkraise()
        for k, (row, bar, ic, t, icon) in self.nav.items():
            on = k == key
            bg = CARD if on else SIDE
            row.config(bg=bg, highlightbackground=LINE if on else SIDE)
            bar.config(bg=ACCENT if on else bg)
            ic.config(bg=bg)
            t.config(bg=bg, fg=FG if on else MUTED)
            ic.delete("all")
            draw_icon(ic, icon, 10, 10, 16, ACCENT if on else MUTED, 2)
        {"vault": self.refresh_vault, "patrol": self.refresh_procs, "tower": self.refresh_tower,
         "chronicle": self.refresh_chronicle, "armory": self.refresh_armory, "keep": self.refresh_dashboard, "ultra": self.refresh_ultra}.get(key, lambda: None)()

    def header(self, f, title, sub, icon=None):
        row = tk.Frame(f, bg=BG)
        row.pack(fill="x", pady=(0, 16))
        if icon:
            icon_badge(row, icon, ACCENT, 36, BG).pack(side="left", padx=(0, 11))
        t = tk.Frame(row, bg=BG)
        t.pack(side="left", fill="x", expand=True)
        label(t, title, 21, True).pack(anchor="w")
        label(t, sub, 10, color=MUTED, wraplength=780, justify="left").pack(anchor="w", pady=(2, 0))

    def tree(self, parent, cols, widths, height=12, mode="extended", empty="Nothing to show yet."):
        wrap = tk.Frame(parent, bg=CARD, highlightthickness=1, highlightbackground=LINE)
        t = StateTree(wrap, empty_text=empty, columns=[c[0] for c in cols], show="headings", height=height, selectmode=mode)
        for (cid, text), w in zip(cols, widths):
            t.heading(cid, text=text)
            t.column(cid, width=w, anchor="w", stretch=(cid == cols[-1][0]) or len(cols) <= 2)
        sb = ttk.Scrollbar(wrap, orient="vertical", command=t.yview)
        t.configure(yscrollcommand=sb.set)
        t.pack(side="left", fill="both", expand=True, padx=1, pady=1)
        sb.pack(side="right", fill="y")
        t.tag_configure("bad", foreground=BAD, background=BAD_BG)
        t.tag_configure("warn", foreground=WARN, background=WARN_BG)
        t.tag_configure("good", foreground=GOOD, background=GOOD_BG)
        t.tag_configure("stripe", background=CARD2)
        return wrap, t

    def say(self, text, title=APP_NAME, kind="info"):
        {"info": messagebox.showinfo, "warn": messagebox.showwarning, "error": messagebox.showerror}[kind](title, text, parent=self)

    # -- permission check (tamper protection) -----------------------------------------------
    def authorize(self, what):
        if not self.cfg.get("tamper_protection"):
            return True
        pin = self.cfg.get("pin")
        if pin:
            ans = simpledialog.askstring("Green Rook PIN", f"Type your Green Rook PIN to {what}:", show="*", parent=self)
            if ans is None:
                return False
            if not check_pin(pin, ans):
                self.bus.emit("WARN", "Tamper Guard", f"Wrong PIN while trying to {what}")
                self.say("That PIN is not correct.", kind="error")
                return False
            return True
        return messagebox.askyesno("Please confirm", f"Malware often tries to {what}.\n\nIs it really you doing this?", icon="warning", parent=self)

    # -- Home ---------------------------------------------------------------------------------
    def page_keep(self, f):
        sf = ScrollFrame(f)
        sf.pack(fill="both", expand=True)
        p = sf.inner
        self.home = p

        banner = card(p, padx=22, pady=18)
        banner.pack(fill="x", padx=(0, 10))
        self.hero = Hero(banner, CARD, 0.70)
        self.hero.pack(side="left", padx=(0, 20))
        mid = tk.Frame(banner, bg=CARD)
        mid.pack(side="left", fill="both", expand=True)
        self.status_chip = status_badge(mid, "PROTECTED", "good", CARD)
        self.status_chip.pack(anchor="w", pady=(2, 8))
        self.status_title = label(mid, "You are protected", 24, True)
        self.status_title.pack(anchor="w")
        self.status_sub = label(mid, "", 10, color=MUTED, wraplength=560, justify="left")
        self.status_sub.pack(anchor="w", pady=(5, 15))
        r = tk.Frame(mid, bg=CARD)
        r.pack(anchor="w")
        Btn(r, "Scan my computer", lambda: self.run_preset("quick"), "primary", icon="scan", big=True).pack(side="left", padx=(0, 9))
        Btn(r, "Full scan", lambda: self.run_preset("full"), "neutral", icon="shield", big=True).pack(side="left")
        label(mid, "Quick scan checks common personal folders and start-up locations.", 9,
              color=FAINT, wraplength=560, justify="left").pack(anchor="w", pady=(10, 0))

        # Kept as a separate, clearly actionable warning row when scan results need review.
        self.threat_card = tk.Frame(p, bg=CARD, padx=18, pady=14, highlightthickness=1, highlightbackground=BAD)
        icon_badge(self.threat_card, "warn", BAD, 42, CARD).pack(side="left", padx=(0, 12))
        tb = tk.Frame(self.threat_card, bg=CARD)
        tb.pack(side="right")
        Btn(tb, "Clean all", self.clean_all, "primary", icon="shield", size="small").pack(side="left", padx=3)
        Btn(tb, "Review", lambda: self.show("sweep"), "neutral", size="small").pack(side="left", padx=3)
        Btn(tb, "Delete all", lambda: self.delete_selected(True), "danger", icon="trash", size="small").pack(side="left", padx=3)
        tt = tk.Frame(self.threat_card, bg=CARD)
        tt.pack(side="left", fill="x", expand=True)
        self.threat_title = label(tt, "", 14, True, BAD)
        self.threat_title.pack(anchor="w")
        label(tt, "Clean keeps a recoverable copy. Delete cannot be undone.", 9, color=MUTED,
              wraplength=330, justify="left").pack(anchor="w", pady=(2, 0))

        self.tiles_row = tk.Frame(p, bg=BG)
        self.tiles_row.pack(fill="x", pady=(14, 0), padx=(0, 10))
        self.tile = {}
        for i, (k, title, caption) in enumerate([
                ("files", "Files checked", "All-time + this session"),
                ("threats", "Threats found", "Across completed scans"),
                ("quar", "In quarantine", "Available to restore"),
                ("last", "Last scan", "Most recent result")]):
            c = card(self.tiles_row, padx=15, pady=12)
            c.grid(row=0, column=i, padx=(0 if i == 0 else 8, 0), sticky="nsew")
            self.tiles_row.columnconfigure(i, weight=1, uniform="home-stat")
            accent = tk.Frame(c, bg=ACCENT, width=3)
            accent.pack(side="left", fill="y", padx=(0, 11))
            txt = tk.Frame(c, bg=CARD)
            txt.pack(side="left", fill="x", expand=True)
            self.tile[k] = label(txt, "0", 17, True)
            self.tile[k].pack(anchor="w")
            label(txt, title, 9, True, FG).pack(anchor="w")
            label(txt, caption, 8, color=FAINT).pack(anchor="w", pady=(2, 0))

        heading = tk.Frame(p, bg=BG)
        heading.pack(fill="x", pady=(21, 7), padx=(0, 10))
        label(heading, "Live protection", 14, True).pack(side="left")
        label(heading, "Background safeguards", 9, color=MUTED).pack(side="right")
        grid = tk.Frame(p, bg=BG)
        grid.pack(fill="x", padx=(0, 10))
        for i, (k, title, desc, icon, every) in enumerate(SHIELDS):
            c = card(grid, padx=15, pady=12)
            c.grid(row=i // 2, column=i % 2, sticky="nsew", padx=(0 if i % 2 == 0 else 8, 0), pady=(0, 8))
            grid.columnconfigure(i % 2, weight=1, uniform="shield")
            top = tk.Frame(c, bg=CARD)
            top.pack(fill="x")
            icon_badge(top, icon, ACCENT, 34, CARD).pack(side="left", padx=(0, 10))
            col = tk.Frame(top, bg=CARD)
            col.pack(side="left")
            label(col, title, 11, True).pack(anchor="w")
            self.shield_status[k] = label(col, "", 9, True, GOOD)
            self.shield_status[k].pack(anchor="w", pady=(2, 0))
            sw = Switch(top, self.cfg.get(k), lambda v, key=k, t=title: self.toggle_shield(key, v, t), CARD)
            sw.pack(side="right")
            self.switches[k] = sw
            label(c, desc, 9, color=MUTED, wraplength=350, justify="left").pack(anchor="w", pady=(9, 0))
            label(c, f"Checks {every}", 8, color=FAINT).pack(anchor="w", pady=(4, 0))

        recent = card(p, padx=15, pady=12)
        recent.pack(fill="x", pady=(10, 4), padx=(0, 10))
        recent_head = tk.Frame(recent, bg=CARD)
        recent_head.pack(fill="x", pady=(0, 7))
        label(recent_head, "Recent activity", 12, True).pack(side="left")
        Btn(recent_head, "View history", lambda: self.show("chronicle"), "ghost", size="small").pack(side="right")
        self.home_activity_body = tk.Frame(recent, bg=CARD)
        self.home_activity_body.pack(fill="x")
        self._activity_signature = None
        self.refresh_home_activity()

    def refresh_home_activity(self):
        with self.bus.lock:
            entries = tuple(list(self.bus.history)[-5:])
        if entries == self._activity_signature:
            return
        self._activity_signature = entries
        for child in self.home_activity_body.winfo_children():
            child.destroy()
        if not entries:
            label(self.home_activity_body, "No activity recorded yet.", 9, color=FAINT).pack(anchor="w")
            return
        for ts, level, source, message in reversed(entries):
            row = tk.Frame(self.home_activity_body, bg=CARD)
            row.pack(fill="x", pady=3)
            tone = "bad" if level in ("THREAT", "ERROR") else ("warn" if level == "WARN" else "info")
            status_badge(row, level.title(), tone, CARD).pack(side="left", padx=(0, 9))
            label(row, f"{source}: {short(message, 115)}", 9, color=FG, wraplength=560,
                  justify="left").pack(side="left", fill="x", expand=True, anchor="w")
            label(row, ts[11:16], 8, color=FAINT).pack(side="right", padx=(8, 0))

    def toggle_shield(self, key, v, title=""):
        if not v and not self.authorize(f"turn off {title or key}"):
            return False
        self.cfg.set(key, v)
        svc = self.services.get(key)
        if svc:
            svc.set_enabled(v)
            if key == "ransomware_guard" and not v:
                self.ransom_guard.remove_decoys()
        if key == "tamper_protection":
            d = self.folder
            if v:
                (d / "clean_exit.flag").unlink(missing_ok=True)
                self.start_watchdog()
            else:
                (d / "clean_exit.flag").write_text("1")
        if v and key in ("process_guard", "ransomware_guard", "network_guard", "usb_guard", "persistence_guard") and not psutil:
            self.say("This protection needs the 'psutil' add-on.\nInstall it with:  pip install psutil")
        self.bus.emit("INFO", "Live protection", f"{title or key} {'switched on' if v else 'SWITCHED OFF'}")
        self.refresh_dashboard()
        return True

    def refresh_dashboard(self):
        st, sess = self.cfg.get("stats"), self.engine.session
        self.tile["files"].config(text=f"{st['files'] + sess['files']:,}")
        self.tile["threats"].config(text=f"{st['threats'] + sess['threats']:,}")
        self.tile["quar"].config(text=str(len(self.vault.index)))
        self.tile["last"].config(text=st["last_scan"] or "Never")
        names = {k: t for k, t, *_ in SHIELDS}
        off = [names[k] for k in names if not self.cfg.get(k)]
        for k, lb in self.shield_status.items():
            on = bool(self.cfg.get(k))
            lb.config(text="\u25cf Active" if on else "\u25cb Off", fg=GOOD if on else WARN)
            if self.switches[k].value != on:
                self.switches[k].set(on)
        self.hero.scanning = bool(self.scan_thread and self.scan_thread.is_alive())
        waiting = len(self.scan_items)
        if waiting:
            self.hero.set_state("bad")
            self.status_title.config(text="Threats need your attention")
            self.status_sub.config(text=f"A scan found {plural(waiting, 'problem')}. Use Clean all to make your PC safe again.")
            self.badge.config(text="\u25cf Action needed", fg=BAD, bg=blend(SIDE, BAD, .18), highlightbackground=blend(SIDE, BAD, .45))
            self.status_chip.config(text="ACTION NEEDED", fg=BAD, bg=blend(CARD, BAD, .16), highlightbackground=blend(CARD, BAD, .4))
        elif not off:
            self.hero.set_state("ok")
            self.status_title.config(text="You are protected")
            self.status_sub.config(text="All 8 live protections are on. Green Rook is watching your files, programs, start-up, drives, network and camera.")
            self.badge.config(text="\u25cf Protected", fg=GOOD, bg=blend(SIDE, GOOD, .16), highlightbackground=blend(SIDE, GOOD, .42))
            self.status_chip.config(text="PROTECTED", fg=GOOD, bg=blend(CARD, GOOD, .14), highlightbackground=blend(CARD, GOOD, .38))
        else:
            self.hero.set_state("warn" if len(off) < 4 else "bad")
            self.status_title.config(text="Protection is weakened" if len(off) < 4 else "Protection is mostly off")
            self.status_sub.config(text="Switched off: " + ", ".join(off) + ".")
            col = WARN if len(off) < 4 else BAD
            self.badge.config(text=f"\u25cf {len(off)} protection(s) off", fg=col, bg=blend(SIDE, col, .18), highlightbackground=blend(SIDE, col, .45))
            self.status_chip.config(text="ATTENTION" if len(off) < 4 else "PROTECTION OFF", fg=col,
                                    bg=blend(CARD, col, .16), highlightbackground=blend(CARD, col, .4))
        if waiting:
            self.threat_title.config(text=f"{plural(waiting, 'threat')} waiting for you")
            if not self.threat_card.winfo_ismapped():
                self.threat_card.pack(fill="x", pady=(14, 0), padx=(0, 12), after=self.home.winfo_children()[0])
        else:
            self.threat_card.pack_forget()
        self.refresh_home_activity()

    def status_tick(self):
        try:
            self.refresh_dashboard()
        finally:
            self.after(3000, self.status_tick)

    # -- Scan --------------------------------------------------------------------------------------
    def page_sweep(self, f):
        self.header(f, "Scan", "Choose what to check, then review any findings.", "scan")
        actions = tk.Frame(f, bg=BG)
        actions.pack(side="bottom", fill="x", pady=(8, 0))
        row = tk.Frame(actions, bg=BG)
        row.pack(fill="x")
        Btn(row, "Clean selected", self.quarantine_selected, "primary", icon="shield", size="small").pack(side="left", padx=(0, 6))
        Btn(row, "Clean all", self.clean_all, "neutral", size="small").pack(side="left", padx=(0, 6))
        Btn(row, "Delete selected", self.delete_selected, "danger", icon="trash", size="small").pack(side="left", padx=(0, 6))
        Btn(row, "This file is safe", self.trust_selected, "ghost", icon="check", size="small").pack(side="left", padx=(0, 6))
        Btn(row, "Save report...", self.save_report, "ghost", size="small").pack(side="right")
        label(actions, "Clean keeps a recoverable copy. Delete permanently removes the selected file.", 8,
              color=FAINT).pack(anchor="w", pady=(5, 0))

        sf = ScrollFrame(f)
        sf.pack(fill="both", expand=True)
        p = sf.inner
        choices = tk.Frame(p, bg=BG)
        choices.pack(fill="x", pady=(0, 10))
        cards = [
            ("Quick scan", "Checks common personal folders and start-up locations.", "Start quick scan", lambda: self.run_preset("quick"), "scan"),
            ("Full scan", "Checks every accessible location Green Rook includes in a full scan.", "Start full scan", lambda: self.run_preset("full"), "shield"),
        ]
        for i, (title, desc, action, fn, icon) in enumerate(cards):
            c = card(choices, padx=13, pady=10)
            c.grid(row=0, column=i, sticky="nsew", padx=(0, 8))
            choices.columnconfigure(i, weight=1, uniform="scan-choice")
            top = tk.Frame(c, bg=CARD)
            top.pack(fill="x")
            icon_badge(top, icon, ACCENT, 28, CARD).pack(side="left", padx=(0, 8))
            label(top, title, 11, True).pack(side="left", anchor="w")
            label(c, desc, 9, color=MUTED, wraplength=230, justify="left").pack(anchor="w", pady=(6, 7))
            Btn(c, action, fn, "primary" if i == 0 else "neutral", size="small").pack(anchor="w")

        c = card(choices, padx=13, pady=10)
        c.grid(row=0, column=2, sticky="nsew")
        choices.columnconfigure(2, weight=1, uniform="scan-choice")
        top = tk.Frame(c, bg=CARD)
        top.pack(fill="x")
        icon_badge(top, "folder", ACCENT, 28, CARD).pack(side="left", padx=(0, 8))
        label(top, "Choose a location", 11, True).pack(side="left", anchor="w")
        label(c, "Scan one file or folder without starting a full scan.", 9, color=MUTED, wraplength=230,
              justify="left").pack(anchor="w", pady=(6, 7))
        pick = tk.Frame(c, bg=CARD)
        pick.pack(anchor="w")
        Btn(pick, "Choose file", self.scan_file_dialog, "ghost", size="small").pack(side="left", padx=(0, 6))
        Btn(pick, "Choose folder", self.scan_folder_dialog, "ghost", size="small").pack(side="left")

        pc = card(p, padx=16, pady=11)
        pc.pack(fill="x", pady=(0, 10))
        self.cancel_btn = Btn(pc, "Stop scan", lambda: self.scan_cancel.set(), "warn", size="small")
        self.cancel_btn.pack(side="top", anchor="e")
        body = tk.Frame(pc, bg=CARD)
        body.pack(fill="x", pady=(0, 2))
        self.scan_rook = ScanRook(body, size=148, bg=CARD)
        self.scan_rook.pack(side="left", padx=(2, 13))
        info = tk.Frame(body, bg=CARD)
        info.pack(side="left", fill="both", expand=True)
        state_row = tk.Frame(info, bg=CARD)
        state_row.pack(fill="x")
        self.scan_state_badge = status_badge(state_row, "READY", "info", CARD)
        self.scan_state_badge.pack(side="left", padx=(0, 9))
        self.scan_status = label(state_row, "Ready to scan", 14, True)
        self.scan_status.pack(side="left", anchor="w")
        self.scan_file_lbl = tk.Label(info, text="Choose a scan above to begin.", font=(MONO, 9), fg=MUTED, bg=CARD,
                                       anchor="w", justify="left", wraplength=650)
        self.scan_file_lbl.pack(fill="x", pady=(6, 7))

        step_row = tk.Frame(info, bg=CARD)
        step_row.pack(fill="x", pady=(0, 8))
        self.scan_stage_labels = []
        for i, title in enumerate(("Ready", "Scanning", "Review")):
            badge = status_badge(step_row, title, "neutral", CARD)
            badge.pack(side="left", padx=(0, 6))
            self.scan_stage_labels.append(badge)
        self._scan_stage(0)

        stats = tk.Frame(info, bg=CARD)
        stats.pack(fill="x")
        self.scan_metrics = {}
        for i, (key, title, value) in enumerate((
                ("files", "Files checked", "0"), ("threats", "Findings", "0"),
                ("rate", "Current pace", "--"), ("elapsed", "Elapsed", "00:00"))):
            cell = tk.Frame(stats, bg=CARD2, padx=9, pady=6)
            cell.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 5, 0))
            stats.columnconfigure(i, weight=1, uniform="scan-stat")
            self.scan_metrics[key] = label(cell, value, 12, True)
            self.scan_metrics[key].pack(anchor="w")
            label(cell, title, 8, color=MUTED).pack(anchor="w", pady=(2, 0))
        self.progress = ttk.Progressbar(pc, mode="indeterminate")
        self.progress.pack(fill="x", pady=(9, 0))
        label(pc, "Rook fill shows scan activity; total scan size varies.", 8, color=FAINT).pack(anchor="w", pady=(4, 0))
        self.cancel_btn.set_enabled(False)

        self.results_title = label(p, "Scan results", 13, True)
        self.results_title.pack(anchor="w", pady=(0, 6))
        self.scan_empty = label(p, "No results yet. Start a scan to review anything flagged.", 9, color=FAINT)
        self.scan_empty.pack(anchor="w", pady=(0, 6))
        wrap, self.scan_tree = self.tree(p, [("file", "File"), ("verdict", "Result"), ("score", "Risk"), ("why", "Why it was flagged")],
                                         [260, 100, 72, 360], 5, empty="")
        wrap.pack(fill="both", expand=True)
        self.scan_tree.bind("<<TreeviewSelect>>", self.explain_selected)
        self.explain_box = tk.Text(p, height=3, bg=CARD, fg=MUTED, font=(FONT, 9), relief="flat", wrap="word", padx=10, pady=8,
                                   highlightthickness=1, highlightbackground=LINE, state="disabled")
        self.explain_box.pack(fill="x", pady=(7, 0))
        self.set_explain("Select a result to see why it was flagged and how certain the finding is.")

    def _scan_stage(self, active):
        if not hasattr(self, "scan_stage_labels"):
            return
        for i, badge in enumerate(self.scan_stage_labels):
            color = GOOD if i < active else (INFO if i == active else MUTED)
            badge.config(fg=color, bg=blend(CARD, color, .16) if i <= active else CARD2,
                         highlightbackground=blend(CARD, color, .38) if i <= active else LINE)

    def _scan_clock_tick(self):
        self.scan_clock_job = None
        if not self.scan_active or not self.scan_started_at:
            return
        elapsed = max(.1, time.time() - self.scan_started_at)
        count = self.scan_current_count
        self.scan_metrics["elapsed"].config(text=f"{int(elapsed // 60):02d}:{int(elapsed % 60):02d}")
        self.scan_metrics["rate"].config(text=f"{count / elapsed:,.0f} files/s" if count else "Starting")
        self.scan_clock_job = self.after(500, self._scan_clock_tick)

    def _scan_progress_update(self, count, path):
        self.scan_current_count = count
        self.scan_metrics["files"].config(text=f"{count:,}")
        self.scan_metrics["threats"].config(text=f"{len(self.scan_items):,}")
        self.scan_file_lbl.config(text=short(path, 120))
        self.scan_rook.set_activity(count)
        if self.scan_started_at:
            elapsed = max(.1, time.time() - self.scan_started_at)
            self.scan_metrics["rate"].config(text=f"{count / elapsed:,.0f} files/s" if count else "Starting")
            self.scan_metrics["elapsed"].config(text=f"{int(elapsed // 60):02d}:{int(elapsed % 60):02d}")

    def set_explain(self, text):
        self.explain_box.config(state="normal")
        self.explain_box.delete("1.0", "end")
        self.explain_box.insert("end", text)
        self.explain_box.config(state="disabled")

    def explain_selected(self, _=None):
        sel = self.selected_hits(False)
        if sel:
            self.set_explain(sel[0][1].explain())

    def save_report(self):
        p = filedialog.asksaveasfilename(title="Save scan report", defaultextension=".html",
                                         filetypes=[("Web page", "*.html"), ("JSON", "*.json")], initialfile="greenrook-report.html")
        if not p:
            return
        try:
            gr_report.write_report(p, list(self.all_hits), f"{self.scan_name or 'Scan'} report", files_checked=self.scan_total or None)
            open_path(p)
        except OSError as e:
            self.say(str(e), kind="error")

    def targets_quick(self):
        home = Path.home()
        t = [home / "Downloads", home / "Desktop", home / "Documents"]
        if IS_WIN:
            for var, rel in (("TEMP", ""), ("APPDATA", "Microsoft/Windows/Start Menu/Programs/Startup")):
                v = os.environ.get(var)
                if v:
                    t.append(Path(v) / rel)
        else:
            t += [Path("/tmp"), home / ".config/autostart"]
        return [str(p) for p in t if p.exists()]

    def targets_full(self):
        if IS_WIN:
            import string
            return [f"{d}:\\" for d in string.ascii_uppercase if os.path.exists(f"{d}:\\")]
        return [str(p) for p in [Path.home(), Path("/opt"), Path("/usr/local"), Path("/tmp"), Path("/var/tmp")] if p.exists()]

    def run_preset(self, kind, silent=False):
        if kind == "quick":
            ok = self.start_scan(self.targets_quick(), False, "Quick scan", silent)
        else:
            if not messagebox.askyesno("Full scan", "A full scan checks every drive and can take a long time.\n\nStart it now?", parent=self):
                return False
            ok = self.start_scan(self.targets_full(), True, "Full scan")
        if ok and not silent:
            self.show("sweep")
        return ok

    def scan_file_dialog(self):
        p = filedialog.askopenfilename(title="Choose a file to scan")
        if p and self.start_scan([p], False, "File scan"):
            self.show("sweep")

    def scan_folder_dialog(self):
        p = filedialog.askdirectory(title="Choose a folder to scan")
        if p and self.start_scan([p], False, "Folder scan"):
            self.show("sweep")

    def start_scan(self, targets, risky_only, name, silent=False):
        if self.scan_thread and self.scan_thread.is_alive():
            if not silent:
                self.say("A scan is already running. Wait for it to finish, or press Stop.")
            return False
        self.scan_cancel = threading.Event()
        self.scan_tree.delete(*self.scan_tree.get_children())
        self.scan_items, self.scan_name, self.silent_scan = {}, name, silent
        self.all_hits, self.scan_total = [], 0
        self.scan_current_count = 0
        if self.scan_clock_job:
            try:
                self.after_cancel(self.scan_clock_job)
            except tk.TclError:
                pass
            self.scan_clock_job = None
        self.scan_started_at, self.scan_active = time.time(), True
        self.scan_rook.set_progress(0)
        self.scan_rook.set_scanning(True)
        self._scan_stage(1)
        self.scan_state_badge.config(text="SCANNING", fg=INFO, bg=blend(CARD, INFO, .18), highlightbackground=blend(CARD, INFO, .42))
        self.scan_metrics["files"].config(text="0")
        self.scan_metrics["threats"].config(text="0")
        self.scan_metrics["rate"].config(text="Starting")
        self.scan_metrics["elapsed"].config(text="00:00")
        self.scan_empty.config(text="Scanning. Findings will appear here.")
        if not self.scan_empty.winfo_ismapped():
            self.scan_empty.pack(anchor="w", pady=(0, 6), before=self.scan_tree.master)
        self.results_title.config(text="Scan results")
        self.scan_status.config(text=f"{name} in progress", fg=FG)
        self.scan_file_lbl.config(text="Preparing scan locations...")
        self.progress.start(12)
        self.scan_clock_job = self.after(500, self._scan_clock_tick)
        self.cancel_btn.set_enabled(True)
        self.bus.emit("INFO", "Scan", f"{name} started")
        self.scan_thread = threading.Thread(target=self.scan_worker, args=(targets, risky_only, self.scan_cancel), daemon=True)
        self.scan_thread.start()
        self.refresh_dashboard()
        return True

    def scan_worker(self, targets, risky_only, cancel):
        count = threats = 0
        t0, last_ui = time.time(), 0
        for p in iter_files(self.engine, targets, risky_only, cancel):
            if cancel.is_set():
                break
            res = self.engine.scan_file(p)
            count += 1
            if res.verdict in (SUSPICIOUS, MALICIOUS):
                threats += 1
                self.ui_q.put(("scan_hit", res))
            if time.time() - last_ui > 0.15:
                last_ui = time.time()
                self.ui_q.put(("scan_progress", count, p))
        self.ui_q.put(("scan_done", count, threats, cancel.is_set(), time.time() - t0))

    def add_scan_hit(self, res):
        self.all_hits.append(res)
        self.scan_empty.pack_forget()
        iid = self.scan_tree.insert("", "end", values=(short(res.path, 60), VERDICT_WORD.get(res.verdict, res.verdict), f"{res.score}/100",
                                                       "; ".join(res.reasons[:2])), tags=("bad" if res.verdict == MALICIOUS else "warn",))
        self.scan_items[iid] = res
        self.results_title.config(text=f"Scan results  ({plural(len(self.scan_items), 'finding')})")
        self.scan_metrics["threats"].config(text=f"{len(self.scan_items):,}")

    def selected_hits(self, all_items):
        ids = list(self.scan_items) if all_items else list(self.scan_tree.selection())
        return [(i, self.scan_items[i]) for i in ids if i in self.scan_items]

    def _resolved(self, iid, word, tag="good"):
        self.scan_tree.set(iid, "verdict", word)
        self.scan_tree.item(iid, tags=(tag,))
        self.scan_items.pop(iid, None)
        n = len(self.scan_items)
        self.results_title.config(text=f"Results  ({plural(n, 'threat')} left)" if n else "Results  (all handled)")

    def quarantine_selected(self, all_items=False):
        sel = self.selected_hits(all_items)
        if not sel:
            return self.say("Click one or more results in the list first, or use 'Clean all'.")
        done, failed = 0, []
        for iid, res in sel:
            try:
                self.vault.quarantine(res)
                self._resolved(iid, "Cleaned")
                done += 1
            except OSError as e:
                failed.append(f"{short(res.path, 60)}\n   {e}")
        if done:
            self.bus.notify("good", "Cleaned", f"{plural(done, 'file')} moved to Quarantine. You can restore them any time.")
        if failed:
            self.say("These could not be cleaned (they may be in use or protected):\n\n" + "\n\n".join(failed[:5]), kind="warn")
        self.refresh_dashboard()
        return done

    def clean_all(self):
        if not self.scan_items:
            return self.say("There is nothing waiting to be cleaned.")
        return self.quarantine_selected(True)

    def delete_selected(self, all_items=False):
        sel = self.selected_hits(all_items)
        if not sel:
            return self.say("Click one or more results in the list first.")
        if not messagebox.askyesno("Delete for good?", f"Permanently delete {plural(len(sel), 'file')}?\n\nThis cannot be undone.\n"
                                   "If you are not sure, choose Clean instead: it keeps a locked copy you can restore.",
                                   icon="warning", default="no", parent=self):
            return
        done, failed, restart_note = 0, [], ""
        for iid, res in sel:
            if system_protected(res.path) and not res.confirmed:
                failed.append(f"{short(res.path, 60)}\n   Protected operating-system file; Green Rook will not delete a guess from Windows.")
                continue
            if not res.confirmed and gr_trust.is_trusted(res.path):
                failed.append(f"{short(res.path, 60)}\n   Genuine signed software; Green Rook will not delete it based on a guess.")
                continue
            ok, msg = safe_delete(res.path)
            if ok:
                self.bus.emit("INFO", "Scan", f"You deleted {res.path}" + (" (finishes at restart)" if "restart" in msg else ""))
                self._resolved(iid, "Deleted at restart" if "restart" in msg else "Deleted")
                if "restart" in msg:
                    restart_note = msg
                done += 1
            else:
                failed.append(f"{short(res.path, 60)}\n   {msg}")
        if done:
            self.bus.notify("good", "Deleted", restart_note or f"{plural(done, 'file')} permanently deleted.")
        if failed:
            self.say("These could not be deleted:\n\n" + "\n\n".join(failed[:5]), kind="warn")
        self.refresh_dashboard()

    def trust_selected(self):
        sel = self.selected_hits(False)
        if not sel:
            return self.say("Click a result first.")
        if not self.authorize("mark files as safe"):
            return
        for iid, res in sel:
            self.cfg.append_unique("allow_hashes", res.sha256)
            self._resolved(iid, "Marked safe")
        self.refresh_dashboard()

    def scan_finished(self, count, threats, cancelled, secs):
        self.scan_total = count
        self.progress.stop()
        self.cancel_btn.set_enabled(False)
        self.scan_active = False
        if self.scan_clock_job:
            try:
                self.after_cancel(self.scan_clock_job)
            except tk.TclError:
                pass
            self.scan_clock_job = None
        self.scan_rook.set_scanning(False)
        if not cancelled:
            self.scan_rook.set_progress(1.0)
        self._scan_stage(2)
        self.scan_state_badge.config(text="STOPPED" if cancelled else ("REVIEW" if threats else "COMPLETE"),
                                     fg=WARN if cancelled else (BAD if threats else GOOD),
                                     bg=blend(CARD, WARN if cancelled else (BAD if threats else GOOD), .16),
                                     highlightbackground=blend(CARD, WARN if cancelled else (BAD if threats else GOOD), .42))
        self.scan_metrics["files"].config(text=f"{count:,}")
        self.scan_metrics["threats"].config(text=f"{len(self.scan_items):,}")
        self.scan_metrics["rate"].config(text=f"{count / max(secs, .1):,.0f} files/s" if secs else "0 files/s")
        self.scan_metrics["elapsed"].config(text=f"{int(secs // 60):02d}:{int(secs % 60):02d}")
        self.scan_file_lbl.config(text="Scan stopped." if cancelled else "Scan finished. Select a finding for details." if threats else "No flagged files in this scan.")
        if not self.all_hits:
            self.scan_empty.config(text="Scan stopped before any findings." if cancelled else "No threats found in this scan.")
            self.scan_empty.pack(anchor="w", pady=(0, 6))
        verb = "stopped" if cancelled else "finished"
        if threats:
            self.scan_status.config(text=f"{self.scan_name} {verb}: {plural(count, 'file')} checked, {plural(threats, 'threat')} found.", fg=WARN)
        else:
            self.scan_status.config(text=f"{self.scan_name} {verb}: {plural(count, 'file')} checked in {secs:.0f} s. No threats found.", fg=GOOD)
        st = self.cfg.get("stats")
        st["files"] += count
        st["threats"] += threats
        st["last_scan"] = time.strftime("%d %b %H:%M")
        self.engine.session["files"] = max(0, self.engine.session["files"] - count)
        self.engine.session["threats"] = max(0, self.engine.session["threats"] - threats)
        self.cfg.set("stats", st)
        self.bus.emit("INFO", "Scan", f"{self.scan_name} {verb}: {count} files, {threats} threats")
        if threats and not cancelled:
            if self.silent_scan and self.cfg.get("auto_quarantine"):
                for iid, res in self.selected_hits(True):
                    if res.auto_safe:                      # only hard evidence, never guesses
                        try:
                            self.vault.quarantine(res)
                            self._resolved(iid, "Cleaned")
                        except OSError:
                            pass
            if self.scan_items:
                self.bus.notify("bad", "Scan finished", f"{plural(len(self.scan_items), 'threat')} found. Open Home or Scan to clean them.")
        elif self.silent_scan and not cancelled:
            self.bus.emit("INFO", "Scan", "Scheduled scan found nothing")
        self.refresh_dashboard()

    def sched_tick(self):
        try:
            hrs = int(self.cfg.get("scan_every_hours") or 0)
            last = float(self.cfg.get("last_auto_scan") or 0)
            if hrs > 0:
                if last == 0:
                    self.cfg.set("last_auto_scan", time.time())
                elif time.time() - last >= hrs * 3600:
                    if self.run_preset("quick", silent=True) is not False:
                        self.cfg.set("last_auto_scan", time.time())
        finally:
            self.after(60000, self.sched_tick)

    # -- Quarantine -----------------------------------------------------------------------------------
    def page_vault(self, f):
        self.header(f, "Quarantine", "Dangerous files are locked away here. They are scrambled, so they cannot run or harm anything.", "lock")
        label(f, "Restore puts the file back where it came from and marks it safe. Delete erases it for good.", 9, color=FAINT).pack(side="bottom", anchor="w", pady=(8, 0))
        r = tk.Frame(f, bg=BG)
        r.pack(side="bottom", fill="x", pady=(14, 0))
        Btn(r, "Restore selected", self.q_restore, "neutral", icon="refresh").pack(side="left", padx=(0, 8))
        Btn(r, "Delete selected", self.q_delete, "danger", icon="trash").pack(side="left", padx=(0, 8))
        Btn(r, "Empty quarantine", lambda: self.q_delete(True), "danger").pack(side="left")
        self.vault_summary = label(f, "", 11, color=MUTED)
        self.vault_summary.pack(anchor="w", pady=(0, 8))
        wrap, self.q_tree = self.tree(f, [("t", "Date"), ("v", "Result"), ("o", "Where it was"), ("w", "Why")], [100, 92, 250, 315], 6, empty="Quarantine is empty.")
        wrap.pack(fill="both", expand=True)

    def refresh_vault(self):
        self.q_tree.delete(*self.q_tree.get_children())
        for qid, m in self.vault.items():
            self.q_tree.insert("", "end", iid=qid, values=(m["time"], VERDICT_WORD.get(m["verdict"], m["verdict"]), short(m["original"], 56),
                                                           "; ".join(m["reasons"][:2])), tags=("bad" if m["verdict"] == MALICIOUS else "warn",))
        n = len(self.vault.index)
        self.vault_summary.config(text=f"{plural(n, 'file')} in quarantine." if n else "Quarantine is empty. Nothing dangerous is being held.")

    def q_restore(self):
        ids = list(self.q_tree.selection())
        if not ids:
            return self.say("Click a file in the list first.")
        if self.authorize("restore a quarantined file"):
            for qid in ids:
                try:
                    self.vault.restore(qid)
                except Exception as e:
                    self.say(str(e), kind="error")
            self.refresh_vault()
            self.refresh_dashboard()

    def q_delete(self, all_items=False):
        ids = list(self.q_tree.get_children()) if all_items else list(self.q_tree.selection())
        if not ids:
            return self.say("Click a file in the list first." if not all_items else "Quarantine is already empty.")
        if messagebox.askyesno("Delete for good?", f"Permanently delete {plural(len(ids), 'quarantined file')}?\n\nThis cannot be undone.",
                               icon="warning", default="no", parent=self):
            for qid in ids:
                self.vault.delete(qid)
            self.refresh_vault()
            self.refresh_dashboard()

    # -- Ultra Rook (private connection) -----------------------------------------------------------------
    def page_ultra(self, f):
        self.header(f, "Ultra Rook", "Hide your internet address from websites. Free mode costs nothing and needs no account.", "vpn")
        sf = ScrollFrame(f)
        sf.pack(fill="both", expand=True)
        p = sf.inner

        mode_row = tk.Frame(p, bg=BG)
        mode_row.pack(fill="x", pady=(0, 10), padx=(0, 12))
        label(mode_row, "Mode:", 11, True).pack(side="left", padx=(0, 10))
        self.ur_mode_seg = Seg(mode_row, self.cfg.get("ultra_mode") or "tor", self.ur_set_mode, ["tor", "wg"])
        self.ur_mode_seg.pack(side="left")

        st = card(p, padx=26, pady=20)
        st.pack(fill="x", padx=(0, 12))
        left = tk.Frame(st, bg=CARD)
        left.pack(side="left", fill="x", expand=True)
        self.ur_title = label(left, "Ultra Rook is OFF", 20, True, WARN)
        self.ur_title.pack(anchor="w")
        self.ur_detail = label(left, "", 10, color=MUTED, wraplength=520, justify="left")
        self.ur_detail.pack(anchor="w", pady=(4, 0))
        right = tk.Frame(st, bg=CARD)
        right.pack(side="right")
        self.ur_connect_btn = Btn(right, "Connect", self.ur_connect, "primary", icon="vpn", big=True)
        self.ur_disconnect_btn = Btn(right, "Disconnect", self.ur_disconnect, "danger", big=True)
        self.ur_connect_btn.pack()

        ac = card(p)
        ac.pack(fill="x", pady=(12, 0), padx=(0, 12))
        top = tk.Frame(ac, bg=CARD)
        top.pack(fill="x")
        Btn(top, "Check my address", self.ur_check_ip, "neutral", icon="scan").pack(side="right")
        label(top, "Your public address", 12, True).pack(anchor="w")
        self.ur_ip = label(top, "Not checked yet. This is the address websites see.", 10, color=MUTED, wraplength=560, justify="left")
        self.ur_ip.pack(anchor="w", pady=(2, 0))
        label(ac, "Checking asks a free address service what address it sees (Tor's own checker in Free mode).", 9, color=FAINT).pack(anchor="w", pady=(8, 0))

        # ---------------- FREE (Tor) panel
        self.ur_free = tk.Frame(p, bg=BG)
        hw = card(self.ur_free)
        hw.pack(fill="x", pady=(12, 0), padx=(0, 12))
        label(hw, "How Free mode works", 12, True).pack(anchor="w")
        label(hw, "Tor is a free network run by volunteers around the world. Your browsing passes through three of their computers, so websites see "
                  "an address from the Tor network instead of yours. It costs nothing, needs no account and no server.", 10, color=MUTED,
              wraplength=780, justify="left").pack(anchor="w", pady=(4, 0))
        self.tor_tool_card = card(self.ur_free)
        label(self.tor_tool_card, "One free add-on is needed: the Tor engine", 12, True, WARN).pack(anchor="w")
        label(self.tor_tool_card, "Green Rook controls it for you. On Windows the button below installs it (it comes with Tor Browser, the safest way to browse).",
              10, color=MUTED, wraplength=780, justify="left").pack(anchor="w", pady=(2, 10))
        tr = tk.Frame(self.tor_tool_card, bg=CARD)
        tr.pack(anchor="w")
        if IS_WIN:
            Btn(tr, "Install Tor (free)", self.tor_install, "primary", icon="plus").pack(side="left", padx=(0, 8))
        else:
            label(tr, "Install it with:   sudo apt install tor", 10, bg=CARD).pack(side="left", padx=(0, 12))
        Btn(tr, "I already have it\u2026", self.tor_locate, "neutral").pack(side="left", padx=(0, 8))
        Btn(tr, "Tor download page", lambda: open_path("https://www.torproject.org/download/"), "ghost").pack(side="left")
        op = self.tor_opts_card = card(self.ur_free)
        op.pack(fill="x", pady=(12, 0), padx=(0, 12))
        orow = tk.Frame(op, bg=CARD)
        orow.pack(fill="x")
        Switch(orow, self.cfg.get("tor_set_proxy"), lambda v: self.cfg.set("tor_set_proxy", v), CARD).pack(side="right")
        label(orow, "Send my browsers through Tor automatically while connected", 11, True).pack(anchor="w")
        label(op, "This changes your PC's proxy setting while Free mode is on, and puts your old setting back when it stops (even after a crash). "
                  "It covers Edge, Chrome, Firefox and most browsers.", 10, color=MUTED, wraplength=780, justify="left").pack(anchor="w", pady=(4, 0))
        nf = card(self.ur_free)
        nf.pack(fill="x", pady=(12, 0), padx=(0, 12))
        label(nf, "What Free mode does, and does not do", 12, True).pack(anchor="w")
        label(nf, "\u2022 Websites see a Tor address instead of yours, and nobody on your Wi-Fi can read where you go.\n"
                  "\u2022 It is slower than normal, and a few websites block Tor.\n"
                  "\u2022 Only programs that use the PC's proxy are covered (browsers mostly): not games, torrents or system services.\n"
                  "\u2022 For the strongest privacy, browse with Tor Browser. Normal browsers can still leak your address through features like WebRTC.\n"
                  "\u2022 It is not total anonymity and it does not remove viruses.", 10, color=MUTED, wraplength=780, justify="left").pack(anchor="w", pady=(6, 0))

        # ---------------- OWN SERVER (WireGuard) panel
        self.ur_wg = tk.Frame(p, bg=BG)
        self.ur_tool_card = card(self.ur_wg)
        label(self.ur_tool_card, "One free add-on is needed: WireGuard", 12, True, WARN).pack(anchor="w")
        label(self.ur_tool_card, "WireGuard is the trusted, open-source engine that builds the encrypted tunnel. Ultra Rook controls it for you.", 10,
              color=MUTED, wraplength=760, justify="left").pack(anchor="w", pady=(2, 10))
        rr = tk.Frame(self.ur_tool_card, bg=CARD)
        rr.pack(anchor="w")
        if IS_WIN:
            Btn(rr, "Install WireGuard (free)", self.ur_install_wireguard, "primary", icon="plus").pack(side="left", padx=(0, 8))
        else:
            label(rr, "Install it with:   sudo apt install wireguard-tools", 10, bg=CARD, color=FG).pack(side="left", padx=(0, 12))
        Btn(rr, "Open the WireGuard download page", lambda: open_path("https://www.wireguard.com/install/"), "ghost").pack(side="left")

        self.ur_servers_card = sc = card(self.ur_wg)
        sc.pack(fill="x", pady=(12, 0), padx=(0, 12))
        label(sc, "Your servers", 12, True).pack(anchor="w")
        label(sc, "This advanced mode needs a server. Add the WireGuard file (.conf) from a VPN company, or make your own below (renting a small server "
                  "usually costs a few dollars a month). Free mode above needs none of this.", 10, color=MUTED, wraplength=780, justify="left").pack(anchor="w", pady=(2, 10))
        wrap, self.ur_tree = self.tree(sc, [("n", "Name"), ("s", "Server"), ("p", "Hides address"), ("d", "Private lookups")], [190, 260, 130, 140], 4, "browse", empty="No saved profiles yet.")
        wrap.pack(fill="x")
        rb = tk.Frame(sc, bg=CARD)
        rb.pack(anchor="w", pady=(10, 0))
        Btn(rb, "Add a server file\u2026", self.ur_add, "primary", icon="plus").pack(side="left", padx=(0, 8))
        Btn(rb, "Use selected", self.ur_use, "neutral", icon="check").pack(side="left", padx=(0, 8))
        Btn(rb, "Remove selected", self.ur_remove, "ghost").pack(side="left")
        mk = card(self.ur_wg)
        mk.pack(fill="x", pady=(12, 0), padx=(0, 12))
        label(mk, "Run your own server", 12, True).pack(anchor="w")
        label(mk, "Ultra Rook writes the server and client files and the exact steps for a small Linux server. With your own server, nobody else sees where you browse.",
              10, color=MUTED, wraplength=780, justify="left").pack(anchor="w", pady=(2, 10))
        Btn(mk, "Make my own server files\u2026", self.ur_make_files, "neutral").pack(anchor="w")
        nb = card(self.ur_wg)
        nb.pack(fill="x", pady=(12, 0), padx=(0, 12))
        label(nb, "What this mode does, and does not do", 12, True).pack(anchor="w")
        label(nb, "\u2022 ALL your traffic goes through the server, so websites see the server's address and your provider cannot read your traffic.\n"
                  "\u2022 The owner of the server CAN see which sites you visit. Use one you trust.\n"
                  "\u2022 Files from other people are refused if they contain commands that could run on your PC.\n"
                  "\u2022 If the tunnel drops, you are warned straight away. There is no automatic kill switch.", 10, color=MUTED,
              wraplength=780, justify="left").pack(anchor="w", pady=(6, 0))
        self.ur_ip_before = None
        self.ur_show_mode()

    def ur_mode(self):
        return self.cfg.get("ultra_mode") or "tor"

    def ur_show_mode(self):
        self.ur_free.pack_forget()
        self.ur_wg.pack_forget()
        (self.ur_free if self.ur_mode() == "tor" else self.ur_wg).pack(fill="x")

    def ur_set_mode(self, m):
        if self.ultra_busy or self.tor.running() or gr_ultra.tunnel_up():
            self.say("Disconnect first, then change the mode.")
            return False
        self.cfg.set("ultra_mode", m)
        self.ur_show_mode()
        self.refresh_ultra()

    def refresh_ultra(self):
        if self.ultra_busy:
            return
        free = self.ur_mode() == "tor"
        if free:
            have = bool(gr_tor.find_tor(self.cfg.get("tor_path")))
            if have:
                self.tor_tool_card.pack_forget()
            elif not self.tor_tool_card.winfo_ismapped():
                self.tor_tool_card.pack(fill="x", pady=(12, 0), padx=(0, 12), before=self.tor_opts_card)
            up = self.tor.running() and self.cfg.get("tor_want")
            if up:
                self.ur_title.config(text="Ultra Rook is ON  (Free mode)", fg=GOOD)
                self.ur_detail.config(text="Your browsers go through the Tor network. Websites see a Tor address, not yours."
                                      if self.cfg.get("tor_proxy_set") else "Tor is running. Point your browser at the proxy 127.0.0.1:%s to use it." % self.tor.http_port)
            else:
                self.ur_title.config(text="Ultra Rook is OFF", fg=WARN)
                self.ur_detail.config(text="Press Connect to use Free mode. Right now websites can see your real address.")
        else:
            have = bool(gr_ultra.wireguard_tool())
            if have:
                self.ur_tool_card.pack_forget()
            elif not self.ur_tool_card.winfo_ismapped():
                self.ur_tool_card.pack(fill="x", pady=(12, 0), padx=(0, 12), before=self.ur_servers_card)
            up = gr_ultra.tunnel_up()
            active = next((x for x in self.ultra_profiles.list() if x["id"] == self.cfg.get("ultra_active")), None)
            if up:
                self.ur_title.config(text="Ultra Rook is ON", fg=GOOD)
                self.ur_detail.config(text=f"Your traffic goes through {active['name'] if active else 'your server'}. Websites see the server's address.")
            else:
                self.ur_title.config(text="Ultra Rook is OFF", fg=WARN)
                self.ur_detail.config(text=(f"Ready to connect through {active['name']} ({active['endpoint']})." if active else
                                            "Add a server below to get started.") + " Right now websites can see your real address.")
            self.ur_tree.delete(*self.ur_tree.get_children())
            for x in self.ultra_profiles.list():
                mark = "  \u2713 in use" if x["id"] == self.cfg.get("ultra_active") else ""
                self.ur_tree.insert("", "end", iid=x["id"], values=(x["name"] + mark, x["endpoint"], "Yes, all traffic" if x["full"] else "Only partly",
                                                                   "Yes" if x["dns"] else "No"), tags=("good" if x["full"] and x["dns"] else "warn",))
        self.ur_connect_btn.pack_forget()
        self.ur_disconnect_btn.pack_forget()
        (self.ur_disconnect_btn if up else self.ur_connect_btn).pack()
        self.ur_mode_seg.value = self.ur_mode()
        self.ur_mode_seg.paint()

    def ur_busy_state(self, text):
        self.ultra_busy = True
        self.ur_title.config(text=text, fg=WARN)
        self.ur_connect_btn.set_enabled(False)
        self.ur_disconnect_btn.set_enabled(False)

    def ur_connect(self):
        return self.tor_connect() if self.ur_mode() == "tor" else self.wg_connect()

    def ur_disconnect(self):
        return self.tor_disconnect() if self.ur_mode() == "tor" else self.wg_disconnect()

    # ---- Free (Tor) ----
    def tor_connect(self):
        if not gr_tor.find_tor(self.cfg.get("tor_path")):
            return self.say("The free Tor engine is not installed yet. Use the 'Install Tor (free)' button on this page first.")
        self.ur_busy_state("Connecting to the Tor network\u2026  0%")
        runner = self.tor

        def work():
            try:
                runner.start()
                ok = runner.wait_ready(120, on_progress=lambda pct: self.ui_q.put(("tor_progress", pct)))
                if not ok:
                    msg = runner.explain_failure()
                    runner.stop()
                    raise gr_tor.TorError(msg)
                port = runner.http_port
                if self.cfg.get("tor_set_proxy"):
                    prev = gr_tor.set_system_proxy(port)
                    self.cfg.set("tor_prev_proxy", prev or {})
                    self.cfg.set("tor_proxy_set", True)
                is_tor, ip = gr_tor.check_through_tor(port)
                if is_tor is False:                      # connected, but the checker says the traffic is NOT leaving through Tor
                    if self.cfg.get("tor_proxy_set"):
                        gr_tor.restore_system_proxy(self.cfg.get("tor_prev_proxy") or {})
                        self.cfg.set("tor_proxy_set", False)
                    runner.stop()
                    raise gr_tor.TorError("Tor started, but the check says your traffic is not leaving through it, so Free mode was switched off to be safe.")
                self.ui_q.put(("tor_done", True, is_tor, ip, ""))
            except gr_tor.TorError as e:
                self.ui_q.put(("tor_done", False, None, None, str(e)))
            except Exception as e:
                runner.stop()
                self.ui_q.put(("tor_done", False, None, None, f"Free mode could not start: {e}"))
        threading.Thread(target=work, daemon=True).start()

    def tor_connected(self, ok_call, is_tor, ip, err):
        self.ultra_busy = False
        self.ur_connect_btn.set_enabled(True)
        self.ur_disconnect_btn.set_enabled(True)
        if ok_call:
            self.cfg.set("tor_want", True)
            if is_tor:
                self.ur_ip.config(text=f"Verified by Tor's own checker: websites now see {ip}, a Tor address.", fg=GOOD)
                self.bus.emit("INFO", "Ultra Rook", f"Free mode on; Tor checker confirms address {ip}")
            else:
                self.ur_ip.config(text="Tor is running, but the address checker could not be reached, so it could not be verified.", fg=WARN)
                self.bus.emit("WARN", "Ultra Rook", "Free mode on but unverified")
        else:
            self.cfg.set("tor_want", False)
            self.bus.emit("WARN", "Ultra Rook", "Free mode could not start: " + err.splitlines()[0])
            self.say(err, kind="error")
        self.refresh_ultra()

    def tor_disconnect(self):
        self.ur_busy_state("Switching Free mode off\u2026")

        def work():
            self.tor_shutdown()
            self.ui_q.put(("tor_off",))
        threading.Thread(target=work, daemon=True).start()

    def tor_shutdown(self):
        """Always restore the PC's proxy first, then stop Tor. Safe to call at any time."""
        try:
            if self.cfg.get("tor_proxy_set"):
                gr_tor.restore_system_proxy(self.cfg.get("tor_prev_proxy") or {})
                self.cfg.set("tor_proxy_set", False)
        except Exception as e:
            self.bus.emit("ERROR", "Ultra Rook", f"Could not restore the proxy setting: {e}")
        self.cfg.set("tor_want", False)
        self.tor.stop()

    def tor_locate(self):
        p = filedialog.askopenfilename(title="Find tor.exe (inside the Tor Browser folder) or tor", filetypes=[("Tor program", "tor*"), ("All files", "*.*")])
        if p:
            self.cfg.set("tor_path", p)
            self.refresh_ultra()

    def tor_install(self):
        if not shutil.which("winget"):
            return self.say("Automatic install needs Windows' 'winget'. Use the 'Tor download page' button, install Tor Browser, then press 'I already have it'.", kind="warn")
        self.say("Tor Browser (which contains the Tor engine) will now be installed. This takes a minute. Choose Yes if Windows asks for permission.")

        def work():
            subprocess.run(["winget", "install", "-e", "--id", "TorProject.TorBrowser", "--silent", "--accept-package-agreements",
                            "--accept-source-agreements"], capture_output=True, text=True, creationflags=0x08000000)
            self.ui_q.put(("tor_installed", bool(gr_tor.find_tor(self.cfg.get("tor_path")))))
        threading.Thread(target=work, daemon=True).start()

    # ---- Own server (WireGuard) ----
    def wg_connect(self):
        pid = self.cfg.get("ultra_active")
        if not pid:
            return self.say("Add a server first (the 'Add a server file' button).")
        if not gr_ultra.wireguard_tool():
            return self.say("WireGuard is not installed yet. Use the 'Install WireGuard' button on this page first.")
        self.ur_busy_state("Connecting\u2026  (Windows may ask for permission: choose Yes)")

        def work():
            try:
                conf = self.ultra_profiles.load(pid)
                before = gr_ultra.fetch_public_ip()
                gr_ultra.connect(conf)
                time.sleep(1.5)
                after = gr_ultra.fetch_public_ip()
                ok, sentence = gr_ultra.verify_hidden(before, after)
                self.ui_q.put(("ultra_done", True, sentence, before, after, ok))
            except gr_ultra.UltraError as e:
                self.ui_q.put(("ultra_done", False, str(e), None, None, False))
        threading.Thread(target=work, daemon=True).start()

    def wg_disconnect(self):
        self.ur_busy_state("Disconnecting\u2026")

        def work():
            try:
                gr_ultra.disconnect()
                self.ui_q.put(("ultra_off", True, "Disconnected. Websites can see your real address again."))
            except gr_ultra.UltraError as e:
                self.ui_q.put(("ultra_off", False, str(e)))
        threading.Thread(target=work, daemon=True).start()

    def ultra_connected(self, ok_call, sentence, before, after, hidden):
        self.ultra_busy = False
        self.ur_connect_btn.set_enabled(True)
        self.ur_disconnect_btn.set_enabled(True)
        if ok_call:
            self.cfg.set("ultra_want", True)
            self.ur_ip.config(text=sentence, fg=GOOD if hidden else WARN)
            self.bus.emit("INFO" if hidden else "WARN", "Ultra Rook", "Connected. " + sentence)
            if not hidden:
                self.say(sentence, kind="warn")
        else:
            self.bus.emit("WARN", "Ultra Rook", "Could not connect: " + sentence)
            self.say(sentence, kind="error")
        self.refresh_ultra()

    def ultra_disconnected(self, ok_call, msg):
        self.ultra_busy = False
        self.ur_connect_btn.set_enabled(True)
        self.ur_disconnect_btn.set_enabled(True)
        if ok_call:
            self.cfg.set("ultra_want", False)
            self.ur_ip.config(text=msg, fg=MUTED)
            self.bus.emit("INFO", "Ultra Rook", "Disconnected")
        else:
            self.say(msg, kind="error")
        self.refresh_ultra()

    def ur_check_ip(self):
        self.ur_ip.config(text="Checking\u2026", fg=WARN)
        via_tor = self.ur_mode() == "tor" and self.tor.running() and self.tor.http_port

        def work():
            if via_tor:
                is_tor, ip = gr_tor.check_through_tor(self.tor.http_port)
                self.ui_q.put(("ultra_ip", ip, "tor" if is_tor else ("unverified" if is_tor is None else "not-tor")))
            else:
                self.ui_q.put(("ultra_ip", gr_ultra.fetch_public_ip(), "direct"))
        threading.Thread(target=work, daemon=True).start()

    def ur_add(self):
        p = filedialog.askopenfilename(title="WireGuard file from your VPN company or your own server", filetypes=[("WireGuard file", "*.conf"), ("All files", "*.*")])
        if not p:
            return
        try:
            text = Path(p).read_text(encoding="utf-8", errors="strict")
            entry = self.ultra_profiles.add(Path(p).stem, text)
        except (gr_ultra.UltraError, OSError, UnicodeError) as e:
            return self.say(str(e), kind="error")
        note = ("\n\nPlease note:\n- " + "\n- ".join(entry["warnings"])) if entry["warnings"] else ""
        self.say(f"Added '{entry['name']}'. Press Connect to use it." + note, kind="warn" if entry["warnings"] else "info")
        self.refresh_ultra()

    def ur_use(self):
        sel = self.ur_tree.selection()
        if not sel:
            return self.say("Click a server in the list first.")
        if gr_ultra.tunnel_up():
            return self.say("Disconnect first, then choose a different server.")
        self.cfg.set("ultra_active", sel[0])
        self.refresh_ultra()

    def ur_remove(self):
        sel = self.ur_tree.selection()
        if not sel:
            return self.say("Click a server in the list first.")
        if gr_ultra.tunnel_up() and sel[0] == self.cfg.get("ultra_active"):
            return self.say("This server is connected. Disconnect first.")
        if messagebox.askyesno("Remove server?", "Remove this server and its saved keys from Green Rook?", parent=self):
            self.ultra_profiles.remove(sel[0])
            self.refresh_ultra()

    def ur_install_wireguard(self):
        if not shutil.which("winget"):
            return self.say("Automatic install needs Windows' 'winget'. Use the download page button instead.", kind="warn")
        self.say("WireGuard will now be installed (about a minute). Choose Yes if Windows asks for permission.")

        def work():
            r = subprocess.run(["winget", "install", "-e", "--id", "WireGuard.WireGuard", "--silent", "--accept-package-agreements",
                                "--accept-source-agreements"], capture_output=True, text=True, creationflags=0x08000000)
            self.ui_q.put(("ultra_wg", r.returncode == 0 or bool(gr_ultra.wireguard_tool())))
        threading.Thread(target=work, daemon=True).start()

    def ur_make_files(self):
        host = simpledialog.askstring("Your server", "Type your server's internet address (an IP address like 203.0.113.5, or a name like vpn.example.com):", parent=self)
        if not host:
            return
        out = filedialog.askdirectory(title="Where should the files be saved?")
        if not out:
            return
        try:
            server, client, steps = gr_ultra.make_wireguard_pair(host.strip())
            gr_ultra.parse_wg_conf(client)
        except (gr_ultra.UltraError, ImportError) as e:
            return self.say(str(e), kind="error")
        folder = Path(out) / "ultrarook-files"
        folder.mkdir(parents=True, exist_ok=True)
        for name, text in (("server-wg0.conf", server), ("client.conf", client), ("SERVER-STEPS.txt", steps)):
            fd = os.open(folder / name, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w") as fh:
                fh.write(text)
        self.say(f"Three files were saved in:\n{folder}\n\nOpen SERVER-STEPS.txt and follow it. Then come back here, press 'Add a server file' and choose client.conf.")
        open_path(str(folder))

    def refresh_block_status(self):
        self.block_status.config(text=f"{len(self.web.blocklist):,} dangerous websites are on the list. 'Block them on this whole PC' makes every "
                                      "browser and app refuse to open them (needs administrator rights).")

    def update_blocklist(self):
        self.block_status.config(text="Downloading the latest list of dangerous websites\u2026", fg=WARN)

        def work():
            try:
                added, total = self.web.update_online()
                self.ui_q.put(("web_update", f"List updated: {added:,} new, {total:,} websites in total.", GOOD))
            except Exception as e:
                self.ui_q.put(("web_update", f"Could not download the list: {e}", BAD))
        threading.Thread(target=work, daemon=True).start()

    def import_blocklist(self):
        p = filedialog.askopenfilename(title="Choose a text file with one website per line")
        if p:
            n = self.web.import_list(p)
            self.refresh_block_status()
            self.say(f"Added {n} websites to the block list.")

    def hosts_action(self, enable):
        if not enable and not self.authorize("stop blocking dangerous websites"):
            return
        try:
            n = self.web.apply_hosts(enable)
            msg = f"{n:,} dangerous websites are now blocked for every program on this PC." if enable else "Blocking across the whole PC has been turned off."
            self.bus.emit("INFO", "Web safety", msg)
            self.say(msg)
        except PermissionError:
            self.say("Your computer needs administrator rights to do this.\n\nClose Green Rook, then start it again with 'Run as administrator' "
                     "(or with sudo).", kind="warn")
        except OSError as e:
            self.say(str(e), kind="error")

    # -- Camera & USB ------------------------------------------------------------------------------------
    def page_tower(self, f):
        self.header(f, "Camera & USB", "Green Rook watches your webcam and any drive you plug in.", "camera")
        c = card(f)
        c.pack(fill="x")
        self.cam_status = label(c, "", 13, True)
        self.cam_status.pack(anchor="w")
        label(c, "When an app starts using your camera you get a message. You can allow it, or stop the app.", 10, color=MUTED).pack(anchor="w", pady=(4, 0))
        if IS_WIN:
            Btn(c, "Open Windows camera privacy settings", lambda: open_path("ms-settings:privacy-webcam"), "neutral").pack(anchor="w", pady=(12, 0))
        c2 = card(f)
        c2.pack(fill="x", pady=14)
        self.usb_status = label(c2, "", 10, justify="left", wraplength=820)
        self.usb_status.pack(anchor="w")
        r = tk.Frame(f, bg=BG)
        r.pack(side="bottom", fill="x", pady=(12, 0))
        Btn(r, "Remove selected app", self.remove_cam, "neutral").pack(side="left")
        label(f, "Camera apps you allowed", 14, True).pack(anchor="w", pady=(6, 8))
        wrap, self.cam_tree = self.tree(f, [("a", "App")], [700], 5, empty="No apps are on the allowed list yet.")
        wrap.pack(fill="both", expand=True)

    def refresh_tower(self):
        if not self.cam_guard.supported:
            self.cam_status.config(text="Camera alerts are not available on this operating system", fg=WARN)
        else:
            on = self.cfg.get("camera_guard")
            self.cam_status.config(text="Camera alerts are " + ("ON" if on else "OFF"), fg=GOOD if on else WARN)
        mounts = removable_mounts()
        self.usb_status.config(text=("USB drive scanner is " + ("ON" if self.cfg.get("usb_guard") else "OFF") + ".   Drives connected now: " +
                                     (", ".join(mounts) if mounts else "none") +
                                     "\nNew drives are scanned automatically, and programs that start from a drive are paused."))
        self.cam_tree.delete(*self.cam_tree.get_children())
        for a in self.cfg.get("camera_allowed") or []:
            self.cam_tree.insert("", "end", values=(a,))

    def remove_cam(self):
        lst = self.cfg.get("camera_allowed") or []
        for i in self.cam_tree.selection():
            v = self.cam_tree.item(i, "values")[0]
            if v in lst:
                lst.remove(v)
        self.cfg.set("camera_allowed", lst)
        self.refresh_tower()

    # -- Attack blocker -------------------------------------------------------------------------------------
    def page_rules(self, f):
        self.header(f, "Attack blocker", "Rules that stop the tricks attackers use. Pick what Green Rook does when a rule is triggered.", "block")
        legend = tk.Frame(f, bg=BG)
        legend.pack(fill="x", pady=(0, 10))
        for m, txt in (("block", "stop it quietly"), ("ask", "pause it and ask you"), ("audit", "just write it in History"), ("off", "ignore it")):
            label(legend, Seg.NAME[m], 9, True, Seg.COL[m]).pack(side="left")
            label(legend, f" = {txt}      ", 9, color=MUTED).pack(side="left")
        sf = ScrollFrame(f)
        sf.pack(fill="both", expand=True)
        for rid, title, desc, _ in RULES:
            row = tk.Frame(sf.inner, bg=CARD, padx=18, pady=12, highlightthickness=1, highlightbackground=LINE)
            row.pack(fill="x", pady=(0, 8), padx=(0, 10))
            left = tk.Frame(row, bg=CARD)
            left.pack(side="left", fill="x", expand=True)
            label(left, title, 12, True).pack(anchor="w")
            label(left, desc, 10, color=MUTED, wraplength=560, justify="left").pack(anchor="w", pady=(3, 0))
            Seg(row, rule_mode(self.cfg, rid), lambda m, r=rid: self.set_rule(r, m), MODES).pack(side="right")

    def set_rule(self, rid, mode):
        cur = rule_mode(self.cfg, rid)
        if MODES.index(mode) > MODES.index(cur) and mode in ("audit", "off") and not self.authorize(f"weaken rule {rid}"):
            return False
        modes = self.cfg.get("rule_modes") or {}
        modes[rid] = mode
        self.cfg.set("rule_modes", modes)
        self.bus.emit("INFO", "Attack blocker", f"{rid} set to {mode.upper()}")

    # -- Health check ----------------------------------------------------------------------------------------
    def page_ramparts(self, f):
        self.header(f, "Health check", "Look at your PC's security settings, or test that Green Rook itself works. Nothing is changed.", "pulse")
        r = tk.Frame(f, bg=BG)
        r.pack(fill="x")
        self.health_btn = Btn(r, "Check my PC's settings", self.run_health, icon="pulse")
        self.health_btn.pack(side="left", padx=(0, 10))
        self.selftest_btn = Btn(r, "Test Green Rook", self.run_selftest, "neutral", icon="check")
        self.selftest_btn.pack(side="left")
        self.health_pending = False
        self.selftest_running = False
        self.selftest_box = tk.Text(f, height=7, bg=CARD, fg=FG, font=(MONO, 9), relief="flat", wrap="word", padx=14, pady=10,
                                    highlightthickness=1, highlightbackground=LINE, state="disabled")
        self.selftest_box.pack(side="bottom", fill="x")
        self.health_note = label(f, "", 10, color=MUTED, wraplength=900, justify="left")
        self.health_note.pack(side="bottom", anchor="w", pady=(8, 8))
        self.health_sum = label(f, "Press a button to start.", 11, color=MUTED)
        self.health_sum.pack(anchor="w", pady=(14, 8))
        wrap, self.health_tree = self.tree(f, [("s", "Status"), ("t", "Setting"), ("d", "What we found")], [82, 190, 420], 5, "browse", empty="Run a check to see the results.")
        wrap.pack(fill="both", expand=True)
        self.health_tree.bind("<<TreeviewSelect>>", self.health_lesson)
        self.health_rows = {}

    def run_health(self):
        self.health_sum.config(text="Checking\u2026", fg=WARN)
        threading.Thread(target=lambda: self.ui_q.put(("health", gr_health.run_checks(self.cfg))), daemon=True).start()

    def show_health(self, rows):
        self.health_pending = False
        self.health_btn.set_loading(False)
        self.health_tree.delete(*self.health_tree.get_children())
        self.health_rows = {}
        tag = {"good": "good", "warn": "warn", "bad": "bad", "info": ""}
        word = {"good": "Good", "warn": "Warning", "bad": "Fix this", "info": "Info"}
        for row in rows:
            iid = self.health_tree.insert("", "end", values=(word[row["status"]], row["title"], row["detail"]), tags=(tag[row["status"]],))
            self.health_rows[iid] = row
        s = gr_health.summarize(rows)
        self.health_sum.config(text=f"{s['good']} good, {s['warn']} warnings, {s['bad']} to fix.  Click a row to see why it matters.",
                               fg=BAD if s["bad"] else WARN if s["warn"] else GOOD)

    def health_lesson(self, _=None):
        sel = self.health_tree.selection()
        row = self.health_rows.get(sel[0]) if sel else None
        self.health_note.config(text=("Why it matters: " + row["lesson"]) if row and row["lesson"] else "")

    def run_selftest(self):
        if self.selftest_running:
            return
        self.selftest_running = True
        self.selftest_btn.set_loading(True, "Testing...")
        self.selftest_box.config(state="normal")
        self.selftest_box.delete("1.0", "end")
        self.selftest_box.insert("end", "Testing Green Rook with harmless files in a private temporary folder. Your own files and settings are not touched\u2026\n")
        self.selftest_box.config(state="disabled")

        def work():
            try:
                result = gr_selftest.format_results(gr_selftest.run_selftest())
                self.ui_q.put(("selftest", result))
            except Exception as e:
                self.ui_q.put(("selftest", f"The self-test could not run: {e}"))
        threading.Thread(target=work, daemon=True).start()

    # -- Privacy Shield: seven privacy / attack-surface checks -----------------------------
    def page_shield(self, f):
        self.header(f, "Privacy shield", "Check browser passwords and cookies, camera, remote access, documents, DNS and firewall. Checks are free and read-only.", "shield")
        top = tk.Frame(f, bg=BG)
        top.pack(fill="x", pady=(0, 12))
        self.shield_run_btn = Btn(top, "Run security check", self.run_shield, "primary", icon="refresh")
        self.shield_run_btn.pack(side="left", padx=(0, 10))
        self.shield_summary = label(top, "Run a check to review these settings.", 10, color=MUTED)
        self.shield_summary.pack(side="left", fill="x", expand=True)
        label(f, "Green Rook never reads saved password contents or uploads your private files. Review each suggested change before applying it.",
              9, color=FAINT, wraplength=780, justify="left").pack(anchor="w", pady=(0, 10))
        body = tk.Frame(f, bg=BG)
        body.pack(fill="both", expand=True)
        wrap, self.shield_tree = self.tree(body, [("status", "Status"), ("topic", "Protection area")], [90, 260], 8, "browse", empty="Run the privacy checks to load results.")
        wrap.pack(side="left", fill="y", padx=(0, 12))
        self.shield_tree.tag_configure("bad", foreground=BAD)
        self.shield_tree.tag_configure("warn", foreground=WARN)
        self.shield_tree.tag_configure("good", foreground=GOOD)
        self.shield_tree.bind("<<TreeviewSelect>>", self.shield_selected)
        right = tk.Frame(body, bg=BG)
        right.pack(side="left", fill="both", expand=True)
        detailbox = tk.Frame(right, bg=BG)
        detailbox.pack(fill="x", pady=(0, 10))
        self.shield_detail = tk.Text(detailbox, height=12, wrap="word", bg=CARD, fg=FG, font=(FONT, 10), relief="flat",
                                     padx=12, pady=10, highlightthickness=1, highlightbackground=LINE, state="disabled")
        detail_scroll = ttk.Scrollbar(detailbox, orient="vertical", command=self.shield_detail.yview)
        self.shield_detail.configure(yscrollcommand=detail_scroll.set)
        self.shield_detail.pack(side="left", fill="both", expand=True)
        detail_scroll.pack(side="right", fill="y")
        self.shield_doc_list = tk.Listbox(right, height=5, selectmode="extended", bg=CARD, fg=FG, selectbackground=ACCENT,
                                          relief="flat", highlightthickness=1, highlightbackground=LINE, font=(FONT, 9), activestyle="dotbox")
        self.shield_doc_list.pack(fill="x", pady=(0, 8))
        self.shield_doc_list.pack_forget()
        self.shield_actions = tk.Frame(right, bg=BG)
        self.shield_actions.pack(fill="x", anchor="w")
        self.shield_note = label(right, "", 9, color=MUTED, wraplength=560, justify="left", anchor="nw")
        self.shield_note.pack(fill="x", pady=(10, 0), anchor="nw")
        self.shield_rows = {}
        self.shield_running = False
        self.shield_pending = False

    def run_shield(self):
        if self.shield_pending or self.shield_running:
            return
        self.shield_running = True
        self.shield_run_btn.set_loading(True, "Checking...")
        self.shield_summary.config(text="Checking security settings. Nothing will be changed...", fg=WARN)
        def work():
            try:
                self.ui_q.put(("shield_result", gr_shield.run_checks(self.cfg, self.cam_guard)))
            except Exception as e:
                self.ui_q.put(("shield_error", str(e)))
        threading.Thread(target=work, daemon=True).start()

    def show_shield(self, rows):
        self.shield_running = False
        self.shield_run_btn.set_loading(False)
        self.shield_rows = {r["id"]: r for r in rows}
        self.shield_tree.delete(*self.shield_tree.get_children())
        self.shield_iids = {}
        words = {"good": "Good", "warn": "Review", "bad": "Risk", "info": "Info"}
        for r in rows:
            iid = self.shield_tree.insert("", "end", values=(words[r["status"]], r["title"]), tags=(r["status"],))
            self.shield_iids[iid] = r["id"]
        count = gr_shield.summarize(rows)
        self.shield_summary.config(text=f"{count['good']} good · {count['warn']} to review · {count['bad']} risks · {count['info']} info",
                                   fg=BAD if count['bad'] else WARN if count['warn'] else GOOD)
        if rows:
            first = self.shield_tree.get_children()[0]
            self.shield_tree.selection_set(first)
            self.shield_selected()

    def shield_selected(self, _=None):
        if self.shield_pending:
            return
        sel = self.shield_tree.selection()
        if not sel:
            return
        r = self.shield_rows.get(self.shield_iids.get(sel[0]))
        if not r:
            return
        text = f"{r['title']}  ·  {r['status'].upper()}\n\n{r['detail']}"
        if r.get("why"):
            text += "\n\nWhy it matters: " + r["why"]
        if r.get("steps"):
            text += "\n\nWhat you can do\n" + "\n".join("• " + x for x in r["steps"])
        self.shield_detail.config(state="normal")
        self.shield_detail.delete("1.0", "end")
        self.shield_detail.insert("1.0", text)
        self.shield_detail.config(state="disabled")
        self.shield_doc_list.delete(0, "end")
        if r["id"] == "documents" and r.get("data"):
            for path, why in r["data"]:
                self.shield_doc_list.insert("end", f"{Path(path).name}   --   {why}")
            self.shield_doc_list.pack(fill="x", pady=(0, 8))
        else:
            self.shield_doc_list.pack_forget()
        for w in self.shield_actions.winfo_children():
            w.destroy()
        shown_fixes = set()
        for fix_id, text in r.get("fixes", []):
            shown_fixes.add(fix_id)
            Btn(self.shield_actions, text, lambda i=fix_id, r=r: self.shield_fix(i, r), "neutral").pack(anchor="w", pady=3)
        for fix_id, text in gr_shield.undo_list(self.cfg):
            relevant = (fix_id == "rdp_undo" and r["id"] == "rdp") or (fix_id == "dns_undo" and r["id"] == "dns") or (fix_id in ("fw_stealth_off", "fw_undo") and r["id"] == "firewall")
            if relevant and fix_id not in shown_fixes:
                Btn(self.shield_actions, text, lambda i=fix_id, r=r: self.shield_fix(i, r), "neutral").pack(anchor="w", pady=3)
        if r["id"] == "documents" and r.get("data"):
            Btn(self.shield_actions, "Lock selected files with a password", self.shield_lock_selected, "neutral").pack(anchor="w", pady=(8, 3))
        if r["id"] == "documents":
            Btn(self.shield_actions, "Unlock a file...", self.shield_unlock, "neutral").pack(anchor="w", pady=3)
        self.shield_note.config(text="")

    def shield_fix(self, fix_id, row):
        impacts = {"clear_cookies": "This signs you out of websites. Saved passwords and bookmarks are not deleted.",
                   "cam_block": "Apps in your Windows account will be blocked from the camera until you allow them again.",
                   "mic_block": "Apps in your Windows account will be blocked from the microphone until you allow them again.",
                   "cam_unblock": "Apps in your Windows account may use the camera again.", "mic_unblock": "Apps in your Windows account may use the microphone again.",
                   "rdp_off": "Remote Desktop and Remote Assistance will be disabled. You can restore their previous settings here.",
                   "rdp_undo": "The remote access settings Green Rook saved will be restored.",
                   "fw_on": "Windows Firewall will be turned on for all profiles without changing existing app rules; the previous state can be restored here.",
                   "fw_stealth": "Blocks selected connection probes only when your network is marked Public; private-network sharing is unaffected.",
                   "fw_stealth_off": "Green Rook's optional public-network firewall rules will be removed.",
                   "fw_undo": "The firewall on/off state for each profile will be restored as Green Rook recorded it.",
                   "fw_undo": "The firewall on/off state for each profile will be restored as Green Rook recorded it.",
                   "dns_secure": "This changes this PC's DNS resolver to Quad9 (9.9.9.9 and 149.112.112.112). It can be restored here.",
                   "dns_undo": "Green Rook will restore the DNS servers it found before the change.",
                   "hosts_clean": "Suspicious website redirects will be removed from the hosts file. A backup will be kept.",
                   "cam_guard_on": "Green Rook will resume camera-use alerts."}
        if not messagebox.askyesno("Apply this change?", impacts.get(fix_id, "Apply this change?"), icon="warning", default="no", parent=self):
            return
        self.shield_note.config(text="Applying the change. Windows may ask for permission...", fg=WARN)
        self.shield_pending = True
        def work():
            result = gr_shield.apply_fix(fix_id, self.cfg, self.cam_guard)
            self.ui_q.put(("shield_action", result[0], result[1]))
        threading.Thread(target=work, daemon=True).start()

    def shield_lock_selected(self):
        if self.shield_pending:
            return
        row = self.shield_rows.get("documents")
        if not row or not row.get("data"):
            return
        ids = list(self.shield_doc_list.curselection())
        if not ids:
            self.say("Select one or more files in the list first.", kind="warn")
            return
        chosen = [row["data"][i][0] for i in ids]
        if not messagebox.askyesno("Lock these files?", "The selected readable files will be encrypted and then removed. You must remember the password to unlock them. Continue?",
                                   icon="warning", default="no", parent=self):
            return
        pw = simpledialog.askstring("Choose a password", "Use at least 8 characters. Green Rook cannot recover a forgotten password:", show="*", parent=self)
        if not pw:
            return
        again = simpledialog.askstring("Confirm password", "Type the same password again:", show="*", parent=self)
        if pw != again:
            self.shield_note.config(text="The passwords did not match. No files were changed.", fg=BAD)
            return
        self.shield_note.config(text="Locking selected files...", fg=WARN)
        self.shield_pending = True
        def work():
            results = [gr_shield.lock_file(p, pw) for p in chosen]
            self.ui_q.put(("shield_lock", results))
        threading.Thread(target=work, daemon=True).start()

    def shield_unlock(self):
        if self.shield_pending:
            return
        path = filedialog.askopenfilename(parent=self, title="Choose a Green Rook locked file", filetypes=[("Green Rook locked files", "*.grlocked"), ("All files", "*.*")])
        if not path:
            return
        pw = simpledialog.askstring("Unlock file", "Enter the password used to lock this file:", show="*", parent=self)
        if not pw:
            return
        self.shield_note.config(text="Unlocking file...", fg=WARN)
        self.shield_pending = True
        def work():
            result = gr_shield.unlock_file(path, pw)
            self.ui_q.put(("shield_unlock", result[0], result[1]))
        threading.Thread(target=work, daemon=True).start()

    # -- Running programs --------------------------------------------------------------------------------------
    def page_patrol(self, f):
        self.header(f, "Running programs", "Everything that is running on this computer right now.", "list")
        if not psutil:
            label(f, "Install the 'psutil' add-on to use this page:   pip install psutil", 11, color=WARN).pack(anchor="w", pady=(0, 8))
        r = tk.Frame(f, bg=BG)
        r.pack(side="bottom", fill="x", pady=(14, 0))
        Btn(r, "Refresh list", self.refresh_procs, "neutral", icon="refresh").pack(side="left", padx=(0, 8))
        Btn(r, "Scan selected program", self.scan_proc, "primary", icon="scan").pack(side="left", padx=(0, 8))
        Btn(r, "Stop selected program", self.kill_proc, "danger").pack(side="left")
        wrap, self.proc_tree = self.tree(f, [("pid", "ID"), ("name", "Program"), ("user", "Owner"), ("exe", "Where it is stored")],
                                         [56, 150, 110, 420], 8, "browse", empty="No running programs are listed.")
        wrap.pack(fill="both", expand=True)

    def refresh_procs(self):
        if not psutil:
            return
        self.proc_tree.delete(*self.proc_tree.get_children())
        rows = []
        for p in psutil.process_iter(["pid", "name", "username", "exe"]):
            i = p.info
            rows.append((i["pid"], i["name"] or "?", (i["username"] or "").split("\\")[-1], i["exe"] or ""))
        for r in sorted(rows, key=lambda x: (x[1] or "").lower()):
            self.proc_tree.insert("", "end", values=r)

    def sel_proc(self):
        s = self.proc_tree.selection()
        if not s:
            self.say("Click a program in the list first.")
            return None
        return self.proc_tree.item(s[0], "values")

    def scan_proc(self):
        v = self.sel_proc()
        if not v:
            return
        if not v[3]:
            return self.say("Windows does not tell us where this program is stored, so it cannot be scanned.")

        def work():
            res = self.engine.scan_file(v[3])
            self.ui_q.put(("proc_scan", v[1], res))
        threading.Thread(target=work, daemon=True).start()

    def kill_proc(self):
        v = self.sel_proc()
        if v and messagebox.askyesno("Stop this program?", f"Stop {v[1]} (ID {v[0]})?\n\nAnything unsaved in it will be lost.", parent=self):
            try:
                psutil.Process(int(v[0])).kill()
                self.bus.emit("INFO", "Programs", f"You stopped {v[1]} ({v[0]})")
            except Exception as e:
                self.say(f"Could not stop it.\n{e}\n\nTry starting Green Rook as administrator.", kind="error")
            self.after(400, self.refresh_procs)

    # -- History ----------------------------------------------------------------------------------------------------
    def page_chronicle(self, f):
        self.header(f, "History", "Filter what Green Rook has noticed and done.", "clock")
        self.history_filter = "all"
        filt = tk.Frame(f, bg=BG)
        filt.pack(fill="x", pady=(0, 10))
        label(filt, "Show", 9, True, MUTED).pack(side="left", padx=(0, 8))
        Seg(filt, self.history_filter, self.set_history_filter, ("all", "threats", "warnings", "actions"),
            labels={"all": "All", "threats": "Threats", "warnings": "Warnings", "actions": "Actions"}).pack(side="left")
        wrap = tk.Frame(f, bg=CARD, highlightthickness=1, highlightbackground=LINE)
        self.log_wrap = wrap
        self.log_text = tk.Text(wrap, bg=CARD, fg=FG, font=(MONO, 9), relief="flat", state="disabled", wrap="word", padx=14, pady=12, highlightthickness=0)
        sb = ttk.Scrollbar(wrap, command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.log_text.pack(side="left", fill="both", expand=True)
        for tag, col in [("THREAT", BAD), ("WARN", WARN), ("ERROR", BAD), ("AUDIT", INFO), ("INFO", MUTED), ("EMPTY", FAINT)]:
            self.log_text.tag_configure(tag, foreground=col)
        self.log_empty = False
        r = tk.Frame(f, bg=BG)
        r.pack(side="bottom", fill="x", pady=(10, 0))
        Btn(r, "Open the log file", lambda: open_path(str(self.folder / "events.log")), "neutral", size="small").pack(side="left")
        self.log_wrap.pack(fill="both", expand=True)

    def _history_matches(self, entry):
        level = entry[1]
        if self.history_filter == "threats":
            return level in ("THREAT", "ERROR")
        if self.history_filter == "warnings":
            return level == "WARN"
        if self.history_filter == "actions":
            return level in ("INFO", "AUDIT")
        return True

    def set_history_filter(self, value):
        self.history_filter = value
        self.refresh_chronicle()

    def append_log(self, entry):
        if not self._history_matches(entry):
            return
        ts, lvl, src, msg = entry
        self.log_text.config(state="normal")
        if self.log_empty:
            self.log_text.delete("1.0", "end")
            self.log_empty = False
        self.log_text.insert("end", f"{ts}  {lvl:<6} {src:<18} {msg}\n", lvl if lvl in ("THREAT", "WARN", "ERROR", "AUDIT") else "INFO")
        self.log_text.see("end")
        self.log_text.config(state="disabled")

    def refresh_chronicle(self):
        with self.bus.lock:
            entries = tuple(self.bus.history)
        self.log_text.config(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.config(state="disabled")
        self.log_empty = False
        matched = [entry for entry in entries if self._history_matches(entry)]
        if matched:
            for entry in matched:
                self.append_log(entry)
        else:
            self.log_text.config(state="normal")
            self.log_text.insert("end", "No events match this filter.\n", "EMPTY")
            self.log_text.config(state="disabled")
            self.log_empty = True

    # -- Settings ------------------------------------------------------------------------------------------------------
    def page_armory(self, f):
        self.header(f, "Settings", "Choose how Green Rook protects you.", "sliders")
        sf = ScrollFrame(f)
        sf.pack(fill="both", expand=True)
        p = sf.inner

        def section(title, hint=""):
            c = card(p)
            c.pack(fill="x", pady=(0, 12), padx=(0, 10))
            label(c, title, 12, True).pack(anchor="w")
            if hint:
                label(c, hint, 10, color=MUTED, wraplength=820, justify="left").pack(anchor="w", pady=(2, 8))
            return c

        def listbox(parent, key, on_change):
            lb = tk.Listbox(parent, bg=CARD2, fg=FG, selectbackground=SELECTED, relief="flat", height=4, highlightthickness=0, font=(FONT, 10))
            lb.pack(fill="x", pady=8)
            for d in self.cfg.get(key):
                lb.insert("end", d)
            r = tk.Frame(parent, bg=CARD)
            r.pack(anchor="w")

            def add():
                d = filedialog.askdirectory(title="Choose a folder")
                if d and d not in lb.get(0, "end"):
                    lb.insert("end", d)
                    self.cfg.set(key, list(lb.get(0, "end")))
                    on_change()

            def rm():
                if not lb.curselection() or not self.authorize("stop protecting a folder"):
                    return
                for i in reversed(lb.curselection()):
                    lb.delete(i)
                self.cfg.set(key, list(lb.get(0, "end")))
                on_change()
            Btn(r, "Add a folder\u2026", add, "neutral", icon="plus").pack(side="left", padx=(0, 8))
            Btn(r, "Remove selected", rm, "ghost").pack(side="left")

        listbox(section("Folders watched live", "The file watcher checks everything that appears in these folders."), "watch_dirs", self.file_guard.reset)
        listbox(section("Folders guarded against ransomware", "The ransomware shield plants harmless bait files here and watches them."),
                "protected_dirs", lambda: (self.ransom_guard.remove_decoys(), self.ransom_guard.reset()))

        c = section("Behaviour")
        for text, key in (("Automatically quarantine files that are clearly malware (known virus fingerprints only, never guesses)", "auto_quarantine"),
                          ("Check unknown files against an online database (only a fingerprint of the file is sent, never the file)", "cloud_lookup")):
            row = tk.Frame(c, bg=CARD)
            row.pack(fill="x", pady=(0, 12))
            label(row, text, 10, wraplength=700, justify="left").pack(side="left")
            Switch(row, self.cfg.get(key), lambda v, k=key, t=text: self._set_flag(k, v, t), CARD).pack(side="right")
        for text, key, lo, hi in (("How long to wait for your answer before Green Rook blocks (seconds)", "prompt_timeout", 5, 300),
                                  ("Automatic quick scan every ... hours (0 = never)", "scan_every_hours", 0, 168)):
            row = tk.Frame(c, bg=CARD)
            row.pack(fill="x", pady=(0, 8))
            label(row, text, 10).pack(side="left")
            var = tk.IntVar(value=self.cfg.get(key))
            sp = tk.Spinbox(row, from_=lo, to=hi, width=6, textvariable=var, bg=CARD2, fg=FG, relief="flat", buttonbackground=CARD2,
                            insertbackground=FG, command=lambda v=var, k=key: self._save_int(k, v))
            sp.pack(side="right")
            sp.bind("<FocusOut>", lambda e, v=var, k=key: self._save_int(k, v))

        c = section("Self-protection")
        self.integrity_lbl = label(c, "", 10, color=MUTED, justify="left", wraplength=820)
        self.integrity_lbl.pack(anchor="w", pady=(0, 10))
        r = tk.Frame(c, bg=CARD)
        r.pack(anchor="w")
        Btn(r, "Set or change PIN", self.set_pin, "neutral").pack(side="left", padx=(0, 8))
        Btn(r, "Remove PIN", self.clear_pin, "ghost").pack(side="left")

        c = section("Security updates (signed)", "Updates are only accepted if they carry a digital signature from a publisher you trust. "
                                                 "This stops anyone from slipping in a fake update.")
        self.intel_lbl = label(c, "", 10, color=MUTED, justify="left", wraplength=820)
        self.intel_lbl.pack(anchor="w", pady=(0, 10))
        r0 = tk.Frame(c, bg=CARD)
        r0.pack(anchor="w")
        Btn(r0, "Trust a publisher\u2026", self.trust_key, "neutral").pack(side="left", padx=(0, 8))
        Btn(r0, "Install an update file\u2026", self.install_pack, "primary").pack(side="left", padx=(0, 8))
        Btn(r0, "Download public virus list", self.update_feed, "neutral", icon="refresh").pack(side="left")

        c = section("App icon", "Choose how Green Rook looks on your taskbar, Desktop and Start Menu.")
        row = tk.Frame(c, bg=CARD)
        row.pack(anchor="w", pady=(0, 10))
        self.icon_boxes, self.icon_thumbs = {}, {}
        for name, title in gr_icons.PRESETS:
            col = tk.Frame(row, bg=CARD)
            col.pack(side="left", padx=(0, 10))
            try:
                self.icon_thumbs[name] = tk.PhotoImage(file=str(gr_icons.paths(name)["logo"]))
            except tk.TclError:
                continue
            box = tk.Label(col, image=self.icon_thumbs[name], bg=CARD, cursor="hand2", highlightthickness=3, highlightbackground=CARD, padx=4, pady=4)
            box.pack()
            box.bind("<Button-1>", lambda e, n=name: self.pick_icon(n))
            label(col, title, 9, color=MUTED).pack(pady=(4, 0))
            self.icon_boxes[name] = box
        ri = tk.Frame(c, bg=CARD)
        ri.pack(anchor="w")
        Btn(ri, "Use my own image\u2026", self.pick_own_icon, "neutral", icon="file").pack(side="left", padx=(0, 8))
        Btn(ri, "Back to the original", lambda: self.pick_icon("green"), "ghost").pack(side="left")
        self.paint_icon_choices()

        c = section("Dangerous-website list", "The network watcher refuses connections to websites on this list.")
        self.block_status = label(c, "", 10, color=MUTED, justify="left", wraplength=820)
        self.block_status.pack(anchor="w", pady=(0, 10))
        rl = tk.Frame(c, bg=CARD)
        rl.pack(anchor="w")
        Btn(rl, "Download latest list", self.update_blocklist, "primary", icon="refresh").pack(side="left", padx=(0, 8))
        Btn(rl, "Add my own list\u2026", self.import_blocklist, "neutral").pack(side="left", padx=(0, 8))
        Btn(rl, "Block them on this whole PC", lambda: self.hosts_action(True), "neutral").pack(side="left", padx=(0, 8))
        Btn(rl, "Stop blocking", lambda: self.hosts_action(False), "ghost").pack(side="left")

        c = section("Tools")
        r1 = tk.Frame(c, bg=CARD)
        r1.pack(anchor="w", pady=(0, 8))
        Btn(r1, "Add my own virus list\u2026", self.import_hashes, "neutral").pack(side="left", padx=(0, 8))
        Btn(r1, "Edit my own detection rules", self.open_rules, "neutral").pack(side="left", padx=(0, 8))
        Btn(r1, "Create a safe test virus", self.make_test_threat, "primary").pack(side="left")
        r2 = tk.Frame(c, bg=CARD)
        r2.pack(anchor="w")
        if IS_WIN and not gr_health.is_admin():
            Btn(r2, "Restart as administrator", self.restart_as_admin, "warn").pack(side="left", padx=(0, 8))
        Btn(r2, "Forget everything I marked safe", self.reset_trust, "ghost").pack(side="left", padx=(0, 8))
        Btn(r2, "Open Green Rook's data folder", lambda: open_path(str(self.folder)), "ghost").pack(side="left")
        self.about_lbl = label(c, "", 9, color=FAINT, justify="left")
        self.about_lbl.pack(anchor="w", pady=(14, 0))

    def trust_key(self):
        p = filedialog.askopenfilename(title="Publisher's public key file (.pub)", filetypes=[("Public key", "*.pub"), ("All files", "*.*")])
        if not p or not self.authorize("trust a new update publisher"):
            return
        try:
            kid = self.engine.intel.add_key(Path(p).read_text())
            self.say(f"Publisher {kid} is now trusted.")
        except (PackError, OSError) as e:
            self.say(str(e), kind="error")
        self.refresh_armory()

    def install_pack(self):
        p = filedialog.askopenfilename(title="Signed update file", filetypes=[("Green Rook update", "*.grpack"), ("All files", "*.*")])
        if not p:
            return
        try:
            i = self.engine.install_pack(p)
            self.web.reload()
            self.say(f"Installed '{i['name']}' #{i['serial']}:\n{i['hashes']} virus fingerprints, {i['domains']} websites, {i['ips']} addresses, {i['rules']} rules.")
        except (PackError, OSError) as e:
            self.say(str(e), kind="error")
        self.refresh_armory()

    def update_feed(self):
        self.intel_lbl.config(text="Downloading the public virus list\u2026", fg=WARN)

        def work():
            try:
                new, total = self.engine.update_hash_feeds()
                self.ui_q.put(("intel_msg", f"Updated: {new:,} new virus fingerprints ({total:,} in the list).", GOOD))
            except Exception as e:
                self.ui_q.put(("intel_msg", f"Could not update: {e}", BAD))
        threading.Thread(target=work, daemon=True).start()

    def _set_flag(self, key, v, text):
        if not v and not self.authorize("weaken protection"):
            return False
        self.cfg.set(key, v)

    def _save_int(self, key, var):
        try:
            self.cfg.set(key, max(0, int(var.get())))
        except (tk.TclError, ValueError):
            pass

    def refresh_armory(self):
        self.refresh_block_status()
        enc = "AES-256-GCM" if AESGCM else "a built-in cipher (install 'cryptography' for AES-256-GCM)"
        self.integrity_lbl.config(text=f"Program files: {self.tamper.integrity}.   PIN: {'set' if self.cfg.get('pin') else 'not set'}.\n"
                                       f"If Green Rook is killed it restarts itself. Switching off a protection asks you to confirm"
                                       f"{' with your PIN' if self.cfg.get('pin') else ''}.")
        agg = self.engine.intel.load_all()
        names = ", ".join(f"{x['name']} #{x['serial']}" for x in agg["packs"]) or "none"
        bad = f"   REJECTED (not trusted or edited): {', '.join(n for n, _ in agg['rejected'])}." if agg["rejected"] else ""
        self.intel_lbl.config(fg=MUTED, text=f"{len(self.engine.intel.trusted())} trusted publisher(s).  Active updates: {names}.{bad}")
        self.about_lbl.config(text=f"Quarantine encryption: {enc}\nKnown threats: {len(self.engine.hashdb)} fingerprints, built-in patterns, "
                                   f"{self.engine.reload_rules()} custom rule(s), {len(self.web.blocklist):,} blocked websites\nData folder: {self.folder}")

    def set_pin(self):
        if self.cfg.get("pin") and not self.authorize("change the PIN"):
            return
        a = simpledialog.askstring(APP_NAME, "Choose a new PIN (at least 4 characters):", show="*", parent=self)
        if not a or len(a) < 4:
            return
        if simpledialog.askstring(APP_NAME, "Type the PIN again:", show="*", parent=self) != a:
            return self.say("The two PINs were different. Nothing was changed.", kind="error")
        self.cfg.set("pin", hash_pin(a))
        self.bus.emit("INFO", "Tamper Guard", "PIN set")
        self.refresh_armory()

    def clear_pin(self):
        if self.cfg.get("pin") and self.authorize("remove the PIN"):
            self.cfg.set("pin", "")
            self.refresh_armory()

    def import_hashes(self):
        p = filedialog.askopenfilename(title="Text file with one virus fingerprint (SHA-256) per line")
        if p:
            self.say(f"Added {self.engine.import_hashes(p)} new fingerprints.")

    def open_rules(self):
        self.engine.reload_rules()
        open_path(str(self.engine.rules_file))

    def make_test_threat(self):
        target = Path.home() / "Downloads"
        target = target if target.exists() else Path.home()
        eicar = "X5O!P%@AP[4\\PZX54(P^)7CC)7}$" + "EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*"
        dest = target / "eicar_test_file.com"
        try:
            dest.write_text(eicar)
        except OSError as e:
            return self.say(str(e), kind="error")
        self.say(f"A harmless test file was created:\n{dest}\n\nIt is the industry-standard EICAR test. With the file watcher on, "
                 "Green Rook should lock it in Quarantine within a few seconds.\n\nOn Windows, Microsoft Defender may remove it first. "
                 "That is normal: both antivirus programs recognise the same test file.")

    def restart_as_admin(self):
        """Windows only: re-open Green Rook with administrator rights so it can delete and quarantine protected files."""
        if not IS_WIN:
            return
        if not messagebox.askyesno("Restart as administrator", "Windows will ask for permission. Choose YES there.\n\n"
                                   "Green Rook will close and re-open with extra rights. Continue?", parent=self):
            return
        try:
            import ctypes
            exe = Path(sys.executable)
            pyw = exe.with_name("pythonw.exe")
            frozen = getattr(sys, "frozen", False)
            prog = str(exe if frozen or not pyw.exists() else pyw)
            args = "--elevated" if frozen else f'"{Path(__file__).resolve()}" --elevated'
            rc = ctypes.windll.shell32.ShellExecuteW(None, "runas", prog, args, str(INSTALL_DIR), 1)
        except Exception as e:
            return self.say(f"Could not restart as administrator: {e}", kind="error")
        if rc > 32:
            self.shutdown()
        else:
            self.say("The restart was cancelled. Green Rook is still running as before.")

    def reset_trust(self):
        if self.authorize("clear every trusted item") and messagebox.askyesno("Forget trusted items?", "Forget every file, program and camera app you marked as safe?", parent=self):
            for k in ("allow_hashes", "proc_allowed", "camera_allowed", "net_allowed"):
                self.cfg.set(k, [])

    # -- watchdog ------------------------------------------------------------------------------------------------------
    def start_watchdog(self):
        if not psutil or "--no-watchdog" in sys.argv:
            return
        try:
            (self.folder / "main.pid").write_text(str(os.getpid()))
            (self.folder / "clean_exit.flag").unlink(missing_ok=True)
            if self.cfg.get("tamper_protection"):
                ensure_watchdog()
        except OSError:
            pass

    # -- event pump ------------------------------------------------------------------------------------------------------
    def handle_message(self, m):
        k = m[0]
        if k == "log":
            self.append_log(m[1])
        elif k == "notify":
            Toast(self, m[1], m[2], m[3])
            self.refresh_dashboard()
        elif k == "prompt":
            self.prompts.append(m[1])
            self.next_prompt()
        elif k == "scan_hit":
            self.add_scan_hit(m[1])
        elif k == "scan_progress":
            self.scan_status.config(text=f"{self.scan_name} in progress")
            self._scan_progress_update(m[1], m[2])
        elif k == "scan_done":
            self.scan_finished(*m[1:])
        elif k == "web_update":
            self.refresh_block_status()
            self.block_status.config(text=m[1], fg=m[2])
        elif k == "health":
            self.show_health(m[1])
        elif k == "health_error":
            self.health_pending = False
            self.health_btn.set_loading(False)
            self.health_sum.config(text=f"The check could not finish: {m[1]}", fg=BAD)
        elif k == "shield_result":
            self.show_shield(m[1])
        elif k == "shield_error":
            self.shield_running = False
            self.shield_run_btn.set_loading(False)
            self.shield_summary.config(text=f"The check could not finish: {m[1]}", fg=BAD)
        elif k == "shield_action":
            self.shield_pending = False
            self.shield_note.config(text=m[2], fg=GOOD if m[1] else BAD)
            if m[1]:
                self.run_shield()
        elif k == "shield_lock":
            self.shield_pending = False
            ok = sum(1 for success, _ in m[1] if success)
            msg = f"{ok} file(s) locked." + (" " + "; ".join(text for success, text in m[1] if not success) if ok < len(m[1]) else "")
            self.shield_note.config(text=msg, fg=GOOD if ok == len(m[1]) else WARN)
            self.run_shield()
        elif k == "shield_unlock":
            self.shield_pending = False
            self.shield_note.config(text=m[2], fg=GOOD if m[1] else BAD)
            if m[1]: self.run_shield()
        elif k == "selftest":
            self.selftest_running = False
            self.selftest_btn.set_loading(False)
            self.selftest_box.config(state="normal")
            self.selftest_box.delete("1.0", "end")
            self.selftest_box.insert("end", m[1])
            self.selftest_box.config(state="disabled")
        elif k == "intel_msg":
            self.intel_lbl.config(text=m[1], fg=m[2])
        elif k == "ultra_done":
            self.ultra_connected(*m[1:])
        elif k == "ultra_off":
            self.ultra_disconnected(*m[1:])
        elif k == "ultra_ip":
            how = m[2] if len(m) > 2 else "direct"
            if not m[1]:
                self.ur_ip.config(text="Could not check (no internet, or the address service is blocked).", fg=WARN)
            elif how == "tor":
                self.ur_ip.config(text=f"Tor's checker confirms websites see {m[1]}, a Tor address.", fg=GOOD)
            elif how == "not-tor":
                self.ur_ip.config(text=f"WARNING: through the proxy, websites see {m[1]}, which is NOT a Tor address.", fg=BAD)
            else:
                self.ur_ip.config(text=f"Websites currently see your address as {m[1]}.", fg=FG)
        elif k == "tor_progress":
            if self.ultra_busy:
                self.ur_title.config(text=f"Connecting to the Tor network...  {m[1]}%")
        elif k == "tor_done":
            self.tor_connected(*m[1:])
        elif k == "tor_off":
            self.ultra_busy = False
            self.ur_connect_btn.set_enabled(True)
            self.ur_disconnect_btn.set_enabled(True)
            self.ur_ip.config(text="Free mode is off. Websites can see your real address again.", fg=MUTED)
            self.bus.emit("INFO", "Ultra Rook", "Free mode switched off")
            self.refresh_ultra()
        elif k == "tor_installed":
            self.refresh_ultra()
            self.say("Tor is installed. You can now press Connect." if m[1] else "Tor could not be found after installing. Press 'I already have it' and choose tor.exe "
                     "(inside the Tor Browser folder).", kind="info" if m[1] else "warn")
        elif k == "ultra_wg":
            self.refresh_ultra()
            self.say("WireGuard is installed. You can now connect." if m[1] else "WireGuard could not be installed automatically. Use the download page button.",
                     kind="info" if m[1] else "warn")
        elif k == "proc_scan":
            res = m[2]
            self.say(f"{m[1]}: {VERDICT_WORD.get(res.verdict, res.verdict)} (risk {res.score}/100)\n\n" + "\n".join(res.reasons[:6]))

    def report_callback_exception(self, exc, value, tb):
        """Make Tk callback failures visible even when the app was started without a console."""
        detail = "".join(traceback.format_exception(exc, value, tb))
        path = _write_error_log("interface-error.log", detail)
        try:
            self.bus.emit("ERROR", "Interface", str(value))
        except Exception:
            pass
        if not self._interface_error_shown:
            self._interface_error_shown = True
            messagebox.showerror("Green Rook encountered a problem",
                                 f"A screen action failed. Green Rook is still open.\n\nDetails were saved to:\n{path}",
                                 parent=self)

    def _raise_for_instance_request(self, request):
        try:
            self.deiconify()
            self.lift()
            self.focus_force()
        except tk.TclError:
            return
        if request == "ADMIN":
            self.after_idle(lambda: messagebox.showinfo(
                "Green Rook is already open",
                "The existing window has been brought forward. To restart with administrator rights, use Settings > Restart as administrator.",
                parent=self))

    def pump(self):
        """Deliver background messages and local single-window requests to Tk's UI thread."""
        try:
            for _ in range(200):
                try:
                    m = self.ui_q.get_nowait()
                except queue.Empty:
                    break
                try:
                    self.handle_message(m)
                except Exception as e:
                    self.bus.emit("ERROR", "Interface", f"Could not show a '{m[0]}' message: {e}")
            for _ in range(20):
                try:
                    request = self.instance_inbox.get_nowait()
                except queue.Empty:
                    break
                self._raise_for_instance_request(request)
        finally:
            self.after(100, self.pump)

    def next_prompt(self):
        if self.dialog is None and self.prompts:
            p = self.prompts.pop(0)
            self.deiconify()
            self.dialog = PromptDialog(self, p)

    def dialog_closed(self):
        self.dialog = None
        self.after(150, self.next_prompt)

    # -- shutdown ----------------------------------------------------------------------------------------------------------
    def on_close(self):
        ans = messagebox.askyesnocancel("Close Green Rook?", "Keep protecting this PC?\n\nYes  -  hide the window, protection keeps running\n"
                                        "No  -  close Green Rook completely (protection stops)\nCancel  -  go back", parent=self)
        if ans is None:
            return
        if ans:
            self.iconify()
        elif self.authorize("quit Green Rook"):
            self.shutdown()

    def shutdown(self):
        try:
            (self.folder / "clean_exit.flag").write_text("1")
        except OSError:
            pass
        self.broker.shutdown = True
        for s in (*self.services.values(), self.tamper, self.ultra_watch, self.tor_watch):
            s.alive = False
        self.tor_shutdown()
        self.ransom_guard.remove_decoys()
        self.cfg.save()
        self.destroy()


def _write_error_log(name, detail):
    try:
        path = data_dir() / name
    except Exception:
        path = Path.home() / ("GreenRook-" + name)
    try:
        with path.open("a", encoding="utf-8") as f:
            f.write("\n" + time.strftime("%Y-%m-%d %H:%M:%S") + "\n" + detail.rstrip() + "\n")
        return path
    except OSError:
        return Path("startup-error.log")


def _show_startup_error(detail):
    path = _write_error_log("startup-error.log", detail)
    message = f"Green Rook could not open its window.\n\nError details were saved to:\n{path}"
    if IS_WIN:
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, message, "Green Rook startup problem", 0x10)
            return
        except Exception:
            pass
    try:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Green Rook startup problem", message, parent=root)
        root.destroy()
    except Exception:
        print(message, file=sys.stderr)


def _signal_startup_ready():
    ready_path = os.environ.get("GREENROOK_STARTUP_READY")
    if ready_path:
        try:
            Path(ready_path).write_text(str(os.getpid()), encoding="utf-8")
        except OSError:
            pass


def main():
    args = set(sys.argv[1:])
    if "--watchdog" in args:
        run_watchdog()
        return

    # An elevated restart waits for the old window to finish shutting down. Every other
    # duplicate launch simply asks the existing window to come forward.
    wait = 30.0 if "--elevated" in args else 0.0
    listener = bind_instance_socket(DEFAULT_ADDRESS, wait=wait)
    if listener is None:
        request = "ADMIN" if "--admin-shortcut" in args else "SHOW"
        if send_instance_request(DEFAULT_ADDRESS, request):
            _signal_startup_ready()
            return
        if "--elevated" in args:
            _show_startup_error("The administrator restart could not take over the Green Rook window within 30 seconds.\n"
                                "The existing window may still be closing; try Settings > Restart as administrator again.")
        else:
            _show_startup_error("Green Rook could not claim its local startup channel.\n"
                                "Another program may be using the same address. Close that program or restart Windows, then try again.")
        return

    inbox = queue.Queue()
    stop_server = threading.Event()
    server = threading.Thread(target=serve_instance_requests, args=(listener, inbox, stop_server), daemon=True)
    server.start()
    try:
        app = App(restarted="--restarted" in args, instance_inbox=inbox)
        app.update_idletasks()
        _signal_startup_ready()
        app.mainloop()
    except Exception:
        _show_startup_error(traceback.format_exc())
    finally:
        stop_server.set()
        listener.close()
        server.join(timeout=1)


if __name__ == "__main__":
    main()
