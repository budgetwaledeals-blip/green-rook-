"""
Green Rook - Office macro analysis (defensive, read-only).

Melissa (1999) was a Word macro. Old-style Office files (.doc/.xls) are OLE "compound files" whose VBA source is
stored compressed (MS-OVBA), so a plain byte search cannot see it. This module:

  1. parses the OLE container just enough to list its streams,
  2. decompresses the VBA module source,
  3. returns the readable macro text and a list of explained risk findings.

Nothing here ever executes a macro. Every parser has hard size / count limits and survives corrupt input.
"""
import struct

OLE_MAGIC = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"
MAX_STREAM = 16 * 1024 * 1024
MAX_ENTRIES = 4000
ENDOFCHAIN, FREESECT = 0xFFFFFFFE, 0xFFFFFFFF

MACRO_EXTS_OOXML = {".docm", ".xlsm", ".pptm", ".dotm", ".xlam", ".xltm", ".potm", ".ppam", ".sldm"}
LEGACY_OFFICE_EXTS = {".doc", ".dot", ".xls", ".xlt", ".xla", ".ppt", ".pot", ".pps", ".ppa"}


def is_ole(data: bytes) -> bool:
    return data[:8] == OLE_MAGIC


# --------------------------------------------------------------------------- OLE compound file reader
class OleError(Exception):
    pass


class OleFile:
    def __init__(self, data: bytes):
        if len(data) < 512 or not is_ole(data):
            raise OleError("not an OLE file")
        self.d = data
        shift, mini_shift = struct.unpack_from("<HH", data, 0x1E)
        if shift not in (9, 12) or mini_shift != 6:
            raise OleError("unsupported sector size")
        self.ss, self.mss = 1 << shift, 1 << mini_shift
        nfat, first_dir, _txn, cutoff, first_minifat, nminifat, first_difat, ndifat = struct.unpack_from("<IIIIIIII", data, 0x2C)
        self.cutoff = cutoff or 4096
        difat = list(struct.unpack_from("<109I", data, 0x4C))
        sid, seen = first_difat, set()
        while ndifat and sid not in (ENDOFCHAIN, FREESECT) and sid not in seen and len(seen) < 4096:
            seen.add(sid)
            sec = self._sector(sid)
            ids = struct.unpack_from(f"<{self.ss // 4}I", sec)
            difat.extend(ids[:-1])
            sid = ids[-1]
        self.fat = []
        for fs in [x for x in difat if x not in (ENDOFCHAIN, FREESECT)][:nfat]:
            try:
                self.fat.extend(struct.unpack_from(f"<{self.ss // 4}I", self._sector(fs)))
            except (struct.error, OleError):
                break
        self.minifat = []
        if nminifat and first_minifat not in (ENDOFCHAIN, FREESECT):
            raw = self._chain(first_minifat, nminifat * self.ss)
            self.minifat = list(struct.unpack_from(f"<{len(raw) // 4}I", raw))
        dir_raw = self._chain(first_dir, MAX_ENTRIES * 128)
        self.entries = []
        for i in range(0, min(len(dir_raw), MAX_ENTRIES * 128) - 127, 128):
            e = dir_raw[i:i + 128]
            nlen = struct.unpack_from("<H", e, 64)[0]
            name = e[:max(0, min(nlen, 64) - 2)].decode("utf-16le", "ignore")
            typ = e[66]
            left, right, child = struct.unpack_from("<III", e, 68)
            start = struct.unpack_from("<I", e, 116)[0]
            size = struct.unpack_from("<Q", e, 120)[0] & 0xFFFFFFFF
            self.entries.append({"name": name, "type": typ, "left": left, "right": right, "child": child, "start": start, "size": size})
        self.ministream = b""
        self.paths = self._build_paths()

    def _sector(self, sid):
        off = (sid + 1) * self.ss
        if sid >= 0xFFFFFFFA or off >= len(self.d):
            raise OleError("sector outside file")
        return self.d[off:off + self.ss].ljust(self.ss, b"\0")

    def _chain(self, start, limit):
        out, seen, sid = bytearray(), set(), start
        while sid < len(self.fat) and sid not in seen and len(out) < limit:
            seen.add(sid)
            try:
                out += self._sector(sid)
            except OleError:
                break
            sid = self.fat[sid]
        return bytes(out)

    def _mini_chain(self, start, size):
        if not self.ministream and self.entries:
            root = self.entries[0]
            self.ministream = self._chain(root["start"], MAX_STREAM)[:root["size"]]
        out, seen, sid = bytearray(), set(), start
        while sid < len(self.minifat) and sid not in seen and len(out) < size:
            seen.add(sid)
            out += self.ministream[sid * self.mss:(sid + 1) * self.mss]
            sid = self.minifat[sid]
        return bytes(out)

    def _build_paths(self):
        """Map 'Storage/Stream' (original case) -> entry index by walking the directory's sibling trees."""
        paths, seen = {}, set()
        if not self.entries:
            return paths
        stack = [(self.entries[0]["child"], "")]
        while stack and len(paths) < MAX_ENTRIES:
            idx, prefix = stack.pop()
            if idx >= len(self.entries) or idx in seen:
                continue
            seen.add(idx)
            e = self.entries[idx]
            full = prefix + e["name"]
            paths[full] = idx
            stack.append((e["left"], prefix))
            stack.append((e["right"], prefix))
            if e["type"] == 1:
                stack.append((e["child"], full + "/"))
        return paths

    def read(self, path_or_idx) -> bytes:
        idx = self.paths[path_or_idx] if isinstance(path_or_idx, str) else path_or_idx
        e = self.entries[idx]
        size = min(e["size"], MAX_STREAM)
        if e["type"] != 2 or size == 0:
            return b""
        if size < self.cutoff:
            return self._mini_chain(e["start"], size)[:size]
        return self._chain(e["start"], size)[:size]


# --------------------------------------------------------------------------- MS-OVBA decompression
def ovba_decompress(buf: bytes) -> bytes:
    """Decompress a VBA 'CompressedContainer'. Stops quietly at the first malformed chunk."""
    if not buf or buf[0] != 1:
        return b""
    out, pos, n = bytearray(), 1, len(buf)
    while pos + 2 <= n and len(out) < MAX_STREAM:
        header = buf[pos] | (buf[pos + 1] << 8)
        if (header >> 12) & 7 != 3:          # chunk signature must be 0b011 - also stops at zero padding
            break
        size = (header & 0x0FFF) + 3
        compressed = (header >> 15) & 1
        end = min(pos + size, n)
        pos += 2
        if not compressed:
            out += buf[pos:pos + 4096]
            pos += 4096
            continue
        start = len(out)
        while pos < end:
            flags = buf[pos]
            pos += 1
            for bit in range(8):
                if pos >= end:
                    break
                if not (flags >> bit) & 1:
                    out.append(buf[pos])
                    pos += 1
                else:
                    if pos + 2 > end:
                        pos = end
                        break
                    token = buf[pos] | (buf[pos + 1] << 8)
                    pos += 2
                    diff = len(out) - start
                    bits = max((diff - 1).bit_length(), 4) if diff > 1 else 4
                    length_mask = 0xFFFF >> bits
                    length = (token & length_mask) + 3
                    offset = ((token & ~length_mask & 0xFFFF) >> (16 - bits)) + 1
                    if offset > diff:
                        return bytes(out)      # corrupt back-reference (must point inside the current chunk)
                    for _ in range(length):
                        out.append(out[-offset])
        pos = max(pos, end)
    return bytes(out)


def _dir_records(d: bytes):
    pos, n = 0, len(d)
    while pos + 6 <= n:
        rid, size = struct.unpack_from("<HI", d, pos)
        pos += 6
        if rid == 0x0009:        # PROJECTVERSION: declared size 4, but 6 data bytes follow
            size = 6
        yield rid, d[pos:pos + size]
        pos += size


def vba_modules(data: bytes):
    """[(module_name, source_text)] for an OLE file that holds a VBA project. Empty list if none/unreadable."""
    try:
        ole = OleFile(data)
    except (OleError, struct.error, IndexError):
        return []
    mods = []
    for path in list(ole.paths):
        if path.rsplit("/", 1)[-1] != "VBA" or ole.entries[ole.paths[path]]["type"] != 1:
            continue
        base = path + "/"
        if base + "dir" not in ole.paths:
            continue
        try:
            dirdata = ovba_decompress(ole.read(base + "dir"))
            lower = {k.lower(): k for k in ole.paths if k.startswith(base)}
            name, stream, offset = "", "", 0
            for rid, val in _dir_records(dirdata):
                if rid == 0x0019:
                    name = val.decode("cp1252", "ignore")
                elif rid == 0x001A:
                    stream = val.decode("cp1252", "ignore")
                elif rid == 0x0031 and len(val) >= 4:
                    offset = struct.unpack_from("<I", val)[0]
                    key = lower.get((base + stream).lower())
                    if key:
                        src = ovba_decompress(ole.read(key)[offset:])
                        mods.append((name or stream, src.decode("cp1252", "ignore")))
        except (OleError, struct.error, IndexError, KeyError):
            continue
    return mods


def has_vba_markers(data: bytes) -> bool:
    """Cheap check that works even if the project cannot be fully parsed (stream names are stored as UTF-16)."""
    return any(m.encode("utf-16le") in data for m in ("_VBA_PROJECT", "VBA"))


# --------------------------------------------------------------------------- macro risk analysis
AUTO_EXEC = ("autoopen", "auto_open", "autoexec", "autoclose", "auto_close", "document_open", "document_close", "document_new",
             "workbook_open", "workbook_activate", "workbook_beforeclose", "auto_activate")
SUSPICIOUS_CALLS = [
    ("starts programs (Shell / WScript.Shell / ShellExecute)", 10, ("shell(", "shell ", "wscript.shell", "shellexecute", ".run(", ".exec(")),
    ("creates COM objects dynamically (CreateObject / GetObject)", 5, ("createobject", "getobject(")),
    ("downloads from the internet (URLDownloadToFile / XMLHTTP / WinHttp)", 14, ("urldownloadtofile", "xmlhttp", "winhttp", "msxml2.serverxmlhttp", "internetopenurl")),
    ("writes binary files (ADODB.Stream / SaveToFile)", 10, ("adodb.stream", "savetofile")),
    ("launches PowerShell / cmd / script hosts", 14, ("powershell", "cmd /c", "cmd.exe", "mshta", "wscript.exe", "cscript", "regsvr32", "rundll32", "certutil")),
    ("reads environment / temp paths to drop files", 5, ("environ(", "environ$(", "%temp%", "%appdata%")),
    ("hides its window (vbHide / WindowStyle)", 6, ("vbhide", "windowstyle", "visible = false")),
    ("drives Outlook to send mail (worm-style behaviour)", 10, ("outlook.application",)),
    ("reads the address book (mass-mailer behaviour)", 12, ("addressentries", "addresslists")),
    ("modifies the registry / start-up", 8, ("regwrite", "currentversion\\run")),
]


def analyze_macros(modules, ext=""):
    """Return [(weight, reason, confirmed)] for decompressed macro modules. Weights are deliberately modest:
    macros are common in legitimate spreadsheets - it is the *combination* that is dangerous."""
    findings = []
    if not modules:
        return findings
    text = "\n".join(src.lower() for _, src in modules)
    findings.append((8, f"Contains {len(modules)} VBA macro module(s)", False))
    auto = sorted({a for a in AUTO_EXEC if a in text})
    if auto:
        findings.append((8, "Macro runs automatically when the file is opened (" + ", ".join(auto[:3]) + ")", False))
    risky = []
    for label, weight, needles in SUSPICIOUS_CALLS:
        if any(nd in text for nd in needles):
            risky.append((label, weight))
    for label, weight in risky:
        findings.append((weight, "Macro " + label, False))
    if auto and sum(w for _, w in risky) >= 20:
        findings.append((25, "Auto-running macro that also launches programs or downloads data (classic macro-malware pattern)", False))
    if text.count("chr(") + text.count("chrw(") > 60 or text.count('" & "') > 80:
        findings.append((12, "Macro text is heavily obfuscated (hundreds of Chr()/string-concatenation fragments)", False))
    if "outlook.application" in text and ("addressentries" in text or "addresslists" in text):
        findings.append((25, "Macro enumerates the address book through Outlook (Melissa-style mass-mailer)", False))
    return findings
