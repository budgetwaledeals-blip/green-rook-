"""
Green Rook - built-in self-test ("Stage 6: test with harmless files and controlled simulations").

Runs entirely in a throw-away temp folder with its own settings: it never touches your real settings, vault or files.
It checks both directions - that bad things are caught AND that good things are left alone (false-positive guard).
"""
import contextlib
import io
import json
import os
import queue
import shutil
import tempfile
import zipfile
from pathlib import Path


@contextlib.contextmanager
def isolated_env():
    """Point every 'home / appdata' lookup at a temp folder, then restore."""
    tmp = tempfile.mkdtemp(prefix="greenrook_selftest_")
    keys = ("HOME", "APPDATA", "USERPROFILE", "TEMP")
    old = {k: os.environ.get(k) for k in keys}
    for k in keys:
        os.environ[k] = tmp
    try:
        yield Path(tmp)
    finally:
        for k, v in old.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        shutil.rmtree(tmp, ignore_errors=True)


def run_selftest():
    """Returns [(name, passed, detail)]."""
    results = []

    def check(name, fn):
        try:
            ok, detail = fn()
        except Exception as e:  # a crash is a failed test, not a crashed self-test
            ok, detail = False, f"crashed: {type(e).__name__}: {e}"
        results.append((name, bool(ok), detail))

    with isolated_env() as root:
        import gr_core as c
        import gr_guards as g
        import gr_intel
        import gr_office
        import gr_testkit as tk
        work = root / "samples"
        work.mkdir()
        cfg = c.Config(root / "config.json")
        bus = c.EventBus(root / "events.log", queue.Queue())
        eng = c.Engine(cfg, bus)
        vault = c.Vault(root, cfg, bus)

        def scan(name, data):
            p = work / name
            p.write_bytes(data if isinstance(data, bytes) else data.encode("latin-1"))
            return eng.scan_file(p, cloud=False)

        eicar = "X5O!P%@AP[4\\PZX54(P^)7CC)7}$" + "EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*"
        # -- file engine --------------------------------------------------------------
        def t_eicar():
            r = scan("eicar.com", eicar)
            return r.verdict == c.MALICIOUS and r.confirmed and r.auto_safe, f"{r.verdict}, score {r.score}, confirmed={r.confirmed}"
        check("EICAR test file is caught with hard evidence", t_eicar)

        def t_clean():
            r = scan("notes.txt", "Shopping list: milk, eggs, bread.\nMeeting at 10.\n")
            return r.verdict == c.CLEAN, r.verdict
        check("Ordinary text file is left alone (no false alarm)", t_clean)

        def t_admin_script():
            r = scan("update.ps1", "Get-ChildItem | Where-Object Length -gt 1MB | Invoke-" + "Expression $cmd\n")
            return r.verdict != c.MALICIOUS, f"{r.verdict}, score {r.score}"
        check("Single mild admin keyword does not condemn a script", t_admin_script)

        def t_double_ext():
            r = scan("invoice.pdf.exe", b"MZ" + b"\0" * 100)
            return any("Double extension" in x for x in r.reasons), "; ".join(r.reasons[:2])
        check("Double-extension disguise is flagged", t_double_ext)

        worm = ('Set o = CreateObject("Outlook.' + 'Application")\nFor Each a In o.GetNameSpace("MAPI").Address' + 'Lists\n a.Address' + 'Entries\nNext\n'
                'Set sh = CreateObject("WScript.Shell")\nsh.Reg' + 'Write "HKCU\\x", 1\n')

        def t_heuristic_no_auto():
            r = scan("mailer_demo.vbs", worm)
            return r.verdict in (c.MALICIOUS, c.SUSPICIOUS) and not r.auto_safe, f"{r.verdict}, score {r.score}, auto-remove={r.auto_safe} (must be False)"
        check("Behaviour-only verdicts are never removed automatically", t_heuristic_no_auto)

        def macro_doc(src):
            return tk.build_cfb(tk.make_vba_streams(src))
        risky = {"ThisDocument": 'Sub Document_Open()\r\n CreateObject("WScript.Shell").Run "cmd /c calc", vbHide\r\n CreateObject("Outlook.Application")\r\nEnd Sub\r\n'}
        calm = {"Module1": 'Sub Total()\r\n Range("A1").Value = 1 + 2\r\nEnd Sub\r\n'}
        check("Auto-running launcher macro is flagged", lambda: ((lambda r: (r.verdict in (c.MALICIOUS, c.SUSPICIOUS), f"{r.verdict}, score {r.score}"))(scan("risky.doc", macro_doc(risky)))))
        check("Harmless spreadsheet macro is left alone", lambda: ((lambda r: (r.verdict == c.CLEAN, f"{r.verdict}, score {r.score}"))(scan("calm.xls", macro_doc(calm)))))

        def t_hidden_macro():
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w") as z:
                z.writestr("[Content_Types].xml", "<x/>")
                z.writestr("word/vbaProject.bin", macro_doc(calm))
            r = scan("report.docx", buf.getvalue())
            return any("hidden" in x.lower() or "extension says" in x.lower() for x in r.reasons), "; ".join(r.reasons[:2])
        check("Macros hidden inside a .docx are noticed", t_hidden_macro)

        def t_zip_bomb():
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
                z.writestr("big.txt", b"A" * 30_000_000)
            r = scan("bomb.zip", buf.getvalue())
            return r.verdict in (c.CLEAN, c.SKIPPED), f"{r.verdict} (scanner survived a highly compressed archive)"
        check("Compressed-archive bomb does not hang the scanner", t_zip_bomb)

        # -- behaviour rules ------------------------------------------------------------
        def t_rules():
            pos = [("powershell.exe", "", "powershell -w hidden -enc " + "QQBBAEEA" * 5, "R02"),
                   ("cmd.exe", "winword.exe", "cmd /c dir", "R01"),
                   ("cmd.exe", "", "vssadmin delete " + "shadows /all /quiet", "R05"),
                   ("wscript.exe", "", r"wscript c:\users\x\appdata\local\temp\invoice.vbs", "R12")]
            neg = [("powershell.exe", "", "powershell -command get-date", ""), ("notepad.exe", "", "notepad c:\\notes.txt", ""),
                   ("wscript.exe", "", r"wscript c:\program files\vendor\setup.vbs", ""), ("cmd.exe", "explorer.exe", "cmd /c dir", "")]
            miss = [e for n, par, cmd, e in pos if e not in [h[0] for h in g.match_rules(n, par, cmd.lower())]]
            fps = [cmd for n, par, cmd, _ in neg if g.match_rules(n, par, cmd.lower())]
            return not miss and not fps, f"missed={miss or 'none'}, false alarms={fps or 'none'}"
        check("Rook Rules catch attacks and ignore normal commands", t_rules)

        def t_critical():
            class Fake:
                pid = 900

                def name(self):
                    return "svchost.exe"
            return g.is_critical(Fake()) and g.kill_tree(Fake()) is False, "operating-system-critical processes are protected"
        check("Critical system processes can never be killed automatically", t_critical)

        def t_fanout():
            f = g.FanoutTracker()
            hit = sum(bool(f.add(10, f"10.0.0.{i}", 445, now=100 + i * 0.1)) for i in range(40))
            f2 = g.FanoutTracker()
            quiet = sum(bool(f2.add(11, f"203.0.113.{i}", 443, now=100 + i * 0.1)) for i in range(40))
            slow = sum(bool(f2.add(12, f"10.0.1.{i}", 445, now=100 + i * 5)) for i in range(40))
            return hit >= 1 and quiet == 0 and slow == 0, f"burst on SMB={hit}, many web connections={quiet}, slow trickle={slow}"
        check("Worm-style scanning is detected, normal browsing is not", t_fanout)

        # -- ransomware shield ------------------------------------------------------------
        def t_ransom():
            def run(content):
                d = root / ("prot_" + str(abs(hash(content)) % 9999))
                d.mkdir()
                for i in range(10):
                    (d / f"doc{i}.txt").write_text("quarterly figures " * 400)
                shield = g.RansomwareShield(cfg, eng, vault, c.Broker(queue.Queue(), cfg), bus, False)
                cur = lambda: dict(c.walk_limited(str(d), 2))  # noqa: E731
                shield.judge(cur())
                for i in range(10):
                    (d / f"doc{i}.txt").write_bytes(content())
                return shield.judge(cur())
            enc = run(lambda: os.urandom(8192))
            edit = run(lambda: b"edited text " * 700)
            return enc is not None and edit is None, f"encrypted-overwrite -> {'ALARM' if enc else 'quiet'}; normal edit -> {'alarm' if edit else 'quiet'}"
        check("Ransomware Shield alarms on encryption, not on normal edits", t_ransom)

        # -- safety nets ------------------------------------------------------------------
        def t_vault():
            data = os.urandom(5000) + b"payload"
            p = work / "victim.bin"
            p.write_bytes(data)
            r = c.ScanResult(str(p), c.MALICIOUS, 90, ["test"], __import__("hashlib").sha256(data).hexdigest(), len(data))
            qid = vault.quarantine(r)
            gone = not p.exists()
            blob = (vault.dir / f"{qid}.sgq").read_bytes()
            p.write_bytes(b"someone made a new file here")
            dest = Path(vault.restore(qid))
            ok = gone and data[:64] not in blob and dest != p and dest.read_bytes() == data and p.read_bytes() == b"someone made a new file here"
            return ok, "encrypted at rest, restored byte-for-byte, existing file never overwritten"
        check("Quarantine is encrypted, reversible and never overwrites", t_vault)

        def t_config():
            cp = root / "cfg2.json"
            c.Config(cp).set("pin", "x")
            raw = json.loads(cp.read_text())
            raw["data"]["tamper_protection"] = False
            cp.write_text(json.dumps(raw))
            return c.Config(cp).tampered, "edited settings file detected and discarded"
        check("Edited settings file is detected (tamper-evident)", t_config)

        def t_sysprot():
            r = c.ScanResult("/usr/bin/x" if not c.IS_WIN else os.environ.get("SystemRoot", "C:\\Windows") + "\\System32\\x.dll", c.MALICIOUS, 100, ["k"], "ab", 1, True)
            return not r.auto_safe, "files in operating-system folders are flagged but never removed automatically"
        check("OS folders are protected from automatic removal", t_sysprot)

        # -- web ----------------------------------------------------------------------------
        def t_url():
            web = c.WebGuard(eng.intel)
            bad = web.analyze("http://paypal-secure-login.verify-account.xyz/signin?update=1")[2]
            ok = web.analyze("https://www.google.com/")[2]
            return bad in ("Dangerous", "Suspicious") and ok == "Looks safe", f"phishing-style link -> {bad}; google.com -> {ok}"
        check("Link checker flags phishing-style URLs, passes real sites", t_url)

        # -- signed updates ------------------------------------------------------------------
        def t_pack():
            if not gr_intel.HAVE_ED25519:
                return True, "skipped (install 'cryptography' to test signed packs)"
            priv, pub = gr_intel.generate_keypair()
            sha = __import__("hashlib").sha256(b"selftest-sample").hexdigest()
            good = root / "good.grpack"
            good.write_text(gr_intel.sign_pack({"name": "selftest", "serial": 1, "hashes": [{"sha256": sha, "name": "x"}]}, priv))
            eng.intel.add_key(pub)
            info = eng.install_pack(good)
            doc = json.loads(good.read_text())
            doc["payload"] = doc["payload"][:-6] + "AAAAAA"
            bad = root / "bad.grpack"
            bad.write_text(json.dumps(doc))
            try:
                eng.install_pack(bad)
                rejected = False
            except gr_intel.PackError:
                rejected = True
            try:
                eng.install_pack(good)
                rolled = False
            except gr_intel.PackError:
                rolled = True
            return info["hashes"] == 1 and rejected and rolled, f"valid pack installed; tampered pack rejected={rejected}; rollback blocked={rolled}"
        check("Signed update packs: valid accepted, forged and rolled-back rejected", t_pack)

        def t_ultra_hooks():
            import gr_ultra
            sk, pk = "A" * 43 + "=", "B" * 43 + "="
            base = f"[Interface]\nPrivateKey = {sk}\nAddress = 10.0.0.2/32\nDNS = 1.1.1.1\n{{HOOK}}\n[Peer]\nPublicKey = {pk}\nEndpoint = 203.0.113.5:51820\nAllowedIPs = 0.0.0.0/0, ::/0\n"
            good = gr_ultra.parse_wg_conf(base.replace("{HOOK}", ""))
            refused = 0
            for hook in ("Post" + "Up = touch /tmp/x", "Pre" + "Up = id", "Post" + "Down = id"):
                try:
                    gr_ultra.parse_wg_conf(base.replace("{HOOK}", hook))
                except gr_ultra.UltraError:
                    refused += 1
            return good["full_tunnel"] and refused == 3, "a normal file is accepted; 3 of 3 files with command hooks are refused"
        check("Ultra Rook refuses config files that could run commands", t_ultra_hooks)

        def t_ultra_store():
            import gr_ultra
            priv, pub = "C" * 43 + "=", "D" * 43 + "="
            conf = f"[Interface]\nPrivateKey = {priv}\nAddress = 10.0.0.2/32\n[Peer]\nPublicKey = {pub}\nEndpoint = vpn.example.com:51820\nAllowedIPs = 0.0.0.0/0\n"
            prof = gr_ultra.Profiles(cfg, vault, root)
            e = prof.add("selftest", conf)
            raw = (prof.dir / f"{e['id']}.enc").read_bytes()
            ok = priv.encode() not in raw and priv in prof.load(e["id"])
            prof.remove(e["id"])
            return ok and not (prof.dir / f"{e['id']}.enc").exists(), "server keys are encrypted on disk and removed on request"
        check("Ultra Rook keeps server keys encrypted", t_ultra_store)

        def t_decompress():
            data = b"Sub Test()\r\n" * 600
            return gr_office.ovba_decompress(tk.ovba_compress(data)) == data, "VBA decompressor round-trip"
        check("VBA macro decompressor is exact", t_decompress)
    return results


def format_results(results):
    lines = [f"[{'PASS' if ok else 'FAIL'}] {name}\n        {detail}" for name, ok, detail in results]
    bad = sum(not ok for _, ok, _ in results)
    lines.append("")
    lines.append(f"{len(results) - bad}/{len(results)} checks passed." + ("" if not bad else f"  {bad} FAILED."))
    return "\n".join(lines)


if __name__ == "__main__":
    out = run_selftest()
    print(format_results(out))
    raise SystemExit(0 if all(ok for _, ok, _ in out) else 1)
