"""
Green Rook - Trust layer (new in 3.0).  Its only job is to stop false alarms on genuine software.

Version 2 judged a file by the words inside it. Windows itself (explorer.exe, shell32.dll, PowerShell ...) is full of
those words, because it is the software that legitimately *implements* them. So the scanner kept "finding" Windows.

The trust layer asks one extra question before a guess is shown to you:  "Is this file digitally signed by its maker,
and is the signature intact?"   On Windows it asks the operating system itself:
  * WinVerifyTrust        - the signature embedded in the file (Authenticode), and
  * the catalog database  - how Windows signs its own files (explorer.exe has no embedded signature).
A file that passes is not reported on guesses alone. Hard evidence (a known-bad fingerprint) is never overridden.

verify(path) -> (status, how)      status is TRUSTED, UNSIGNED or UNKNOWN (could not be checked on this system)
"""
import os
import threading

IS_WIN = os.name == "nt"
TRUSTED, UNSIGNED, UNKNOWN = "trusted", "unsigned", "unknown"
_cache, _lock = {}, threading.Lock()


def _win_verify_file(path: str) -> int:
    """WinVerifyTrust on one file. Returns the Windows status code (0 = signature valid and trusted)."""
    import ctypes
    from ctypes import wintypes

    class GUID(ctypes.Structure):
        _fields_ = [("d1", wintypes.DWORD), ("d2", wintypes.WORD), ("d3", wintypes.WORD), ("d4", ctypes.c_ubyte * 8)]

    class FILE_INFO(ctypes.Structure):
        _fields_ = [("cbStruct", wintypes.DWORD), ("pcwszFilePath", wintypes.LPCWSTR), ("hFile", wintypes.HANDLE),
                    ("pgKnownSubject", ctypes.c_void_p)]

    class DATA(ctypes.Structure):
        _fields_ = [("cbStruct", wintypes.DWORD), ("pPolicyCallbackData", ctypes.c_void_p), ("pSIPClientData", ctypes.c_void_p),
                    ("dwUIChoice", wintypes.DWORD), ("fdwRevocationChecks", wintypes.DWORD), ("dwUnionChoice", wintypes.DWORD),
                    ("pFile", ctypes.POINTER(FILE_INFO)), ("dwStateAction", wintypes.DWORD), ("hWVTStateData", wintypes.HANDLE),
                    ("pwszURLReference", wintypes.LPCWSTR), ("dwProvFlags", wintypes.DWORD), ("dwUIContext", wintypes.DWORD),
                    ("pSignatureSettings", ctypes.c_void_p)]

    action = GUID(0x00AAC56B, 0xCD44, 0x11D0, (ctypes.c_ubyte * 8)(0x8C, 0xC2, 0x00, 0xC0, 0x4F, 0xC2, 0x95, 0xEE))
    fi = FILE_INFO(ctypes.sizeof(FILE_INFO), path, None, None)
    wd = DATA()
    wd.cbStruct = ctypes.sizeof(DATA)
    wd.dwUIChoice = 2            # WTD_UI_NONE: never show a window
    wd.fdwRevocationChecks = 0   # WTD_REVOKE_NONE
    wd.dwUnionChoice = 1         # WTD_CHOICE_FILE
    wd.pFile = ctypes.pointer(fi)
    wd.dwStateAction = 1         # WTD_STATEACTION_VERIFY
    wd.dwProvFlags = 0x1000      # WTD_CACHE_ONLY_URL_RETRIEVAL: do not go online
    fn = ctypes.windll.wintrust.WinVerifyTrust
    fn.argtypes = [wintypes.HWND, ctypes.POINTER(GUID), ctypes.c_void_p]
    fn.restype = ctypes.c_long
    rc = fn(None, ctypes.byref(action), ctypes.byref(wd))
    wd.dwStateAction = 2         # WTD_STATEACTION_CLOSE
    fn(None, ctypes.byref(action), ctypes.byref(wd))
    return rc & 0xFFFFFFFF


def _win_catalog_signed(path: str) -> bool:
    """Is this exact file listed in a signed Windows security catalog? (How Windows signs its own files.)"""
    import ctypes
    from ctypes import wintypes

    class CATALOG_INFO(ctypes.Structure):
        _fields_ = [("cbStruct", wintypes.DWORD), ("wszCatalogFile", ctypes.c_wchar * 260)]

    wt, k32 = ctypes.windll.wintrust, ctypes.windll.kernel32
    k32.CreateFileW.restype = wintypes.HANDLE
    k32.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
    k32.CloseHandle.argtypes = [wintypes.HANDLE]
    wt.CryptCATAdminAcquireContext2.argtypes = [ctypes.POINTER(wintypes.HANDLE), ctypes.c_void_p, wintypes.LPCWSTR, ctypes.c_void_p, wintypes.DWORD]
    wt.CryptCATAdminCalcHashFromFileHandle2.argtypes = [wintypes.HANDLE, wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD), ctypes.c_void_p, wintypes.DWORD]
    wt.CryptCATAdminEnumCatalogFromHash.restype = wintypes.HANDLE
    wt.CryptCATAdminEnumCatalogFromHash.argtypes = [wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD, ctypes.c_void_p]
    wt.CryptCATCatalogInfoFromContext.argtypes = [wintypes.HANDLE, ctypes.POINTER(CATALOG_INFO), wintypes.DWORD]
    wt.CryptCATAdminReleaseCatalogContext.argtypes = [wintypes.HANDLE, wintypes.HANDLE, wintypes.DWORD]
    wt.CryptCATAdminReleaseContext.argtypes = [wintypes.HANDLE, wintypes.DWORD]
    invalid = wintypes.HANDLE(-1).value
    for algo in ("SHA256", "SHA1"):
        admin = wintypes.HANDLE()
        if not wt.CryptCATAdminAcquireContext2(ctypes.byref(admin), None, algo, None, 0):
            continue
        hfile = None
        try:
            hfile = k32.CreateFileW(path, 0x80000000, 0x7, None, 3, 0, None)     # read, share all, open existing
            if not hfile or hfile == invalid:
                hfile = None
                continue
            size = wintypes.DWORD(0)
            wt.CryptCATAdminCalcHashFromFileHandle2(admin, hfile, ctypes.byref(size), None, 0)
            if not size.value:
                continue
            buf = (ctypes.c_ubyte * size.value)()
            if not wt.CryptCATAdminCalcHashFromFileHandle2(admin, hfile, ctypes.byref(size), buf, 0):
                continue
            cat = wt.CryptCATAdminEnumCatalogFromHash(admin, buf, size.value, 0, None)
            if not cat:
                continue
            try:
                info = CATALOG_INFO()
                info.cbStruct = ctypes.sizeof(CATALOG_INFO)
                if wt.CryptCATCatalogInfoFromContext(cat, ctypes.byref(info), 0) and _win_verify_file(info.wszCatalogFile) == 0:
                    return True                      # the catalog that lists this file is itself validly signed
            finally:
                wt.CryptCATAdminReleaseCatalogContext(admin, cat, 0)
        finally:
            if hfile:
                k32.CloseHandle(hfile)
            wt.CryptCATAdminReleaseContext(admin, 0)
    return False


def _verify_uncached(path: str):
    if not IS_WIN:
        return UNKNOWN, ""
    try:
        if _win_verify_file(path) == 0:
            return TRUSTED, "valid digital signature (Authenticode)"
    except Exception:
        return UNKNOWN, ""
    try:
        if _win_catalog_signed(path):
            return TRUSTED, "listed in a signed Windows security catalog"
    except Exception:
        return UNKNOWN, ""
    return UNSIGNED, ""


def verify(path: str):
    """(status, how). Cached per file + size + modified time, so a changed file is always checked again."""
    try:
        st = os.stat(path)
        key = (os.path.abspath(path).lower() if IS_WIN else os.path.abspath(path), st.st_size, st.st_mtime_ns)
    except OSError:
        return UNKNOWN, ""
    with _lock:
        if key in _cache:
            return _cache[key]
    res = _verify_uncached(path)
    with _lock:
        if len(_cache) > 5000:
            _cache.clear()
        _cache[key] = res
    return res


def is_trusted(path: str) -> bool:
    return verify(path)[0] == TRUSTED
