"""
Green Rook - visual toolkit: colours, rounded buttons, clean toggles, drawn icons, notifications and dialogs.
Everything is drawn with plain Tk (no image files, no extra packages), so it works the same on Windows, Mac and Linux.
"""
import math
import time
import tkinter as tk
import tkinter.font as tkfont
from tkinter import ttk

from gr_core import IS_MAC, IS_WIN

# ------------------------------------------------------------------ palette
BG, SIDE, CARD, CARD2, LINE = "#09140f", "#07100c", "#102018", "#192c21", "#2a4936"
FG, MUTED, FAINT = "#eaf6ee", "#a5bead", "#789180"
ACCENT, ACCENT_D = "#43df88", "#259b59"
GOOD, WARN, BAD, INFO = "#3ddc84", "#f5b942", "#ef5350", "#5aa9e6"
GOOD_BG, WARN_BG, BAD_BG, SELECTED = "#17281f", "#2a2619", "#2a1c1c", "#1c5a3a"
FONT = "Segoe UI" if IS_WIN else ("Helvetica Neue" if IS_MAC else "DejaVu Sans")
MONO = "Consolas" if IS_WIN else ("Menlo" if IS_MAC else "DejaVu Sans Mono")

ROOK = [(12, 96), (12, 86), (22, 86), (28, 72), (33, 40), (24, 36), (24, 8), (38, 8), (38, 18), (45, 18), (45, 8),
        (55, 8), (55, 18), (62, 18), (62, 8), (76, 8), (76, 36), (67, 40), (72, 72), (78, 86), (88, 86), (88, 96)]
ROOK_HI = [(12, 96), (12, 86), (22, 86), (28, 72), (33, 40), (24, 36), (24, 8), (34, 8), (34, 96)]


def blend(c1, c2, t):
    a = [int(c1[i:i + 2], 16) for i in (1, 3, 5)]
    b = [int(c2[i:i + 2], 16) for i in (1, 3, 5)]
    return "#%02x%02x%02x" % tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def rook_pts(pts, x, y, size):
    s = size / 100.0
    return [v for px, py in pts for v in (x + px * s, y + py * s)]


def draw_rook(cv, x, y, size, fill, hi=None, outline="", width=1, tags=()):
    ids = [cv.create_polygon(rook_pts(ROOK, x, y, size), fill=fill, outline=outline, width=width, joinstyle="round", tags=tags)]
    if hi:
        ids.append(cv.create_polygon(rook_pts(ROOK_HI, x, y, size), fill=hi, outline="", tags=tags))
    return ids


def rrect(cv, x1, y1, x2, y2, r, **kw):
    """Rounded rectangle on a canvas."""
    pts = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]
    return cv.create_polygon(pts, smooth=True, **kw)


# ------------------------------------------------------------------ icons (drawn, 24x24 design grid)
def draw_icon(cv, name, cx, cy, s, color, w=2, tags=()):
    u = s / 24.0
    ox, oy = cx - s / 2, cy - s / 2

    def P(*xy):
        return [ox + v * u if i % 2 == 0 else oy + v * u for i, v in enumerate(xy)]
    kw = dict(fill=color, width=w, capstyle="round", joinstyle="round", tags=tags)
    ok = dict(outline=color, width=w, tags=tags)

    def line(*xy):
        cv.create_line(*P(*xy), **kw)

    def poly(*xy):
        cv.create_polygon(*P(*xy), fill="", joinstyle="round", **ok)

    def oval(x1, y1, x2, y2, filled=False):
        cv.create_oval(*P(x1, y1, x2, y2), **({"fill": color, "outline": color, "width": 1, "tags": tags} if filled else {"fill": "", **ok}))
    if name == "home":
        line(3, 12, 12, 4, 21, 12)
        line(5.5, 10.5, 5.5, 20, 10, 20, 10, 14.5, 14, 14.5, 14, 20, 18.5, 20, 18.5, 10.5)
    elif name == "scan":
        oval(4, 4, 16, 16)
        line(14.5, 14.5, 20.5, 20.5)
    elif name == "shield":
        poly(12, 3, 20, 6, 20, 12, 12, 21, 4, 12, 4, 6)
        line(8.5, 12, 11, 14.5, 15.5, 9.5)
    elif name == "trash":
        line(4, 7, 20, 7)
        line(9, 7, 9, 4, 15, 4, 15, 7)
        poly(6, 7, 7, 20, 17, 20, 18, 7)
        line(10, 10.5, 10, 16.5)
        line(14, 10.5, 14, 16.5)
    elif name == "globe":
        oval(3, 3, 21, 21)
        oval(8, 3, 16, 21)
        line(3, 12, 21, 12)
    elif name == "camera":
        poly(3, 7, 8, 7, 9.5, 4.5, 14.5, 4.5, 16, 7, 21, 7, 21, 19, 3, 19)
        oval(8.5, 9.5, 15.5, 16.5)
    elif name == "block":
        oval(3, 3, 21, 21)
        line(6, 6, 18, 18)
    elif name == "list":
        for y in (6, 12, 18):
            line(9, y, 20, y)
            oval(3.5, y - 1.2, 6, y + 1.3, True)
    elif name == "pulse":
        line(2, 12, 7, 12, 9.5, 5, 13.5, 19, 16, 12, 22, 12)
    elif name == "clock":
        oval(3, 3, 21, 21)
        line(12, 7, 12, 12, 16, 14)
    elif name == "sliders":
        for y, kx in ((7, 8), (12, 15), (17, 10)):
            line(4, y, 20, y)
            oval(kx - 2.3, y - 2.3, kx + 2.3, y + 2.3, True)
    elif name == "lock":
        poly(5, 11, 19, 11, 19, 21, 5, 21)
        cv.create_arc(*P(8, 3, 16, 17), start=0, extent=180, style="arc", outline=color, width=w, tags=tags)
        line(8, 10, 8, 8)
        line(16, 10, 16, 8)
    elif name == "folder":
        poly(3, 6, 9.5, 6, 11.5, 8.5, 21, 8.5, 21, 19, 3, 19)
    elif name == "file":
        poly(6, 3, 14, 3, 19, 8, 19, 21, 6, 21)
        line(14, 3, 14, 8, 19, 8)
    elif name == "check":
        line(5, 12.5, 10, 17.5, 19.5, 7)
    elif name == "warn":
        poly(12, 3, 22, 20, 2, 20)
        line(12, 9.5, 12, 14)
        oval(11.2, 16, 12.8, 17.6, True)
    elif name == "usb":
        poly(8, 11, 16, 11, 16, 22, 8, 22)
        poly(9.5, 3, 14.5, 3, 14.5, 11, 9.5, 11)
    elif name == "eye":
        oval(2, 6.5, 22, 17.5)
        oval(9, 9, 15, 15, True)
    elif name == "vpn":
        poly(12, 2.5, 20.5, 6, 20.5, 12.5, 12, 21.5, 3.5, 12.5, 3.5, 6)
        oval(8, 8, 16, 16)
        line(12, 8, 12, 16)
        line(8, 12, 16, 12)
    elif name == "bolt":
        poly(13.5, 2, 5, 13.5, 11, 13.5, 10, 22, 19, 10, 13, 10)
    elif name == "refresh":
        cv.create_arc(*P(4, 4, 20, 20), start=40, extent=270, style="arc", outline=color, width=w, tags=tags)
        line(17.5, 2.5, 18.5, 7.5, 13.5, 7)
    elif name == "plus":
        line(12, 5, 12, 19)
        line(5, 12, 19, 12)
    else:
        oval(4, 4, 20, 20)


# ------------------------------------------------------------------ widgets
class Btn(tk.Canvas):
    """Rounded button. kind: primary | danger | neutral | ghost | warn.  icon: name from draw_icon (optional)."""
    KINDS = {"primary": (ACCENT_D, ACCENT, "#052012", ""), "danger": ("#c94743", "#e55c54", "#ffffff", ""),
             "neutral": (CARD2, "#284637", FG, LINE), "ghost": (BG, CARD2, FG, LINE),
             "warn": ("#b77a12", "#d79a2b", "#1c1505", "")}

    def __init__(self, master, text, command, kind="primary", icon=None, big=False, size=None):
        # `big` stays supported for existing pages; new pages can use small / medium / large.
        size = size or ("large" if big else "medium")
        self.size = size
        sizes = {"small": (9, 32, 16, 28, 8), "medium": (10, 40, 18, 34, 10), "large": (12, 52, 24, 44, 12)}
        fs, h, isz, pad, radius = sizes.get(size, sizes["medium"])
        self.f = tkfont.Font(family=FONT, size=fs, weight="bold")
        self.text, self.command, self.kind, self.enabled = text, command, kind, True
        self.loading = False
        self._normal_text = text
        iw = isz + 10 if icon else 0
        w = self.f.measure(text) + pad + iw
        super().__init__(master, width=w, height=h, bg=master["bg"], highlightthickness=2, highlightbackground=master["bg"],
                         highlightcolor=ACCENT, cursor="hand2", takefocus=1)
        self.w, self.h = w, h
        self.base, self.hover, self.fg, border = self.KINDS[kind]
        self.shape = rrect(self, 2, 2, w - 2, h - 2, radius, fill=self.base, outline=border)
        left = (w - self.f.measure(text) - iw) / 2
        self.icon_ids = []
        if icon:
            n0 = len(self.find_all())
            draw_icon(self, icon, left + isz / 2, h / 2, isz, self.fg, 2)
            self.icon_ids = list(self.find_all())[n0:]
        self.label = self.create_text(left + iw, h / 2, text=text, fill=self.fg, font=self.f, anchor="w")
        self.bind("<Enter>", lambda e: self._paint(self.hover))
        self.bind("<Leave>", lambda e: self._paint(self.base))
        self.bind("<ButtonPress-1>", lambda e: self._paint(blend(self.base, "#000000", 0.25)))
        self.bind("<ButtonRelease-1>", self._release)
        self.bind("<Return>", lambda e: self._fire())
        self.bind("<space>", lambda e: self._fire())

    def _paint(self, col):
        if self.enabled:
            self.itemconfig(self.shape, fill=col)

    def _release(self, e):
        if self.enabled and 0 <= e.x <= self.w and 0 <= e.y <= self.h:
            self._paint(self.hover)
            self.command()
        else:
            self._paint(self.base)

    def _fire(self):
        if self.enabled:
            self.command()

    def set_loading(self, value, text=None):
        """Show a compact working label and prevent duplicate clicks while an action runs."""
        if value and not self.loading:
            self._normal_text = self.text
        self.loading = bool(value)
        shown = (text or "Working…") if self.loading else self._normal_text
        self.text = shown
        self.itemconfig(self.label, text=shown)
        self.set_enabled(not self.loading)
        return self

    def set_enabled(self, v):
        self.enabled = v
        self.itemconfig(self.shape, fill=self.base if v else "#16251d")
        dim = self.fg if v else "#5d7a69"
        self.itemconfig(self.label, fill=dim)
        for i in self.icon_ids:
            for opt in ("fill", "outline"):
                try:
                    if self.itemcget(i, opt):
                        self.itemconfig(i, **{opt: dim})
                except tk.TclError:
                    pass
        self.config(cursor="hand2" if v else "arrow")


class Switch(tk.Canvas):
    """Keyboard-accessible toggle. command(new_value) may return False to refuse the change."""

    def __init__(self, master, value, command, bg=None):
        self.bg0 = bg or master["bg"]
        super().__init__(master, width=54, height=34, bg=self.bg0, highlightthickness=2,
                         highlightbackground=self.bg0, highlightcolor=ACCENT, cursor="hand2", takefocus=1)
        self.value, self.command = bool(value), command
        self.bind("<Button-1>", self.toggle)
        self.bind("<space>", self.toggle)
        self.bind("<Return>", self.toggle)
        self.bind("<FocusIn>", lambda e: self.config(highlightbackground=ACCENT))
        self.bind("<FocusOut>", lambda e: self.config(highlightbackground=self.bg0))
        self.draw()

    def draw(self):
        self.delete("all")
        rrect(self, 2, 5, 52, 29, 12, fill=ACCENT_D if self.value else "#43564a", outline="")
        x = 40 if self.value else 14
        self.create_oval(x - 10, 7, x + 10, 27, fill="#ffffff", outline="")

    def set(self, v):
        self.value = bool(v)
        self.draw()

    def toggle(self, _=None):
        self.focus_set()
        self.value = not self.value
        self.draw()
        if self.command(self.value) is False:
            self.value = not self.value
            self.draw()


class Seg(tk.Frame):
    """Segmented choice, e.g. Block / Ask me / Log only / Off."""
    COL = {"block": BAD, "ask": WARN, "audit": INFO, "off": "#6b7d72", "tor": ACCENT, "wg": ACCENT}
    NAME = {"block": "Block", "ask": "Ask me", "audit": "Log only", "off": "Off", "tor": "Free (Tor)", "wg": "My own server"}

    def __init__(self, master, value, command, modes, labels=None):
        super().__init__(master, bg=CARD)
        self.value, self.command, self.labels = value, command, {}
        self.names = dict(self.NAME)
        self.names.update(labels or {})
        for m in modes:
            lb = tk.Label(self, text=self.names.get(m, str(m).title()), font=(FONT, 9, "bold"), padx=12, pady=6, cursor="hand2",
                          takefocus=1, highlightthickness=1, highlightbackground=CARD2, highlightcolor=ACCENT)
            lb.pack(side="left", padx=2)
            lb.bind("<Button-1>", lambda e, mm=m: self.pick(mm))
            lb.bind("<space>", lambda e, mm=m: self.pick(mm))
            lb.bind("<Return>", lambda e, mm=m: self.pick(mm))
            self.labels[m] = lb
        self.paint()

    def paint(self):
        for m, lb in self.labels.items():
            on = m == self.value
            color = self.COL.get(m, ACCENT)
            lb.config(bg=color if on else CARD2, fg="#06100a" if on else MUTED)

    def pick(self, m):
        if m != self.value and self.command(m) is not False:
            self.value = m
            self.paint()


class ScrollFrame(tk.Frame):
    def __init__(self, master, bg=BG):
        super().__init__(master, bg=bg)
        self.cv = tk.Canvas(self, bg=bg, highlightthickness=0)
        sb = ttk.Scrollbar(self, orient="vertical", command=self.cv.yview)
        self.inner = tk.Frame(self.cv, bg=bg)
        win = self.cv.create_window((0, 0), window=self.inner, anchor="nw")
        self.cv.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.cv.pack(side="left", fill="both", expand=True)
        self.inner.bind("<Configure>", lambda e: self.cv.configure(scrollregion=self.cv.bbox("all")))
        self.cv.bind("<Configure>", lambda e: self.cv.itemconfig(win, width=e.width))
        # One global wheel handler per frame that checks where the pointer is. (Binding Enter/Leave on the frame
        # fails: moving onto any child widget counts as 'leaving', so scrolling would die over most of the page.)
        self.bind_all("<MouseWheel>", self._on_wheel, add="+")
        self.bind_all("<Button-4>", lambda e: self._on_wheel(e, -1), add="+")
        self.bind_all("<Button-5>", lambda e: self._on_wheel(e, 1), add="+")

    def _on_wheel(self, e, direction=None):
        try:
            w = self.winfo_containing(e.x_root, e.y_root)
        except (KeyError, tk.TclError):
            return
        while w is not None:
            if w is self:
                d = direction if direction is not None else (-1 if e.delta > 0 else 1)
                self.cv.yview_scroll(d, "units")
                return
            w = w.master


class Hero(tk.Canvas):
    """The big rook. It pulses, changes colour with your protection state and sweeps while scanning."""
    PAL = {"ok": ("#2ea05c", "#6fe19a", GOOD), "warn": ("#c98a1c", "#f5c35a", WARN), "bad": ("#c0392b", "#ff8c7e", BAD)}

    def __init__(self, master, bg=CARD, k=0.78):
        self.k = k
        super().__init__(master, width=int(210 * k), height=int(236 * k), bg=bg, highlightthickness=0)
        self.bg0, self.state, self.phase, self.scanning, self.sy = bg, "ok", 0.0, False, 0.0
        self.rings = [self.create_oval(0, 0, 0, 0, outline=bg, width=3) for _ in range(4)]
        self.body, self.hi = draw_rook(self, 30 * k, 50 * k, 150 * k, "#2ea05c", "#6fe19a", "#06100a", 3)
        pts = lambda p: rook_pts(p, 30 * k, 50 * k, 150 * k)  # noqa: E731
        self.check = self.create_line(*pts([(38, 58), (47, 68), (64, 50)]), fill="white", width=9 * k, capstyle="round", joinstyle="round")
        self.bang = self.create_line(*pts([(50, 48), (50, 66)]), fill="white", width=9 * k, capstyle="round", state="hidden")
        self.dot = self.create_oval(*pts([(46, 70), (54, 78)]), fill="white", outline="", state="hidden")
        self.scan = self.create_line(0, 0, 0, 0, fill="#c9ffe0", width=3, state="hidden")
        self._job = None
        self.animate()

    def destroy(self):
        if self._job:
            try:
                self.after_cancel(self._job)
            except Exception:
                pass
        super().destroy()

    def set_state(self, st):
        self.state = st
        body, hi, _ = self.PAL[st]
        self.itemconfig(self.body, fill=body)
        self.itemconfig(self.hi, fill=hi)
        ok = st == "ok"
        self.itemconfig(self.check, state="normal" if ok else "hidden")
        self.itemconfig(self.bang, state="hidden" if ok else "normal")
        self.itemconfig(self.dot, state="hidden" if ok else "normal")

    def animate(self):
        k = self.k
        self.phase += 0.11
        col = self.PAL[self.state][2]
        for i, r in enumerate(self.rings):
            rad = (70 + i * 9) * k
            self.coords(r, 105 * k - rad, 124 * k - rad, 105 * k + rad, 124 * k + rad)
            t = (0.5 + 0.5 * math.sin(self.phase - i * 0.8)) * (0.34 - i * 0.07) + 0.04
            self.itemconfig(r, outline=blend(self.bg0, col, t))
        if self.scanning:
            self.sy = (self.sy + 5 * k) % (140 * k)
            y = 56 * k + self.sy
            self.coords(self.scan, 34 * k, y, 176 * k, y)
            self.itemconfig(self.scan, state="normal")
        else:
            self.itemconfig(self.scan, state="hidden")
        self._job = self.after(70, self.animate)


def card(master, **kw):
    """A bordered panel."""
    return tk.Frame(master, bg=CARD, padx=kw.pop("padx", 20), pady=kw.pop("pady", 16), highlightthickness=1,
                    highlightbackground=LINE, **kw)


def label(master, text, size=10, bold=False, color=FG, bg=None, **kw):
    return tk.Label(master, text=text, font=(FONT, size, "bold" if bold else "normal"), fg=color, bg=bg or master["bg"], **kw)


def icon_badge(master, name, color, size=44, bg=None):
    """A round tinted badge holding an icon."""
    bg = bg or master["bg"]
    cv = tk.Canvas(master, width=size, height=size, bg=bg, highlightthickness=0)
    cv.create_oval(1, 1, size - 1, size - 1, fill=blend(bg, color, 0.16), outline="")
    draw_icon(cv, name, size / 2, size / 2, size * 0.5, color, 2)
    return cv


def status_badge(master, text, level="info", bg=None):
    """Compact status label; every color is paired with readable status text."""
    bg = bg or master["bg"]
    color = {"good": GOOD, "warn": WARN, "bad": BAD, "info": INFO, "neutral": MUTED}.get(level, INFO)
    tint = blend(bg, color, 0.15)
    return tk.Label(master, text=text, font=(FONT, 9, "bold"), fg=color, bg=tint, padx=9, pady=4,
                    highlightthickness=1, highlightbackground=blend(bg, color, 0.35))


class ScanRook(tk.Canvas):
    """A rook silhouette that fills from the base as scan activity increases."""
    BASE = "#173326"
    FILL = "#43df88"
    EDGE = "#3d7955"

    def __init__(self, master, size=176, bg=CARD):
        super().__init__(master, width=size, height=size, bg=bg, highlightthickness=0, takefocus=0)
        self.size, self.bg0 = size, bg
        self.value, self.scanning, self.phase, self._job = 0.0, False, 0.0, None
        self.scale = size / 160.0
        self.ox, self.oy = 19 * self.scale, 14 * self.scale
        self.body_size = 122 * self.scale
        self.create_oval(size*.14, size*.09, size*.86, size*.91, outline=blend(bg, self.FILL, .12), width=2)
        draw_rook(self, self.ox, self.oy, self.body_size, self.BASE, None, self.EDGE, 2)
        self._fill_tag = "scan-fill"
        self._scan_tag = "scan-sweep"
        self._job = None
        self.draw_fill()

    def _intervals(self, local_y):
        pts = [(x, y) for x, y in ROOK]
        cross = []
        for (x1, y1), (x2, y2) in zip(pts, pts[1:] + pts[:1]):
            if (y1 <= local_y < y2) or (y2 <= local_y < y1):
                cross.append(x1 + (local_y - y1) * (x2 - x1) / (y2 - y1))
        cross.sort()
        return [(cross[i], cross[i + 1]) for i in range(0, len(cross) - 1, 2)]

    def set_progress(self, value):
        self.value = max(0.0, min(1.0, float(value)))
        self.draw_fill()

    def set_activity(self, count):
        # The scanner has no reliable total count. This is a visual activity fill, not a percent-complete claim.
        value = min(.92, .08 + .84 * (1.0 - math.exp(-max(0, int(count)) / 1100.0)))
        if value > self.value:
            self.set_progress(value)

    def draw_fill(self):
        self.delete(self._fill_tag)
        step = max(1.3, self.scale * 1.8)
        threshold = 96.0 * (1.0 - self.value)
        y = 0.0
        while y <= 96.0:
            for x1, x2 in self._intervals(y + .15):
                color = self.FILL if y >= threshold else self.BASE
                self.create_line(self.ox + x1*self.body_size/100, self.oy + y*self.body_size/100,
                                 self.ox + x2*self.body_size/100, self.oy + y*self.body_size/100,
                                 fill=color, width=step, tags=(self._fill_tag,))
            y += 1.4

    def set_scanning(self, value):
        self.scanning = bool(value)
        self.delete(self._scan_tag)
        if self.scanning and self._job is None:
            self.animate()
        elif not self.scanning and self._job:
            try:
                self.after_cancel(self._job)
            except tk.TclError:
                pass
            self._job = None
            self.delete(self._scan_tag)

    def animate(self):
        if not self.scanning or not self.winfo_exists():
            self._job = None
            return
        self.delete(self._scan_tag)
        self.phase = (self.phase + 2.4) % 96
        for x1, x2 in self._intervals(self.phase):
            self.create_line(self.ox + x1*self.body_size/100, self.oy + self.phase*self.body_size/100,
                             self.ox + x2*self.body_size/100, self.oy + self.phase*self.body_size/100,
                             fill="#d5ffe5", width=2, tags=(self._scan_tag,))
        self._job = self.after(90, self.animate)

    def destroy(self):
        if self._job:
            try:
                self.after_cancel(self._job)
            except tk.TclError:
                pass
        super().destroy()


# ------------------------------------------------------------------ notifications and dialogs
class Toast(tk.Toplevel):
    live = []
    TTL = 7.0

    def __init__(self, app, level, title, msg):
        super().__init__(app)
        if len(Toast.live) >= 3:
            Toast.live[0].close(reposition=False)
        self.overrideredirect(True)
        self.attributes("-topmost", True)
        self._closed = False
        self._started = time.monotonic()
        col = {"bad": BAD, "warn": WARN, "info": INFO, "good": GOOD}.get(level, INFO)
        f = tk.Frame(self, bg=CARD, highlightbackground=blend(CARD, col, .6), highlightthickness=1, padx=13, pady=10)
        f.pack(fill="x")
        icon = "warn" if level in ("bad", "warn") else ("check" if level == "good" else "pulse")
        icon_badge(f, icon, col, 36, CARD).pack(side="left", padx=(0, 10))
        t = tk.Frame(f, bg=CARD)
        t.pack(side="left", fill="x", expand=True)
        label(t, title, 10, True, col).pack(anchor="w")
        label(t, msg, 9, wraplength=300, justify="left").pack(anchor="w")
        self.timer = tk.Canvas(self, height=3, bg=CARD, highlightthickness=0)
        self.timer.pack(fill="x", padx=13, pady=(0, 8))
        self.update_idletasks()
        self.timer_w = max(80, self.winfo_reqwidth() - 26)
        self.timer.configure(width=self.timer_w)
        self.timer_rect = self.timer.create_rectangle(0, 0, self.timer_w, 3, fill=col, outline="")
        Toast.live.append(self)
        Toast._reposition()
        self._tick()

    @classmethod
    def _reposition(cls):
        live = [t for t in cls.live if not t._closed]
        if not live:
            return
        bottom = live[-1].winfo_screenheight() - 70
        for toast in reversed(live):
            try:
                toast.update_idletasks()
                w, h = toast.winfo_reqwidth(), toast.winfo_reqheight()
                x = max(0, toast.winfo_screenwidth() - w - 24)
                bottom -= h
                toast.geometry(f"+{x}+{max(0, bottom)}")
                bottom -= 10
            except tk.TclError:
                pass

    def _tick(self):
        if self._closed:
            return
        left = max(0.0, 1.0 - (time.monotonic() - self._started) / self.TTL)
        try:
            self.timer.coords(self.timer_rect, 0, 0, self.timer_w * left, 3)
        except tk.TclError:
            return
        if left <= 0:
            self.close()
        else:
            self.after(100, self._tick)

    def close(self, reposition=True):
        if self._closed:
            return
        self._closed = True
        if self in Toast.live:
            Toast.live.remove(self)
        try:
            self.destroy()
        except tk.TclError:
            pass
        if reposition:
            Toast._reposition()


class PromptDialog(tk.Toplevel):
    """The question window shown when a guard needs a decision. Plain words, one clear default."""

    def __init__(self, app, prompt):
        super().__init__(app)
        self.app, self.p, self.left, self.done = app, prompt, prompt.timeout, False
        self.title(prompt.title)
        self.configure(bg=CARD)
        self.attributes("-topmost", True)
        self.resizable(False, False)
        self.protocol("WM_DELETE_WINDOW", lambda: self.finish(getattr(prompt, "fallback", prompt.default), False))
        self.bind("<Escape>", lambda e: self.finish(getattr(prompt, "fallback", prompt.default), False))
        self.bind("<Return>", lambda e: self.finish(getattr(prompt, "fallback", prompt.default), True))
        body = tk.Frame(self, bg=CARD, padx=28, pady=24)
        body.pack()
        top = tk.Frame(body, bg=CARD)
        top.pack(fill="x")
        icon_badge(top, "warn", WARN, 52, CARD).pack(side="left", padx=(0, 16))
        label(top, prompt.headline, 14, True, WARN, wraplength=430, justify="left").pack(side="left", anchor="w")
        grid = tk.Frame(body, bg=CARD)
        grid.pack(fill="x", pady=14)
        for i, (k, v) in enumerate(prompt.details):
            label(grid, k, 9, color=MUTED).grid(row=i, column=0, sticky="nw", padx=(0, 16), pady=3)
            label(grid, v, 10, wraplength=420, justify="left").grid(row=i, column=1, sticky="w", pady=3)
        self.count = label(body, "", 9, color=MUTED)
        self.count.pack(anchor="w", pady=(0, 12))
        row = tk.Frame(body, bg=CARD)
        row.pack(anchor="e")
        for oid, text, style in prompt.options:
            Btn(row, text, lambda o=oid: self.finish(o, True), style).pack(side="left", padx=5)
        self.update_idletasks()
        w, h = self.winfo_reqwidth(), self.winfo_reqheight()
        self.geometry(f"+{(self.winfo_screenwidth() - w) // 2}+{(self.winfo_screenheight() - h) // 3}")
        self.bell()
        self.tick()

    def tick(self):
        if self.done:
            return
        fb = getattr(self.p, "fallback", self.p.default)
        dflt = next((l for i, l, s in self.p.options if i == fb), fb)
        self.count.config(text=f"If you do not answer in {self.left} seconds, Green Rook will choose:  {dflt}")
        if self.left <= 0:
            return self.finish(fb, False)
        self.left -= 1
        self.after(1000, self.tick)

    def finish(self, choice, answered=False):
        if self.done:
            return
        self.done = True
        self.p.answered = answered
        self.p.result = choice
        self.p.event.set()
        self.destroy()
        self.app.dialog_closed()
