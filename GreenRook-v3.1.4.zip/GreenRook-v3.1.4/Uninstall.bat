@echo off
title Uninstall Green Rook
cd /d "%~dp0"
py -3 -c "import sys" >nul 2>&1 && (py -3 gr_setup.py --uninstall) || python gr_setup.py --uninstall
pause
