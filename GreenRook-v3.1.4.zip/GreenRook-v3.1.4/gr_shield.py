"""Green Rook 3.0 Privacy Shield. Read-only checks; local-only password/cookie counts; reversible system fixes."""
import hashlib, hmac, ipaddress, json, os, re, secrets, shutil, socket, sqlite3, subprocess, tempfile, time
from pathlib import Path
from gr_core import AESGCM, BRANDS, IS_LINUX, IS_MAC, IS_WIN, atomic_write, data_dir, psutil, safe_delete, walk_limited
from gr_health import is_admin
NOWIN = {"creationflags": 0x08000000} if IS_WIN else {}
def _row(i,t,s,d,w="",steps=(),fixes=(),data=None): return {"id":i,"title":t,"status":s,"detail":d,"why":w,"steps":list(steps),"fixes":list(fixes),"data":data}
def _run(cmd,timeout=25):
    try:
        r=subprocess.run(cmd,capture_output=True,text=True,timeout=timeout,errors="ignore",**NOWIN); return r.returncode,(r.stdout or "")+(r.stderr or "")
    except Exception as e:return -1,str(e)
def _reg(path,name,hive=None):
    import winreg
    try:
        with winreg.OpenKey(hive or winreg.HKEY_LOCAL_MACHINE,path) as k:return winreg.QueryValueEx(k,name)[0]
    except OSError:return None

# Browser privacy: query counts only. No password values are selected, decrypted, printed, or transmitted.
def browser_profiles(home=None,env=None):
    home=Path(home or Path.home()); env=os.environ if env is None else env
    if IS_WIN:
        la=Path(env.get("LOCALAPPDATA") or home/"AppData/Local"); ra=Path(env.get("APPDATA") or home/"AppData/Roaming")
        roots=[("Chrome","chromium",la/"Google/Chrome/User Data"),("Edge","chromium",la/"Microsoft/Edge/User Data"),("Brave","chromium",la/"BraveSoftware/Brave-Browser/User Data"),("Firefox","firefox",ra/"Mozilla/Firefox/Profiles")]
    elif IS_MAC:
        b=home/"Library/Application Support"; roots=[("Chrome","chromium",b/"Google/Chrome"),("Edge","chromium",b/"Microsoft Edge"),("Brave","chromium",b/"BraveSoftware/Brave-Browser"),("Firefox","firefox",b/"Firefox/Profiles")]
    else:
        b=home/".config"; roots=[("Chrome","chromium",b/"google-chrome"),("Chromium","chromium",b/"chromium"),("Edge","chromium",b/"microsoft-edge"),("Brave","chromium",b/"BraveSoftware/Brave-Browser"),("Firefox","firefox",home/".mozilla/firefox")]
    out=[]
    for name,kind,root in roots:
        if not root.is_dir():continue
        try: subs=[p for p in root.iterdir() if p.is_dir()]
        except OSError:continue
        profs=[p for p in subs if p.name=="Default" or p.name.startswith("Profile ")] if kind=="chromium" else [p for p in subs if (p/"logins.json").exists() or (p/"cookies.sqlite").exists()]
        if kind=="chromium" and any((root/x).exists() for x in ("Login Data","Cookies")): profs.append(root)
        out.extend((name,kind,p) for p in profs)
    return out
def _db_count(path,sql):
    if not path.is_file():return 0
    d=tempfile.mkdtemp(prefix="gr_count_")
    try:
        copy=Path(d)/"c.db"; shutil.copy2(path,copy); con=sqlite3.connect(copy)
        try:return int(con.execute(sql).fetchone()[0])
        finally:con.close()
    except Exception:return None
    finally:shutil.rmtree(d,ignore_errors=True)
def _password_count(kind,p):
    if kind=="chromium":return _db_count(p/"Login Data","SELECT COUNT(*) FROM logins WHERE blacklisted_by_user=0")
    try:
        f=p/"logins.json"
        if not f.is_file():return 0
        # Count Firefox login objects without parsing or keeping encrypted login fields in Python objects.
        pat=re.compile(rb'\{\s*"id"\s*:'); count=0; carry=b""
        with f.open("rb") as stream:
            while True:
                chunk=stream.read(65536)
                if not chunk:break
                data=carry+chunk; matches=list(pat.finditer(data)); count+=sum(m.start()>=len(carry) for m in matches); carry=data[-32:]
        return count
    except Exception:return None
def _cookie_files(kind,p):
    if kind=="chromium":return [x for x in (p/"Network/Cookies",p/"Cookies") if x.is_file()]
    return [p/"cookies.sqlite"] if (p/"cookies.sqlite").is_file() else []
def _cookie_count(kind,p):
    fs=_cookie_files(kind,p); vals=[_db_count(f,"SELECT COUNT(*) FROM "+("cookies" if kind=="chromium" else "moz_cookies")) for f in fs]; vals=[v for v in vals if v is not None]
    return sum(vals) if vals or not fs else None
def check_passwords(profiles=None):
    profiles=browser_profiles() if profiles is None else profiles; per={}; unread=0
    for n,k,p in profiles:
        c=_password_count(k,p)
        if c is None:unread+=1
        elif c:per[n]=per.get(n,0)+c
    total=sum(per.values()); steps=["In your browser's Password settings, use its free password checkup and change leaked or reused passwords.","Use a unique password for every account and enable two-step login for email and banking.","Consider a reputable free password manager; do not share passwords with Green Rook."]
    if not profiles:return _row("passwords","Passwords saved in browsers","good","No browser profiles were found.",steps=steps)
    if not total:return _row("passwords","Passwords saved in browsers","info" if unread else "good","Could not read browser databases; close your browser and check again." if unread else "No saved passwords found.",steps=steps)
    return _row("passwords","Passwords saved in browsers","warn",f"{total} saved password(s) counted ({', '.join(f'{n}: {c}' for n,c in sorted(per.items()))}).", "Only the count is read. Password contents are never accessed or uploaded. Malware running as you may ask your browser to use saved logins.",steps,data={"total":total,"per":per})
def check_cookies(profiles=None):
    profiles=browser_profiles() if profiles is None else profiles; per={}
    unread=[]
    for n,k,p in profiles:
        c=_cookie_count(k,p)
        if c is None:unread.append(n)
        elif c:per[n]=per.get(n,0)+c
    total=sum(per.values()); fixes=[("clear_cookies","Clear cookies now")] if total else []
    detail=(f"{total:,} cookies counted ({', '.join(f'{n}: {c:,}' for n,c in sorted(per.items()))})" if total else "No stored cookies found")
    if unread:detail+=". Could not read: "+", ".join(sorted(set(unread)))+" (close the browser and check again)"
    return _row("cookies","Browser cookies","warn" if total else "info" if unread else "good",detail+".","Cookies can keep accounts signed in; malware that copies them may impersonate you.",["Clearing cookies signs you out of websites; saved passwords and bookmarks are not deleted.","You can configure your browser to clear cookies on exit."],fixes,{"total":total,"per":per})
def running_browsers():
    if not psutil:return None
    found=set()
    try:
        for p in psutil.process_iter(["name"]):
            n=(p.info.get("name") or "").lower().removesuffix(".exe")
            if any(n==x or n.startswith(x+"-") for x in ("chrome","msedge","brave","firefox","chromium")):found.add(n)
    except Exception:return None
    return found
def clear_cookies(profiles=None,running=None):
    profiles=browser_profiles() if profiles is None else profiles; running=running_browsers() if running is None else running; done=set(); skipped=set(); fails=0
    if running is None:return False,"Green Rook cannot check whether a browser is open. Install the optional process monitor or close browsers before clearing cookies."
    for name,k,p in profiles:
        if any(name.lower().split()[0] in x for x in running):skipped.add(name);continue
        for f in _cookie_files(k,p):
            for x in (f,Path(str(f)+"-journal"),Path(str(f)+"-wal"),Path(str(f)+"-shm")):
                try:
                    if x.exists():x.unlink();done.add(name)
                except OSError:fails+=1
    m=[]
    if done:m.append("Cookies cleared for: "+", ".join(sorted(done))+". You are signed out there.")
    if skipped:m.append("Close these browsers completely, then try again: "+", ".join(sorted(skipped))+".")
    if fails:m.append(f"{fails} file(s) could not be removed (possibly in use).")
    return bool(done) or not(skipped or fails)," ".join(m) or "No cookies needed clearing."

# Camera and microphone; the Windows privacy toggles apply to the current Windows user account.
CONSENT=r"Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore"
def _device(device):
    import winreg
    val=_reg(CONSENT+"\\"+device,"Value",winreg.HKEY_CURRENT_USER);n=0
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,CONSENT+"\\"+device+"\\NonPackaged") as k:n=winreg.QueryInfoKey(k)[0]
    except OSError:pass
    return val,n
def check_camera(cfg=None,cam_guard=None):
    on=bool(cfg.get("camera_guard")) if cfg else True; steps=["Keep Green Rook camera alerts on; it warns when an app uses the webcam.","Windows: Settings > Privacy & security > Camera and Microphone; review allowed apps.","Cover the lens when not in use."]
    fixes=[] if on else [("cam_guard_on","Turn on camera alerts")]
    if IS_MAC:
        return _row("camera","Webcam and microphone","info","Green Rook cannot read macOS device permissions yet.","Check macOS System Settings > Privacy & Security > Camera and Microphone.",steps)
    if not IS_WIN:
        using=[]
        try:using=[v[0] for v in (cam_guard.users().values() if cam_guard else [])]
        except Exception:pass
        detail="Camera alerts are "+("on." if on else "off.")
        if using:detail+=" In use now: "+", ".join(using)+"."
        return _row("camera","Webcam and microphone","warn" if not on or using else "good",detail,"Spyware may misuse these devices.",steps,fixes)
    try:cam,cn=_device("webcam");mic,mn=_device("microphone")
    except Exception:cam=mic=None;cn=mn=0
    use=[]
    try:use=[x[0] for x in cam_guard.users().values()] if cam_guard else []
    except Exception:pass
    desc=f"Camera: {'blocked' if cam=='Deny' else 'allowed'} ({cn} desktop apps seen). Microphone: {'blocked' if mic=='Deny' else 'allowed'} ({mn} desktop apps seen). Alerts: {'on' if on else 'off'}."
    if use:desc+=" In use now: "+", ".join(use)+"."
    fixes += [("cam_unblock" if cam=="Deny" else "cam_block","Allow camera again" if cam=="Deny" else "Block camera for all apps"),("mic_unblock" if mic=="Deny" else "mic_block","Allow microphone again" if mic=="Deny" else "Block microphone for all apps"),("cam_settings","Open Windows camera settings")]
    return _row("camera","Webcam and microphone","good" if on or (cam=="Deny" and mic=="Deny") else "warn",desc,"Spyware may misuse these devices.",steps,fixes)

# Remote access and exposed services.
TS=r"SYSTEM\CurrentControlSet\Control\Terminal Server"; RA=r"SYSTEM\CurrentControlSet\Control\Remote Assistance"
REMOTE={3389:"Remote Desktop",5900:"VNC",5985:"Windows Remote Management",23:"Telnet",22:"SSH"}
def listening_ports():
    out={}
    if not psutil:return out
    try:conns=psutil.net_connections(kind="inet")
    except Exception:return out
    for c in conns:
        try:
            if c.status==psutil.CONN_LISTEN and c.laddr and c.laddr.ip not in ("127.0.0.1","::1"):out.setdefault(c.laddr.port,"")
        except Exception:pass
    return out
def check_rdp(ports=None):
    ports=listening_ports() if ports is None else ports; ports_known=ports is not None; ports={} if ports is None else ports
    extra={p:n for p,n in ports.items() if p in REMOTE and p!=3389};steps=["If you do not use Remote Desktop, turn it off. If you need it, keep strong unique passwords and never expose it directly to the internet.","Be wary of callers asking you to install remote-access tools."]
    if IS_WIN:
        deny=_reg(TS,"fDenyTSConnections");nla=_reg(TS+r"\WinStations\RDP-Tcp","UserAuthentication");assist=_reg(RA,"fAllowToGetHelp");on=deny==0;ao=assist==1
        parts=["Remote Desktop is "+("on" if on else "off"),"Remote Assistance is "+("allowed" if ao else "off")]
        if on:parts.append("Network Level Authentication is "+("on" if nla==1 else "off or unknown"))
        if not ports_known:parts.append("Could not check for other listening remote-access services")
        if extra:parts.append("Other remote services listening: "+", ".join(f"{REMOTE[p]} ({p})" for p in extra))
        return _row("rdp","Remote access to this PC","bad" if on and nla!=1 else "warn" if on or ao or extra else "good",". ".join(parts)+".","Remote-control services can be abused to access your computer.",steps,[("rdp_off","Turn off remote access")] if on or ao else [])
    if not ports_known:return _row("rdp","Remote access to this PC","info","Could not inspect listening services (the optional process monitor is unavailable).","Review remote-access settings in your operating system.",steps)
    if extra:return _row("rdp","Remote access to this PC","warn","Listening: "+", ".join(f"{REMOTE[p]} ({p})" for p in extra),"Review remote access you do not recognize.",steps)
    return _row("rdp","Remote access to this PC","good","No known remote-control service is listening.",steps=steps)

# Firewall profiles and optional public-network stealth rules.
FW=r"SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy"; POL=r"SOFTWARE\Policies\Microsoft\WindowsFirewall"; PROFILES=[("DomainProfile","work"),("StandardProfile","private"),("PublicProfile","public")]; STEALTH="Green Rook Stealth"
STEALTH_RULES=(STEALTH+" TCP",STEALTH+" UDP",STEALTH+" ping IPv4",STEALTH+" ping IPv6")
NET_PROFILE={"DomainProfile":"domainprofile","StandardProfile":"privateprofile","PublicProfile":"publicprofile"}
def firewall_profiles():
    out=[]
    for k,n in PROFILES:
        en=_reg(POL+"\\"+k,"EnableFirewall");en=_reg(FW+"\\"+k,"EnableFirewall") if en is None else en
        ib=_reg(POL+"\\"+k,"DefaultInboundAction");ib=_reg(FW+"\\"+k,"DefaultInboundAction") if ib is None else ib
        out.append((n,en!=0,ib!=1))
    return out
def stealth_active():
    for name in STEALTH_RULES:
        rc,out=_run(["netsh","advfirewall","firewall","show","rule",f"name={name}"])
        if rc!=0 or name.lower() not in out.lower():return False
    return True
def check_firewall(ports=None,profiles=None,stealth=None):
    if IS_WIN:
        profiles=firewall_profiles() if profiles is None else profiles;stealth=stealth_active() if stealth is None else stealth
        off=[n for n,e,b in profiles if not e];allow=[n for n,e,b in profiles if e and not b]
        parts=["Firewall is off for: "+", ".join(off)] if off else ["Windows Firewall is on for all networks"]
        if allow:parts.append("Unasked incoming connections are allowed by default on: "+", ".join(allow))
        else:parts.append("Unasked incoming connections are blocked")
        parts.append("Public-network stealth: "+("on" if stealth else "off"));fixes=[]
        if off:fixes.append(("fw_on","Switch firewall fully on"))
        if allow:parts.append("Review custom inbound rules in Windows Security; Green Rook leaves existing app rules unchanged")
        fixes.append(("fw_stealth_off","Remove stealth rules") if stealth else ("fw_stealth","Stealth on public networks"))
        return _row("firewall","Firewall","bad" if off else "warn" if allow or not stealth else "good",". ".join(parts)+".","A firewall blocks incoming connections; optional public-network rules reduce responses to common probes.",["Turning on Windows Firewall enables all profiles and leaves existing app rules intact; the previous on/off state can be restored.","Optional stealth rules apply only on public networks; private-network file sharing is unchanged.","Only enable changes you understand. You can remove the stealth rules here."],fixes)
    if IS_LINUX and shutil.which("ufw"):
        _,o=_run(["ufw","status"])
        if "active" in o.lower():return _row("firewall","Firewall","good","ufw reports active.")
        if "inactive" in o.lower():return _row("firewall","Firewall","warn","ufw is installed but inactive.",steps=["Review your Linux firewall settings and enable a firewall if appropriate."])
    return _row("firewall","Firewall","info","Could not reliably read the firewall state on this system.",steps=["Review the firewall in your operating system's security settings."])

# DNS / hosts-file tampering. No hostname lookups are performed: DNS is read locally only.
GOOD_DNS={"9.9.9.9":"Quad9","149.112.112.112":"Quad9","1.1.1.1":"Cloudflare","1.0.0.1":"Cloudflare","1.1.1.2":"Cloudflare malware blocking","1.0.0.2":"Cloudflare malware blocking","8.8.8.8":"Google","8.8.4.4":"Google","208.67.222.222":"OpenDNS","208.67.220.220":"OpenDNS"}
def dns_servers():
    if IS_WIN:
        _,out=_run(["powershell","-NoProfile","-Command","(Get-DnsClientServerAddress -AddressFamily IPv4).ServerAddresses -join ' '"])
        if not out.strip():_,out=_run(["ipconfig","/all"])
        ips=re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b",out)
    else:
        ips=[]
        for f in ("/run/systemd/resolve/resolv.conf","/etc/resolv.conf"):
            try:ips=re.findall(r"^\s*nameserver\s+(\S+)",Path(f).read_text(errors="ignore"),re.M);break
            except OSError:pass
    return list(dict.fromkeys(x for x in ips if ":" not in x))
def hosts_path():return Path(os.environ.get("SystemRoot",r"C:\Windows"))/"System32/drivers/etc/hosts" if IS_WIN else Path("/etc/hosts")
def hosts_redirects(text):
    brands=set().union(*BRANDS.values()) if BRANDS else set();out=[]
    for i,line in enumerate(text.splitlines()):
        x=line.split("#",1)[0].split()
        if len(x)<2:continue
        try:a=ipaddress.ip_address(x[0].split("%")[0])
        except ValueError:continue
        sink=a.is_loopback or a.is_unspecified
        for host in x[1:]:
            h=host.lower().rstrip(".")
            if "." not in h or h.endswith((".local",".lan",".internal",".test")):continue
            base=".".join(h.split(".")[-2:])
            if (not sink and not a.is_private) or (not sink and (base in brands or h in brands)):out.append((i,x[0],h))
    return out
def check_dns(servers=None,hosts_text=None):
    servers=dns_servers() if servers is None else servers
    if hosts_text is None:
        try:hosts_text=hosts_path().read_text(errors="ignore")
        except OSError:hosts_text=""
    redirects=hosts_redirects(hosts_text);unknown=[];parts=[];protected=False
    for ip in servers:
        try:
            a=ipaddress.ip_address(ip);local=a.is_private or a.is_loopback or a.is_link_local
        except ValueError:local=False
        if ip not in GOOD_DNS and not local:unknown.append(ip)
        provider=GOOD_DNS.get(ip,"router / local network" if local else "not a well-known resolver");parts.append(f"{ip} ({provider})")
        if provider in ("Quad9","Cloudflare malware blocking","OpenDNS"):protected=True
    d="DNS servers: "+(", ".join(parts) if parts else "could not be read")
    if redirects:d+=". Hosts file redirects: "+", ".join(f"{h} to {ip}" for _,ip,h in redirects[:5])
    if unknown:d+=". Unrecognized public DNS: "+", ".join(unknown)
    status="bad" if redirects else "warn" if unknown else "good" if servers else "info";fixes=[]
    if not protected or unknown:fixes.append(("dns_secure","Use secure DNS (Quad9, free)"))
    if redirects:fixes.append(("hosts_clean","Remove the redirects"))
    return _row("dns","Fake websites (DNS)",status,d+".","A tampered hosts file or DNS server can send you to a fake site that looks like the real one.",["Quad9 is a free resolver that blocks many known malicious domains. Changing DNS affects this PC's network connections.","If your router or DNS server is unfamiliar, review your router settings and change its admin password.","Redirect removal keeps a backup of the original hosts file."],fixes,{"servers":servers,"redirects":redirects})
def clean_hosts_text(text):
    bad={i for i,_,_ in hosts_redirects(text)};lines=text.splitlines();return "\n".join(x for i,x in enumerate(lines) if i not in bad)+"\n",[lines[i] for i in sorted(bad)]

# Sensitive document detection looks at names and small plain-text files only. It stores no contents.
NAME=re.compile(r"passport|password|credential|bank[_ -]?(statement|details)|statement|tax[_ -]?return|\bssn\b|social[_ -]?security|aadhaar|pan[_ -]?card|driver.?s.?licen[cs]e|national[_ -]?id|birth[_ -]?cert|medical|recovery[_ -]?(key|code|phrase)|seed[_ -]?phrase|private[_ -]?key|\biban\b|credit[_ -]?card|\bnda\b|reisepass|personalausweis|steuer|kontoauszug",re.I)
DOC={".pdf",".doc",".docx",".xls",".xlsx",".csv",".txt",".rtf",".odt",".ods",".jpg",".jpeg",".png",".tif",".tiff",".md",".json"};TEXT={".txt",".csv",".md",".json",".rtf",".log",".ini",".cfg",".env",".pem",".key",".ppk"}
CARD=re.compile(r"(?<![\d.])(?:\d[ -]?){13,19}(?![\d.])");IBAN=re.compile(r"\b[A-Z]{2}\d{2}(?: ?[A-Z0-9]{4}){2,7}(?: ?[A-Z0-9]{1,4})?\b");SSN=re.compile(r"(?<!\d)(?!000|666|9\d\d)\d{3}-(?!00)\d{2}-(?!0000)\d{4}(?!\d)");PW=re.compile(r"^\s*(?:pass(?:word|wd)?|pwd|pin|secret|api[_ -]?key|token)\s*[:=]\s*\S{4,}",re.I|re.M);PRIV=re.compile(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH |ENCRYPTED )?PRIVATE KEY-----|PuTTY-User-Key-File")
def luhn(s):
    d=re.sub(r"[ -]","",s)
    if not 13<=len(d)<=19:return False
    return sum((int(c)*2-9 if i%2 and int(c)>4 else int(c)*(2 if i%2 else 1)) for i,c in enumerate(reversed(d)))%10==0
def iban_ok(s):
    s=s.replace(" ","").upper()
    try:return 15<=len(s)<=34 and int("".join(str(int(c,36)) for c in s[4:]+s[:4]))%97==1
    except ValueError:return False
def secret_kinds(text):
    k=[]
    if PRIV.search(text):k.append("a private key")
    if any(luhn(m.group()) for m in CARD.finditer(text)):k.append("a possible card number")
    if any(iban_ok(m.group()) for m in IBAN.finditer(text)):k.append("a bank account number")
    if SSN.search(text):k.append("a possible identity number")
    if PW.search(text):k.append("a written-down password")
    return k
def default_doc_dirs():
    h=Path.home();return [str(h/n) for n in ("Documents","Desktop","Downloads") if (h/n).is_dir()]
def find_sensitive(dirs=None,ignore=(),cap=20000,max_hits=200):
    hits=[];ignore={os.path.normcase(os.path.abspath(p)) for p in ignore}
    for root in default_doc_dirs() if dirs is None else dirs:
        for p,_stat in walk_limited(root,depth=4,cap=cap):
            if len(hits)>=max_hits:return hits
            ext=Path(p).suffix.lower();name=Path(p).stem
            if ext in (".kdbx",".gpg",".age",".grlocked") or os.path.normcase(os.path.abspath(p)) in ignore:continue
            reason=""
            if ext in TEXT:
                try:
                    if os.path.getsize(p)<=1_000_000:
                        with open(p,encoding="utf-8",errors="ignore") as f:k=secret_kinds(f.read())
                        if k:reason="Contains "+" and ".join(k[:2])
                except OSError:pass
            if not reason and ext in DOC and NAME.search(name):reason="The file name suggests private information"
            if reason:hits.append((p,reason))
    return hits
def check_documents(cfg=None,dirs=None):
    seen=cfg.get("shield_docs_seen") or [] if cfg else []
    try:hits=find_sensitive(dirs,seen)
    except Exception:hits=[]
    steps=["Lock sensitive files with a password to encrypt them; Green Rook checks the locked copy before removing the readable original.","A forgotten password cannot be recovered. Keep a safe backup of important files.","Use your operating system's free whole-disk encryption when available."]
    if not hits:return _row("documents","Sensitive documents","good","No likely sensitive files found in Documents, Desktop or Downloads.","Unprotected ID, bank and password files can expose private information.",steps,[("unlock_doc","Unlock a file")],[])
    return _row("documents","Sensitive documents","warn",f"{len(hits)} possible sensitive file(s); examples: "+", ".join(Path(p).name for p,_ in hits[:3])+".","Detection uses names and local text clues; it may be wrong. Review every file before locking it.",steps,[("lock_docs","Review and lock files"),("unlock_doc","Unlock a file")],hits)

# Password-based file safe. AES-GCM when available; authenticated HMAC stream fallback for standard-library installs.
MAGIC=b"GRSB1"; LOCK_EXT=".grlocked"
def _kdf(p,s):
    try:return hashlib.scrypt(p.encode(),salt=s,n=2**15,r=8,p=1,maxmem=128*1024*1024,dklen=64)
    except Exception:return hashlib.pbkdf2_hmac("sha256",p.encode(),b"pbkdf2"+s,600000,64)
def _stream(k,n,d):
    o=bytearray()
    for i in range(0,len(d),32):o+=bytes(a^b for a,b in zip(d[i:i+32],hmac.new(k,n+(i//32).to_bytes(8,"big"),hashlib.sha256).digest()))
    return bytes(o)
def seal(data,pw):
    s,n=secrets.token_bytes(16),secrets.token_bytes(12);k=_kdf(pw,s)
    if AESGCM:return MAGIC+b"A"+s+n+AESGCM(k[:32]).encrypt(n,data,MAGIC)
    c=_stream(k[:32],n,data);return MAGIC+b"H"+s+n+c+hmac.new(k[32:],MAGIC+n+c,hashlib.sha256).digest()
def unseal(b,pw):
    if b[:5]!=MAGIC or len(b)<34:raise ValueError("Not a Green Rook locked file.")
    mode,s,n,c=b[5:6],b[6:22],b[22:34],b[34:]
    if mode not in (b"A",b"H"):raise ValueError("Unknown Green Rook locked-file version.")
    k=_kdf(pw,s)
    if mode==b"A":
        if not AESGCM:raise ValueError("Install the cryptography package to unlock this file.")
        try:return AESGCM(k[:32]).decrypt(n,c,MAGIC)
        except Exception:raise ValueError("Wrong password or damaged file.") from None
    ct,tag=c[:-32],c[-32:]
    if not hmac.compare_digest(tag,hmac.new(k[32:],MAGIC+n+ct,hashlib.sha256).digest()):raise ValueError("Wrong password or damaged file.")
    return _stream(k[:32],n,ct)
def lock_file(path,pw):
    path=str(path)
    if len(pw)<8:return False,"Use a password of at least 8 characters."
    try:
        if os.path.islink(path) or not os.path.isfile(path):return False,"Choose a normal file."
        if os.path.getsize(path)>512*1024*1024:return False,"This file is larger than 512 MB."
        data=Path(path).read_bytes();dst=path+LOCK_EXT
        if os.path.exists(dst):return False,"A locked copy already exists."
        blob=seal(data,pw)
        if unseal(blob,pw)!=data:return False,"Encryption check failed; original was kept."
        atomic_write(Path(dst),blob,binary=True)
        if Path(dst).read_bytes()!=blob:os.remove(dst);return False,"Locked copy verification failed; original was kept."
        ok,msg=safe_delete(path)
        return (True,dst) if ok else (False,"Encrypted copy exists, but readable original remains: "+msg)
    except (OSError,ValueError,MemoryError) as e:return False,str(e)
def unlock_file(path,pw):
    try:
        data=unseal(Path(path).read_bytes(),pw);dst=path[:-len(LOCK_EXT)] if path.lower().endswith(LOCK_EXT) else path+".unlocked"
        if os.path.exists(dst):return False,"The original filename already exists; move it first."
        atomic_write(Path(dst),data,binary=True);os.remove(path);return True,dst
    except (OSError,ValueError) as e:return False,str(e)

# Reversible fixes. Administrator changes always go through the normal Windows UAC consent window.
def _elevated(commands):
    if not IS_WIN:return False,"This change is Windows-only."
    if is_admin():
        out=[_run(c) for c in commands];return all(rc==0 for rc,_ in out),"\n".join(x for _,x in out if x)[-500:]
    import ctypes
    d=data_dir()/"elevate";d.mkdir(exist_ok=True);tag=secrets.token_hex(5);bat=d/f"{tag}.cmd";done=d/f"{tag}.done"
    bat.write_text("@echo off\r\n"+"\r\n".join(subprocess.list2cmdline(c) for c in commands)+f'\r\necho done>"{done}"\r\n',encoding="utf-8")
    try:
        rc=ctypes.windll.shell32.ShellExecuteW(None,"runas","cmd.exe",f'/c "{bat}"',None,0)
        if rc<=32:return False,"Windows permission was not granted."
        end=time.time()+90
        while time.time()<end:
            if done.exists():return True,""
            time.sleep(.4)
        return False,"The change did not finish in time."
    finally:
        for p in (bat,done):
            try:p.unlink()
            except OSError:pass
def _remember(cfg,key,val):
    d=dict(cfg.get("shield_undo") or {});d[key]=val;cfg.set("shield_undo",d)
def _forget(cfg,key):
    d=dict(cfg.get("shield_undo") or {});d.pop(key,None);cfg.set("shield_undo",d)
def undo_list(cfg):
    d=cfg.get("shield_undo") or {}; names={"rdp":("rdp_undo","Restore remote access settings"),"dns":("dns_undo","Restore previous DNS settings"),"fw_stealth":("fw_stealth_off","Remove stealth rules"),"fw_state":("fw_undo","Restore previous firewall state")}
    return [names[k] for k in names if k in d]

def apply_fix(fid,cfg,cam_guard=None):
    try:
        if fid=="clear_cookies":return clear_cookies()
        if fid=="cam_guard_on":
            cfg.set("camera_guard",True)
            if cam_guard:cam_guard.set_enabled(True)
            return True,"Camera alerts are on."
        if fid in ("cam_block","cam_unblock","mic_block","mic_unblock"):
            if not IS_WIN:return False,"This control is Windows-only."
            dev="webcam" if fid.startswith("cam") else "microphone";import winreg
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER,CONSENT+"\\"+dev) as k:winreg.SetValueEx(k,"Value",0,winreg.REG_SZ,"Deny" if fid.endswith("_block") else "Allow")
            return True,dev+" access updated for your Windows user account. Restart open apps to apply it."
        if fid=="cam_settings":
            if IS_WIN:os.startfile("ms-settings:privacy-webcam");return True,"Windows camera settings opened."
            return False,"This shortcut is Windows-only."
        if fid=="rdp_off":
            _remember(cfg,"rdp",{"deny":_reg(TS,"fDenyTSConnections"),"assist":_reg(RA,"fAllowToGetHelp")})
            _elevated([["reg","add","HKLM\\"+TS,"/v","fDenyTSConnections","/t","REG_DWORD","/d","1","/f"],["reg","add","HKLM\\"+RA,"/v","fAllowToGetHelp","/t","REG_DWORD","/d","0","/f"]])
            good=_reg(TS,"fDenyTSConnections")==1
            if not good:_forget(cfg,"rdp")
            return good,"Remote Desktop and Remote Assistance turned off." if good else "Could not verify the change; check Windows settings."
        if fid=="rdp_undo":
            old=(cfg.get("shield_undo") or {}).get("rdp") or {};ok,msg=_elevated([["reg","add","HKLM\\"+TS,"/v","fDenyTSConnections","/t","REG_DWORD","/d",str(0 if old.get("deny")==0 else 1),"/f"],["reg","add","HKLM\\"+RA,"/v","fAllowToGetHelp","/t","REG_DWORD","/d",str(1 if old.get("assist")==1 else 0),"/f"]])
            if ok:_forget(cfg,"rdp")
            return ok,"Previous remote access settings restored." if ok else msg
        if fid=="fw_on":
            _remember(cfg,"fw_state",firewall_profiles())
            _elevated([["netsh","advfirewall","set",NET_PROFILE[key],"state","on"] for key,_ in PROFILES]);good=all(e for _,e,_ in firewall_profiles())
            if not good:_forget(cfg,"fw_state")
            return good,"Firewall is on for all profiles." if good else "Could not verify; a policy or security product may control the firewall."
        if fid=="fw_undo":
            old=(cfg.get("shield_undo") or {}).get("fw_state") or [];by_name={name: enabled for name,enabled,_ in old}
            commands=[["netsh","advfirewall","set",NET_PROFILE[key],"state","on" if by_name.get(name,True) else "off"] for key,name in PROFILES]
            ok,msg=_elevated(commands)
            if ok:_forget(cfg,"fw_state")
            return ok,"Previous Windows Firewall profile settings restored." if ok else msg
        if fid=="fw_stealth":
            base=["netsh","advfirewall","firewall","add","rule","dir=in","action=block","profile=public"]
            deletes=[["netsh","advfirewall","firewall","delete","rule","name="+name] for name in STEALTH_RULES]
            adds=[base+["name="+STEALTH_RULES[0],"protocol=TCP","localport=23,135,139,445,3389,5900,5985,5986"],
                  base+["name="+STEALTH_RULES[1],"protocol=UDP","localport=137,138,1900,5353,5355"],
                  base+["name="+STEALTH_RULES[2],"protocol=icmpv4:8,any"],base+["name="+STEALTH_RULES[3],"protocol=icmpv6:128,any"]]
            _elevated(deletes+adds);good=stealth_active()
            if good:_remember(cfg,"fw_stealth",True)
            return good,"Public-network stealth rules added." if good else "Could not verify stealth rules."
        if fid=="fw_stealth_off":
            _elevated([["netsh","advfirewall","firewall","delete","rule","name="+name] for name in STEALTH_RULES]);gone=not stealth_active()
            if gone:_forget(cfg,"fw_stealth")
            return gone,"Stealth rules removed." if gone else "Could not remove stealth rules."
        if fid=="dns_secure":
            if not IS_WIN:return False,"Set DNS to 9.9.9.9 and 149.112.112.112 in your network settings if you choose to use free Quad9."
            psread="$i=@(Get-NetAdapter -Physical | Where-Object {$_.Status -eq 'Up'} | ForEach-Object {$_.ifIndex}); Get-DnsClientServerAddress -AddressFamily IPv4 | Where-Object {$i -contains $_.InterfaceIndex} | Select-Object InterfaceIndex,ServerAddresses | ConvertTo-Json -Compress"
            _,raw=_run(["powershell","-NoProfile","-Command",psread]); old=[]
            try:
                val=json.loads(raw);old=val if isinstance(val,list) else [val]
            except Exception:pass
            if not old:return False,"Could not read the active physical adapters' DNS settings; nothing was changed."
            _remember(cfg,"dns",old)
            ps="Get-NetAdapter -Physical | Where-Object {$_.Status -eq 'Up'} | ForEach-Object {Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ServerAddresses '9.9.9.9','149.112.112.112'}"
            _elevated([["powershell","-NoProfile","-Command",ps],["ipconfig","/flushdns"]]);good="9.9.9.9" in dns_servers()
            if not good:_forget(cfg,"dns")
            return good,"Using Quad9 DNS; many known harmful domains are blocked." if good else "Could not verify DNS settings."
        if fid=="dns_undo":
            old=(cfg.get("shield_undo") or {}).get("dns") or []; commands=[]
            for item in old:
                idx=item.get("InterfaceIndex");servers=item.get("ServerAddresses") or []
                if idx is None:continue
                if isinstance(servers,str):servers=[servers]
                if servers:
                    quoted=",".join("'"+str(x).replace("'","")+"'" for x in servers)
                    ps=f"Set-DnsClientServerAddress -InterfaceIndex {int(idx)} -ServerAddresses {quoted}"
                else:ps=f"Set-DnsClientServerAddress -InterfaceIndex {int(idx)} -ResetServerAddresses"
                commands.append(["powershell","-NoProfile","-Command",ps])
            if not commands:return False,"No saved per-adapter DNS settings were available; nothing was changed."
            commands.append(["ipconfig","/flushdns"]);ok,msg=_elevated(commands)
            if ok:_forget(cfg,"dns")
            return ok,"Previous DNS settings restored." if ok else msg
        if fid=="hosts_clean":
            hp=hosts_path();text=hp.read_text(errors="ignore");new,removed=clean_hosts_text(text)
            if not removed:return True,"No suspicious redirects found."
            backup=data_dir()/("hosts-backup-"+time.strftime("%Y%m%d-%H%M%S")+".txt");backup.write_text(text,encoding="utf-8")
            try:hp.write_text(new,encoding="utf-8")
            except OSError:
                if not IS_WIN:return False,"Administrator rights are needed to edit the hosts file."
                tmp=data_dir()/"hosts.new";tmp.write_text(new,encoding="utf-8");ok,msg=_elevated([["cmd","/c","copy","/y",str(tmp),str(hp)]]);tmp.unlink(missing_ok=True)
                if not ok:return False,msg
            return True,f"Removed {len(removed)} redirect line(s). A backup is saved in Green Rook's data folder."
    except Exception as e:return False,"That change could not be applied: "+str(e)
    return False,"Unknown action."

ORDER=["passwords","cookies","camera","rdp","documents","dns","firewall"]
def run_checks(cfg=None,cam_guard=None,online=False):
    try:profiles=browser_profiles()
    except Exception:profiles=[]
    ports=listening_ports();jobs=[("passwords",lambda:check_passwords(profiles)),("cookies",lambda:check_cookies(profiles)),("camera",lambda:check_camera(cfg,cam_guard)),("rdp",lambda:check_rdp(ports)),("documents",lambda:check_documents(cfg)),("dns",check_dns), ("firewall",lambda:check_firewall(ports))];out=[]
    for cid,fn in jobs:
        try:out.append(fn())
        except Exception as e:out.append(_row(cid,cid.title(),"info","This check could not run: "+str(e)))
    return out
def summarize(rows):return {s:sum(r["status"]==s for r in rows) for s in ("good","warn","bad","info")}
