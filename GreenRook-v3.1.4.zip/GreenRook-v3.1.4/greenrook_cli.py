#!/usr/bin/env python3
"""
Green Rook command line (no window needed).

  python greenrook_cli.py scan  PATH [PATH...] [--all] [--no-cloud] [--report out.html|out.json] [--json] [--quarantine]
  python greenrook_cli.py selftest
  python greenrook_cli.py health
  python greenrook_cli.py trust-key  publisher.pub
  python greenrook_cli.py install-pack  feed.grpack
  python greenrook_cli.py update-feeds
  python greenrook_cli.py check-link URL
  python greenrook_cli.py ultra-status
  python greenrook_cli.py version

Exit code of 'scan': 0 = nothing found, 1 = threats found, 2 = could not run.
--quarantine only removes files with HARD evidence (known hash / signature) outside operating-system folders;
everything else is reported and left alone.
"""
import argparse
import json
import queue
import sys
import threading
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gr_core as c  # noqa: E402
import gr_health  # noqa: E402
import gr_report  # noqa: E402
import gr_selftest  # noqa: E402


def boot():
    folder = c.data_dir()
    cfg = c.Config(folder / "config.json")
    bus = c.EventBus(folder / "events.log", queue.Queue())
    return cfg, bus, c.Engine(cfg, bus), c.Vault(folder, cfg, bus)


def cmd_scan(a):
    cfg, bus, eng, vault = boot()
    cancel = threading.Event()
    results, flagged, moved = [], [], 0
    for p in c.iter_files(eng, [str(Path(x)) for x in a.paths], not a.all, cancel):
        r = eng.scan_file(p, cloud=False if a.no_cloud else None)
        results.append(r)
        if r.verdict in (c.MALICIOUS, c.SUSPICIOUS):
            flagged.append(r)
            if a.quarantine and r.auto_safe:
                try:
                    vault.quarantine(r)
                    moved += 1
                except OSError as e:
                    print(f"  could not quarantine {r.path}: {e}", file=sys.stderr)
    if a.report:
        gr_report.write_report(a.report, results, "Green Rook CLI scan")
    if a.json:
        print(json.dumps(gr_report.to_dict(results, "Green Rook CLI scan"), indent=1))
    else:
        for r in flagged:
            print(f"[{r.verdict.upper()}] {r.path}  score {r.score}  confidence: {r.confidence}")
            for why in r.reasons[:6]:
                print(f"    - {why}")
        print(f"\n{len(results)} files checked, {len(flagged)} flagged" + (f", {moved} quarantined" if a.quarantine else "") + ".")
    return 1 if flagged else 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("scan")
    s.add_argument("paths", nargs="+")
    s.add_argument("--all", action="store_true", help="scan every file type, not just risky ones")
    s.add_argument("--no-cloud", action="store_true")
    s.add_argument("--report")
    s.add_argument("--json", action="store_true")
    s.add_argument("--quarantine", action="store_true")
    for n in ("selftest", "health", "update-feeds", "version"):
        sub.add_parser(n)
    sub.add_parser("ultra-status")
    sub.add_parser("check-link").add_argument("url")
    for n in ("trust-key", "install-pack"):
        sub.add_parser(n).add_argument("file")
    a = ap.parse_args(argv)
    try:
        if a.cmd == "scan":
            return cmd_scan(a)
        if a.cmd == "selftest":
            out = gr_selftest.run_selftest()
            print(gr_selftest.format_results(out))
            return 0 if all(ok for _, ok, _ in out) else 1
        if a.cmd == "version":
            print(f"{c.APP_NAME} {c.VERSION}")
            return 0
        if a.cmd == "ultra-status":
            import gr_ultra
            print("WireGuard:", gr_ultra.wireguard_tool() or "not installed")
            print("Ultra Rook tunnel:", "UP" if gr_ultra.tunnel_up() else "down")
            return 0
        cfg, bus, eng, vault = boot()
        if a.cmd == "check-link":
            score, why, verdict = c.WebGuard(eng.intel).analyze(a.url)
            print(f"{verdict}  (risk {score}/100)")
            for w in why:
                print("  -", w)
            return 1 if verdict == "Dangerous" else 0
        if a.cmd == "health":
            rows = gr_health.run_checks(cfg)
            for r in rows:
                print(f"[{r['status'].upper():4}] {r['title']}: {r['detail']}")
            return 1 if any(r["status"] == "bad" for r in rows) else 0
        if a.cmd == "trust-key":
            print("Trusted publisher key", eng.intel.add_key(Path(a.file).read_text()))
        elif a.cmd == "install-pack":
            i = eng.install_pack(a.file)
            print(f"Installed '{i['name']}' #{i['serial']}: {i['hashes']} hashes, {i['domains']} domains, {i['ips']} IPs, {i['rules']} rules")
        elif a.cmd == "update-feeds":
            new, total = eng.update_hash_feeds()
            print(f"{new} new hashes ({total} in feed)")
    except c.PackError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2
    except OSError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
