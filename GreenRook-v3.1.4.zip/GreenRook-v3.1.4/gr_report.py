"""Green Rook - scan reports (JSON for tools, HTML for people). Pure formatting, no side effects except the file you name."""
import html
import json
import platform
import time

from gr_core import APP_NAME, VERSION, CLEAN


def to_dict(results, title="Scan report", meta=None, files_checked=None):
    flagged = [r for r in results if r.verdict not in (CLEAN, "Skipped", "Error")]
    return {"program": f"{APP_NAME} {VERSION}", "title": title, "created": time.strftime("%Y-%m-%d %H:%M:%S"),
            "host": platform.node(), "os": platform.platform(), "meta": meta or {},
            "summary": {"files": files_checked if files_checked is not None else len(results), "flagged": len(flagged),
                        "malicious": sum(r.verdict == "Malicious" for r in results), "suspicious": sum(r.verdict == "Suspicious" for r in results)},
            "findings": [{"path": r.path, "verdict": r.verdict, "score": r.score, "confidence": r.confidence, "sha256": r.sha256,
                          "size": r.size, "reasons": r.reasons, "explanation": r.explain()} for r in flagged]}


def to_html(results, title="Scan report", meta=None, files_checked=None):
    d, e = to_dict(results, title, meta, files_checked), html.escape
    rows = "".join(
        f"<tr class='{e(f['verdict'].lower())}'><td>{e(f['verdict'])}<br><small>{f['score']}/100 - {e(f['confidence'])}</small></td>"
        f"<td><b>{e(f['path'])}</b><br><small>SHA-256 {e(f['sha256'])}</small><ul>{''.join('<li>' + e(x) + '</li>' for x in f['reasons'])}</ul></td></tr>"
        for f in d["findings"]) or "<tr><td colspan=2>No threats found. This is not a guarantee of safety.</td></tr>"
    s = d["summary"]
    return f"""<!doctype html><html><head><meta charset="utf-8"><title>{e(title)}</title><style>
body{{font:14px system-ui,Segoe UI,sans-serif;background:#0a130e;color:#e9f5ec;margin:2em auto;max-width:960px;padding:0 1em}}
h1{{color:#3ddc84}}table{{border-collapse:collapse;width:100%}}td{{border-bottom:1px solid #24493a;padding:8px;vertical-align:top}}
.malicious td:first-child{{color:#ff8f8c;font-weight:bold}}.suspicious td:first-child{{color:#ffc94d;font-weight:bold}}small{{color:#8fb09d}}</style></head>
<body><h1>&#9820; {e(title)}</h1><p>{e(d['program'])} &middot; {e(d['created'])} &middot; {e(d['host'])}</p>
<p><b>{s['files']}</b> files checked, <b>{s['malicious']}</b> malicious, <b>{s['suspicious']}</b> suspicious.</p>
<table>{rows}</table></body></html>"""


def write_report(path, results, title="Scan report", meta=None, files_checked=None):
    path = str(path)
    text = json.dumps(to_dict(results, title, meta, files_checked), indent=1) if path.lower().endswith(".json") else to_html(results, title, meta, files_checked)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
    return path
