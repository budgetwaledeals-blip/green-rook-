"""
Green Rook - Hardening audit ("Ramparts").  READ-ONLY: it looks at settings, it never changes any.

Every check is tied to the historic incident it would have blunted, because the lesson of those incidents is that
antivirus alone is not enough - the weaknesses were unpatched services, auto-run, macros and scripts left enabled,
exposed remote-access and over-privileged accounts. Each check returns:
    {"id", "title", "status": good|warn|bad|info, "detail", "lesson"}
"""
import os
import re
import subprocess
import sys

from gr_core import IS_LINUX, IS_MAC, IS_WIN, psutil


def _row(cid, title, status, detail, lesson=""):
    return {"id": cid, "title": title, "status": status, "detail": detail, "lesson": lesson}


def _reg(hive, path, name):
    import winreg
    try:
        with winreg.OpenKey(hive, path) as k:
            return winreg.QueryValueEx(k, name)[0]
    except OSError:
        return None


def is_admin() -> bool:
    try:
        if IS_WIN:
            import ctypes
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        return os.geteuid() == 0
    except Exception:
        return False


def world_writable_path_dirs(path_env=None):
    """Folders on PATH that anyone may write to: a program planted there runs whenever you type its name."""
    bad = []
    for d in (path_env if path_env is not None else os.environ.get("PATH", "")).split(os.pathsep):
        try:
            if d and os.path.isdir(d) and os.stat(d).st_mode & 0o002 and not os.stat(d).st_mode & 0o1000:
                bad.append(d)
        except OSError:
            continue
    return bad


def _windows():
    import winreg
    H = winreg.HKEY_LOCAL_MACHINE
    out = []
    smb = _reg(H, r"SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters", "SMB1")
    out.append(_row("smb1", "Old SMBv1 file-sharing protocol", "bad" if smb == 1 else "good" if smb == 0 else "info",
                    {1: "SMBv1 is ENABLED.", 0: "SMBv1 is disabled."}.get(smb, "Not set explicitly (modern Windows disables it by default)."),
                    "WannaCry and NotPetya spread through SMBv1 flaws. Turn it off and keep Windows updated."))
    uac = _reg(H, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System", "EnableLUA")
    out.append(_row("uac", "User Account Control", "good" if uac in (1, None) else "bad",
                    "UAC is on." if uac in (1, None) else "UAC is OFF - every program runs with full rights.",
                    "Least privilege limits what a worm or macro can do the moment it runs."))
    rt = _reg(H, r"SOFTWARE\Microsoft\Windows Defender\Real-Time Protection", "DisableRealtimeMonitoring")
    out.append(_row("defender", "Windows Defender real-time protection", "bad" if rt == 1 else "good" if rt == 0 else "info",
                    {1: "Real-time protection is OFF.", 0: "Real-time protection is on."}.get(rt, "Status not readable (another antivirus may manage it)."),
                    "Green Rook is designed to run beside Defender, not instead of it."))
    ar = _reg(H, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer", "NoDriveTypeAutoRun")
    out.append(_row("autorun", "AutoRun / AutoPlay for drives", "good" if ar == 255 else "warn",
                    "AutoRun is disabled for all drive types." if ar == 255 else "AutoRun is not fully disabled by policy.",
                    "Conficker and many USB worms relied on AutoRun to start themselves."))
    rdp = _reg(H, r"SYSTEM\CurrentControlSet\Control\Terminal Server", "fDenyTSConnections")
    out.append(_row("rdp", "Remote Desktop", "warn" if rdp == 0 else "good", "Remote Desktop is ENABLED - make sure it needs a strong password and is not exposed to the internet."
                    if rdp == 0 else "Remote Desktop is off.", "Exposed remote-access ports are the front door for ransomware gangs."))
    wsh = _reg(H, r"SOFTWARE\Microsoft\Windows Script Host\Settings", "Enabled")
    out.append(_row("wsh", "Windows Script Host (.vbs / .js)", "good" if wsh == 0 else "info",
                    "Script Host is disabled." if wsh == 0 else "Script Host is enabled (needed by some older software).",
                    "ILOVEYOU was a .vbs attachment. If you never run such scripts, disabling the host removes that whole class."))
    sb = _reg(H, r"SYSTEM\CurrentControlSet\Control\SecureBoot\State", "UEFISecureBootEnabled")
    out.append(_row("secureboot", "Secure Boot", "good" if sb == 1 else "warn" if sb == 0 else "info",
                    {1: "Secure Boot is on.", 0: "Secure Boot is OFF."}.get(sb, "Not available (legacy BIOS or unreadable)."),
                    "Secure Boot stops tampered boot code - the layer below any antivirus."))
    cfa = _reg(H, r"SOFTWARE\Microsoft\Windows Defender\Windows Defender Exploit Guard\Controlled Folder Access", "EnableControlledFolderAccess")
    out.append(_row("cfa", "Controlled folder access (Windows ransomware protection)", "info",
                    "ON - Windows may stop Green Rook from deleting or changing files in Documents, Desktop and Pictures until you allow it "
                    "(Windows Security > Ransomware protection > Allow an app)." if cfa == 1 else "Off or not set - it will not block Green Rook.",
                    "If Green Rook says a file could not be deleted in a personal folder, this setting is the usual reason."))
    try:
        r = subprocess.run(["netsh", "advfirewall", "show", "allprofiles", "state"], capture_output=True, text=True, timeout=15, creationflags=0x08000000)
        states = re.findall(r"State\s+(ON|OFF)", r.stdout, re.I)
        off = [x for x in states if x.upper() == "OFF"]
        out.append(_row("firewall", "Windows Firewall", "bad" if off else "good" if states else "info",
                        f"{len(off)} of {len(states)} profiles are OFF." if off else "All firewall profiles are on." if states else "Could not read firewall state.",
                        "A firewall blocks the inbound probes that Code Red-style worms used."))
    except Exception:
        pass
    return out


def _linux():
    out = []
    if os.path.isdir("/sys/firmware/efi"):
        sb = None
        try:
            for f in os.listdir("/sys/firmware/efi/efivars"):
                if f.startswith("SecureBoot-"):
                    sb = open(f"/sys/firmware/efi/efivars/{f}", "rb").read()[-1:] == b"\x01"
        except OSError:
            pass
        out.append(_row("secureboot", "Secure Boot", "good" if sb else "warn" if sb is False else "info",
                        {True: "Secure Boot is on.", False: "Secure Boot is OFF."}.get(sb, "Could not be read."), "Protects the boot chain below the antivirus."))
    else:
        out.append(_row("secureboot", "Secure Boot", "info", "Legacy BIOS boot - Secure Boot does not apply.", ""))
    ww = world_writable_path_dirs()
    out.append(_row("pathperm", "Writable folders on PATH", "bad" if ww else "good", ("World-writable: " + ", ".join(ww)) if ww else "No folder on PATH is world-writable.",
                    "A program planted in such a folder runs with your rights whenever you type its name."))
    try:
        cfg = open("/etc/ssh/sshd_config", encoding="utf-8", errors="ignore").read()
        root = re.search(r"^\s*PermitRootLogin\s+(\S+)", cfg, re.M | re.I)
        out.append(_row("sshroot", "SSH root login", "bad" if root and root.group(1).lower() == "yes" else "good",
                        f"PermitRootLogin = {root.group(1)}" if root else "Not set (OpenSSH default: key-only for root).", "Exposed remote access is a common ransomware entry point."))
    except OSError:
        pass
    out.append(_row("reboot", "Pending reboot for updates", "warn" if os.path.exists("/var/run/reboot-required") else "good",
                    "Updates are waiting for a reboot." if os.path.exists("/var/run/reboot-required") else "No reboot pending.", "Unpatched software was the root cause of Slammer and WannaCry."))
    return out


def run_checks(cfg=None):
    """Return the audit as a list of rows. Never raises."""
    out = []
    try:
        out.append(_row("admin", "Running with administrator / root rights", "warn" if is_admin() else "good",
                        "Green Rook is running elevated. That is needed for some actions, but day-to-day use with lower rights is safer."
                        if is_admin() else "Running as a normal user (least privilege).",
                        "Malware inherits the rights of whatever it infects."))
        if IS_WIN:
            out += _windows()
        elif IS_LINUX:
            out += _linux()
        elif IS_MAC:
            out.append(_row("mac", "System checks", "info", "Detailed system checks are not available on macOS yet.", ""))
    except Exception as e:
        out.append(_row("error", "System checks", "info", f"Some checks could not run: {e}", ""))
    out.append(_row("deps", "Green Rook components", "good" if psutil else "warn",
                    "psutil is installed - process, network and USB guards can work." if psutil else "psutil is missing - process, network, USB and ransomware guards are INACTIVE (pip install psutil).",
                    "A guard that cannot start protects nothing."))
    try:
        import gr_intel
        out.append(_row("signing", "Signed updates", "good" if gr_intel.HAVE_ED25519 else "warn",
                        "Signature verification is available." if gr_intel.HAVE_ED25519 else "Install 'cryptography' to verify signed update packs and use AES-256-GCM in the Vault.",
                        "An update channel that is not authenticated is an attack surface."))
    except Exception:
        pass
    if cfg is not None:
        try:
            off = [k for k in ("realtime", "process_guard", "ransomware_guard", "persistence_guard", "usb_guard", "network_guard", "camera_guard", "tamper_protection") if not cfg.get(k)]
            out.append(_row("guards", "Green Rook guards", "bad" if len(off) >= 4 else "warn" if off else "good",
                            ("Switched off: " + ", ".join(off)) if off else "All guards are on.", "Layered defence only works if the layers are switched on."))
            out.append(_row("pin", "Tamper-protection PIN", "good" if cfg.get("pin") else "warn",
                            "A PIN protects settings changes." if cfg.get("pin") else "No PIN set - anyone at the keyboard can switch guards off after a simple confirmation.", ""))
        except Exception:
            pass
    return out


def summarize(rows):
    c = {"good": 0, "warn": 0, "bad": 0, "info": 0}
    for r in rows:
        c[r["status"]] = c.get(r["status"], 0) + 1
    return c


if __name__ == "__main__":
    for r in run_checks():
        print(f"[{r['status'].upper():4}] {r['title']}: {r['detail']}")
    sys.exit(0)
