#!/usr/bin/env python3
"""
Ultra Rook - make the files for YOUR OWN private-network server.

    python tools/ultrarook_makeconf.py  203.0.113.5            (your server's internet address or name)
    python tools/ultrarook_makeconf.py  vpn.example.com --port 51820 --out my-ultrarook

Writes three files: server-wg0.conf (goes on the server), client.conf (import into Green Rook > Ultra Rook) and SERVER-STEPS.txt.
Needs:  pip install cryptography
"""
import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import gr_ultra  # noqa: E402


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("host", help="the server's public IP address or domain name")
    ap.add_argument("--port", type=int, default=51820)
    ap.add_argument("--out", default="ultrarook-files")
    a = ap.parse_args(argv)
    try:
        server, client, steps = gr_ultra.make_wireguard_pair(a.host, a.port)
        gr_ultra.parse_wg_conf(client)                       # we never hand out a file our own app would refuse
    except (gr_ultra.UltraError, ImportError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    for name, text in (("server-wg0.conf", server), ("client.conf", client), ("SERVER-STEPS.txt", steps)):
        f = out / name
        fd = os.open(f, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as fh:
            fh.write(text)
    print(f"Written to {out.resolve()}:  server-wg0.conf, client.conf, SERVER-STEPS.txt\nNext: open SERVER-STEPS.txt")
    return 0


if __name__ == "__main__":
    sys.exit(main())
