#!/usr/bin/env python3
"""
grsign - publisher tool for Green Rook signed threat-intelligence packs.  Needs:  pip install cryptography

  python tools/grsign.py keygen  mykey                       -> mykey.key (PRIVATE - keep offline) and mykey.pub (share)
  python tools/grsign.py pack    --name "My feed" --serial 1 --hashes hashes.txt --domains domains.txt \\
                                 --ips ips.txt --days-valid 90 --key mykey.key --out my-feed.grpack
  python tools/grsign.py sign    --key mykey.key --in payload.json --out my-feed.grpack
  python tools/grsign.py verify  --pub mykey.pub my-feed.grpack

Then, in Green Rook:  Armory -> Threat intelligence -> "Trust a publisher key..." (paste/choose mykey.pub),
then "Install signed pack..." and choose the .grpack file.
Text input files: one SHA-256 / domain / IPv4 per line; '#' starts a comment; a hash line may carry a name after it.
"""
import argparse
import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import gr_intel  # noqa: E402


def lines(path):
    out = []
    for ln in Path(path).read_text("utf-8", "ignore").splitlines():
        ln = ln.split("#", 1)[0].strip()
        if ln:
            out.append(ln)
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    k = sub.add_parser("keygen")
    k.add_argument("name")
    pk = sub.add_parser("pack")
    pk.add_argument("--name", required=True)
    pk.add_argument("--serial", type=int, required=True)
    pk.add_argument("--hashes")
    pk.add_argument("--domains")
    pk.add_argument("--ips")
    pk.add_argument("--rules", help="JSON file: [{\"name\":..., \"weight\":40, \"any\":[\"text\", ...]}]")
    pk.add_argument("--days-valid", type=int, default=0)
    pk.add_argument("--key", required=True)
    pk.add_argument("--out", required=True)
    sg = sub.add_parser("sign")
    sg.add_argument("--key", required=True)
    sg.add_argument("--in", dest="inp", required=True)
    sg.add_argument("--out", required=True)
    vf = sub.add_parser("verify")
    vf.add_argument("--pub", required=True)
    vf.add_argument("pack")
    a = ap.parse_args(argv)
    try:
        if a.cmd == "keygen":
            priv, pub = gr_intel.generate_keypair()
            kp, pp = Path(a.name + ".key"), Path(a.name + ".pub")
            if kp.exists() or pp.exists():
                print("Refusing to overwrite an existing key file.", file=sys.stderr)
                return 2
            kp.write_text(priv + "\n")
            try:
                os.chmod(kp, 0o600)
            except OSError:
                pass
            pp.write_text(pub + "\n")
            print(f"Private key: {kp}   (secret - never share, never put in the Green Rook folder)")
            print(f"Public key:  {pp}   (key id {gr_intel.key_id(gr_intel.b64d(pub))}) - give this to users")
        elif a.cmd == "pack":
            payload = {"name": a.name, "serial": a.serial, "created": time.strftime("%Y-%m-%d")}
            if a.days_valid:
                payload["expires"] = time.strftime("%Y-%m-%d", time.localtime(time.time() + a.days_valid * 86400))
            if a.hashes:
                payload["hashes"] = [{"sha256": ln.split()[0], "name": " ".join(ln.split()[1:]) or a.name} for ln in lines(a.hashes)]
            if a.domains:
                payload["domains"] = lines(a.domains)
            if a.ips:
                payload["ips"] = lines(a.ips)
            if a.rules:
                payload["rules"] = json.loads(Path(a.rules).read_text("utf-8"))
            Path(a.out).write_text(gr_intel.sign_pack(payload, Path(a.key).read_text().strip()))
            print(f"Signed pack written to {a.out}")
        elif a.cmd == "sign":
            payload = json.loads(Path(a.inp).read_text("utf-8"))
            Path(a.out).write_text(gr_intel.sign_pack(payload, Path(a.key).read_text().strip()))
            print(f"Signed pack written to {a.out}")
        elif a.cmd == "verify":
            payload, kid = gr_intel.verify_pack(Path(a.pack).read_bytes(), [Path(a.pub).read_text().strip()])
            print(f"VALID - '{payload['name']}' serial {payload['serial']} signed by key {kid}: {len(payload['hashes'])} hashes, "
                  f"{len(payload['domains'])} domains, {len(payload['ips'])} IPs, {len(payload['rules'])} rules")
    except gr_intel.PackError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    except (OSError, ValueError, json.JSONDecodeError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
