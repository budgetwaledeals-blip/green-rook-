#!/usr/bin/env python3
"""Rewrite OWNFILES.sha256 (hashes of every shipped file, so Green Rook never flags its own copy) and MANIFEST.sha256 (tamper check).
Run after changing any file in the package:  python tools/make_manifest.py"""
import hashlib
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import gr_guards  # noqa: E402

root = gr_guards.APP_DIR
SKIP_DIRS = {"samples", "__pycache__", "venv", "dist", "build", ".git"}      # samples are deliberately left out: they exist to be detected
SKIP_FILES = {"OWNFILES.sha256", "MANIFEST.sha256", ".deps_ok"}
lines = []
for p in sorted(root.rglob("*")):
    rel = p.relative_to(root)
    if not p.is_file() or rel.parts[0] in SKIP_DIRS or p.name in SKIP_FILES or p.suffix == ".pyc":
        continue
    lines.append(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {rel.as_posix()}")
(root / "OWNFILES.sha256").write_text("\n".join(lines) + "\n")
(root / "MANIFEST.sha256").write_text(gr_guards.compute_manifest())
print(f"OWNFILES.sha256: {len(lines)} files;  MANIFEST.sha256:")
print(gr_guards.compute_manifest())
