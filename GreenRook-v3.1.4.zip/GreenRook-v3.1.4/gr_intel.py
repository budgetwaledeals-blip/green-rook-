"""
Green Rook - trusted threat intelligence.

A threat-intelligence update (malware hashes, bad domains/IPs, detection rules) is only as trustworthy as its source.
An update channel that is not authenticated is itself an attack surface: whoever can tamper with it can make an
antivirus delete good files or ignore bad ones. So Green Rook accepts offline "packs" only when they carry a valid
Ed25519 signature from a key YOU chose to trust.

Pack file (.grpack) = JSON:  {"format": "greenrook-pack/1", "key_id": "...", "payload": "<base64>", "signature": "<base64>"}
The signature covers the exact payload bytes. The payload is JSON:
    {"name": "...", "serial": 7, "created": "2026-11-08", "expires": "2027-02-01",      # expires is optional
     "hashes": [{"sha256": "...", "name": "..."}], "domains": ["bad.example"], "ips": ["203.0.113.9"],
     "rules": [{"name": "...", "weight": 40, "any": ["text to look for"]}]}

Safety properties:
  * unsigned / wrongly signed / edited packs are rejected;
  * a pack's serial number must be higher than the installed one (no rollback to an older, weaker list);
  * installed packs are re-verified every time they are loaded, so editing them on disk disables them;
  * the list of trusted keys lives in the HMAC-protected settings file.
No private key is ever stored by the application. Create keys and sign packs with tools/grsign.py.
"""
import base64
import hashlib
import json
import re
import time
import urllib.request
from pathlib import Path

try:
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
    HAVE_ED25519 = True
except Exception:  # cryptography is optional for the rest of the program
    HAVE_ED25519 = False

FORMAT = "greenrook-pack/1"
MAX_PACK_BYTES = 64 * 1024 * 1024
LIMITS = {"hashes": 600_000, "domains": 250_000, "ips": 100_000, "rules": 500}
SHA_RE = re.compile(r"^[0-9a-f]{64}$")
DOMAIN_RE = re.compile(r"^[a-z0-9]([a-z0-9._-]{0,251}[a-z0-9])?\.[a-z0-9-]{2,}$")
IP_RE = re.compile(r"^(\d{1,3}\.){3}\d{1,3}$")


class PackError(Exception):
    """Raised with a message that is safe to show to the user."""


def _need_crypto():
    if not HAVE_ED25519:
        raise PackError("Signed packs need the 'cryptography' package:  pip install cryptography")


def key_id(pub_raw: bytes) -> str:
    return hashlib.sha256(pub_raw).hexdigest()[:16]


def b64d(text: str) -> bytes:
    try:
        return base64.b64decode(text.strip(), validate=True)
    except Exception as e:
        raise PackError("Not valid base64 text") from e


# --------------------------------------------------------------------------- key + pack creation (used by tools/grsign.py)
def generate_keypair():
    """Return (private_b64, public_b64). Keep the private key offline."""
    _need_crypto()
    k = Ed25519PrivateKey.generate()
    priv = k.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption())
    pub = k.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    return base64.b64encode(priv).decode(), base64.b64encode(pub).decode()


def sign_pack(payload: dict, private_b64: str) -> str:
    """Validate the payload, sign it and return the .grpack JSON text."""
    _need_crypto()
    clean = validate_payload(payload)
    priv = Ed25519PrivateKey.from_private_bytes(b64d(private_b64))
    pub = priv.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    raw = json.dumps(clean, sort_keys=True, separators=(",", ":")).encode()
    return json.dumps({"format": FORMAT, "key_id": key_id(pub), "payload": base64.b64encode(raw).decode(),
                       "signature": base64.b64encode(priv.sign(raw)).decode()}, indent=1)


# --------------------------------------------------------------------------- verification
def validate_payload(p) -> dict:
    """Strict schema check. Returns a cleaned copy; raises PackError on anything unexpected."""
    if not isinstance(p, dict):
        raise PackError("Pack payload must be a JSON object")
    name = str(p.get("name", "")).strip()
    if not re.fullmatch(r"[A-Za-z0-9 ._-]{1,60}", name):
        raise PackError("Pack name must be 1-60 letters, digits, space, dot, dash or underscore")
    serial = p.get("serial")
    if not isinstance(serial, int) or isinstance(serial, bool) or serial < 1:
        raise PackError("Pack serial must be a whole number, 1 or higher")
    out = {"name": name, "serial": serial, "created": str(p.get("created", ""))[:32]}
    if p.get("expires"):
        out["expires"] = str(p["expires"])[:32]
        try:
            time.strptime(out["expires"][:10], "%Y-%m-%d")
        except ValueError as e:
            raise PackError("'expires' must look like 2027-01-31") from e
    hashes = {}
    for h in p.get("hashes", []):
        sha, label = (h.get("sha256"), h.get("name")) if isinstance(h, dict) else (h, None)
        sha = str(sha or "").lower()
        if not SHA_RE.match(sha):
            raise PackError(f"Invalid SHA-256 in pack: {sha[:20]!r}")
        hashes[sha] = str(label or name)[:80]
    domains = sorted({str(d).strip().lower() for d in p.get("domains", [])})
    for d in domains:
        if not DOMAIN_RE.match(d):
            raise PackError(f"Invalid domain in pack: {d[:40]!r}")
    ips = sorted({str(i).strip() for i in p.get("ips", [])})
    for i in ips:
        if not IP_RE.match(i) or any(int(x) > 255 for x in i.split(".")):
            raise PackError(f"Invalid IP address in pack: {i[:20]!r}")
    rules = []
    for r in p.get("rules", []):
        if not isinstance(r, dict):
            raise PackError("Each rule must be an object")
        weight = r.get("weight", 30)
        pats = [str(t) for t in r.get("any", []) if str(t)]
        if not isinstance(weight, int) or not 1 <= weight <= 100:
            raise PackError("Rule weight must be 1-100")
        if not pats or any(len(t) < 6 for t in pats):
            raise PackError("Every rule needs at least one pattern, and each pattern must be 6+ characters (shorter ones cause false alarms)")
        rules.append({"name": str(r.get("name", "unnamed"))[:60], "weight": weight, "any": pats[:50]})
    for key, items in (("hashes", hashes), ("domains", domains), ("ips", ips), ("rules", rules)):
        if len(items) > LIMITS[key]:
            raise PackError(f"Pack has too many {key} (limit {LIMITS[key]:,})")
    out.update({"hashes": [{"sha256": k, "name": v} for k, v in sorted(hashes.items())], "domains": domains, "ips": ips, "rules": rules})
    return out


def verify_pack(raw: bytes, trusted_pubs):
    """trusted_pubs: iterable of base64 public keys. Returns (payload_dict, key_id). Raises PackError."""
    _need_crypto()
    if len(raw) > MAX_PACK_BYTES:
        raise PackError("Pack file is too large")
    try:
        doc = json.loads(raw.decode("utf-8"))
        payload_raw, sig, kid = b64d(doc["payload"]), b64d(doc["signature"]), str(doc.get("key_id", ""))
        if doc.get("format") != FORMAT:
            raise PackError("Unsupported pack format")
    except PackError:
        raise
    except Exception as e:
        raise PackError("This is not a Green Rook pack file") from e
    keys = []
    for t in trusted_pubs:
        try:
            keys.append(b64d(t))
        except PackError:
            continue
    if not keys:
        raise PackError("You have not trusted any publisher key yet. Add the publisher's public key first.")
    candidates = [k for k in keys if key_id(k) == kid] or keys
    for k in candidates:
        try:
            Ed25519PublicKey.from_public_bytes(k).verify(sig, payload_raw)
            break
        except (InvalidSignature, ValueError):
            continue
    else:
        raise PackError("SIGNATURE CHECK FAILED - this pack was not signed by a key you trust, or it was modified. It was NOT installed.")
    try:
        payload = validate_payload(json.loads(payload_raw.decode("utf-8")))
    except PackError:
        raise
    except Exception as e:
        raise PackError("Pack payload is damaged") from e
    return payload, key_id(k)


class IntelStore:
    """Installed signed packs. Everything is re-verified on load."""

    def __init__(self, folder: Path, cfg, bus):
        self.dir = Path(folder) / "intel"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.cfg, self.bus = cfg, bus
        self._cache = (None, None)

    # -- trusted keys (kept in the HMAC-protected settings) ------------------------------
    def trusted(self):
        return list(self.cfg.get("trusted_keys") or [])

    def add_key(self, pub_b64: str) -> str:
        raw = b64d(pub_b64)
        if len(raw) != 32:
            raise PackError("A public key is exactly 32 bytes (44 characters of base64)")
        self.cfg.append_unique("trusted_keys", base64.b64encode(raw).decode())
        self.bus.emit("INFO", "Threat Intel", f"Publisher key {key_id(raw)} is now trusted")
        return key_id(raw)

    def remove_key(self, kid: str):
        keep = [k for k in self.trusted() if key_id(b64d(k)) != kid]
        self.cfg.set("trusted_keys", keep)
        self.bus.emit("INFO", "Threat Intel", f"Publisher key {kid} removed")

    # -- install / load -----------------------------------------------------------------------
    def install(self, path) -> dict:
        raw = Path(path).read_bytes()
        payload, kid = verify_pack(raw, self.trusted())
        exp = payload.get("expires")
        if exp and time.strftime("%Y-%m-%d") > exp[:10]:
            raise PackError(f"This pack expired on {exp[:10]}. Ask the publisher for a newer one.")
        serials = self.cfg.get("intel_serials") or {}
        slot = f"{kid}:{payload['name']}"
        if payload["serial"] <= int(serials.get(slot, 0)):
            raise PackError(f"Rollback blocked: pack serial {payload['serial']} is not newer than the installed serial {serials.get(slot)}.")
        dest = self.dir / (re.sub(r"[^A-Za-z0-9._-]", "_", slot) + ".grpack")
        tmp = dest.with_name(dest.name + ".tmp")
        tmp.write_bytes(raw)
        tmp.replace(dest)
        serials[slot] = payload["serial"]
        self.cfg.set("intel_serials", serials)
        info = {"name": payload["name"], "serial": payload["serial"], "key": kid, "hashes": len(payload["hashes"]),
                "domains": len(payload["domains"]), "ips": len(payload["ips"]), "rules": len(payload["rules"])}
        self.bus.emit("INFO", "Threat Intel", f"Installed signed pack '{info['name']}' #{info['serial']}: {info['hashes']} hashes, "
                                              f"{info['domains']} domains, {info['ips']} IPs, {info['rules']} rules")
        return info

    def load_all(self):
        """Verify every installed pack again and merge them. Invalid packs are skipped and reported."""
        keys = self.trusted()
        blobs = []
        for f in sorted(self.dir.glob("*.grpack")):
            try:
                blobs.append((f, f.read_bytes()))
            except OSError:
                continue
        # keyed on file CONTENT (not size/time, which an attacker could preserve) so edits are always noticed
        stamp = (tuple(keys), tuple((f.name, hashlib.sha256(b).hexdigest()) for f, b in blobs))
        if self._cache[0] == stamp:
            return self._cache[1]
        agg = {"hashes": {}, "domains": set(), "ips": set(), "rules": [], "packs": [], "rejected": []}
        for f, raw in blobs:
            try:
                payload, kid = verify_pack(raw, keys)
            except (PackError, OSError) as e:
                agg["rejected"].append((f.name, str(e)))
                self.bus.emit("THREAT", "Threat Intel", f"Installed pack {f.name} FAILED verification and is ignored: {e}")
                continue
            for h in payload["hashes"]:
                agg["hashes"][h["sha256"]] = f"{h['name']} [pack {payload['name']}]"
            agg["domains"].update(payload["domains"])
            agg["ips"].update(payload["ips"])
            for r in payload["rules"]:
                agg["rules"].append(dict(r, name=f"{r['name']} [pack {payload['name']}]"))
            agg["packs"].append({"name": payload["name"], "serial": payload["serial"], "key": kid, "expires": payload.get("expires", "")})
        self._cache = (stamp, agg)
        return agg


# --------------------------------------------------------------------------- optional public hash feed (HTTPS, unsigned)
DEFAULT_FEEDS = ["https://bazaar.abuse.ch/export/txt/sha256/recent/"]


def fetch_hash_feed(url: str, limit=2_000_000):
    """Download a plain list of SHA-256 hashes (one per line, '#' comments allowed). HTTPS only."""
    if not url.lower().startswith("https://"):
        raise PackError("Hash feeds must use https://")
    req = urllib.request.Request(url, headers={"User-Agent": "GreenRook"})
    with urllib.request.urlopen(req, timeout=30) as r:
        text = r.read(limit * 70).decode("utf-8", "ignore")
    found = set()
    for line in text.splitlines():
        t = line.split("#", 1)[0].strip().lower()
        if SHA_RE.match(t):
            found.add(t)
        if len(found) >= limit:
            break
    if not found:
        raise PackError("The feed did not contain any SHA-256 hashes (it may now require an account key)")
    return found
