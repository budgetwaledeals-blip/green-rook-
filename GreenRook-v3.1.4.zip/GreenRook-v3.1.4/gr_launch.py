"""Local single-instance handoff for Green Rook's desktop window."""
from __future__ import annotations

import queue
import socket
import threading
import time
from typing import Optional, Tuple

DEFAULT_ADDRESS = ("127.0.0.1", 47653)
VALID_REQUESTS = {"SHOW", "ADMIN"}


def bind_instance_socket(address: Tuple[str, int] = DEFAULT_ADDRESS, wait: float = 0.0,
                         poll: float = 0.2) -> Optional[socket.socket]:
    """Claim and listen on the local instance address; optionally wait for the old app to exit."""
    deadline = time.monotonic() + max(0.0, wait)
    while True:
        listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
                listener.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            listener.bind(address)
            listener.listen(8)
            listener.settimeout(0.4)
            return listener
        except OSError:
            listener.close()
            if time.monotonic() >= deadline:
                return None
            time.sleep(min(poll, max(0.0, deadline - time.monotonic())))


def send_instance_request(address: Tuple[str, int], request: str, timeout: float = 1.5) -> bool:
    """Ask the existing window to show itself. Returns True only after it accepts the request."""
    request = request.upper()
    if request not in VALID_REQUESTS:
        return False
    try:
        with socket.create_connection(address, timeout=timeout) as conn:
            conn.settimeout(timeout)
            conn.sendall((request + "\n").encode("ascii"))
            return conn.recv(8) == b"OK"
    except OSError:
        return False


def serve_instance_requests(listener: socket.socket, inbox: queue.Queue, stop: threading.Event) -> None:
    """Accept short local commands and put them in the UI thread's queue."""
    while not stop.is_set():
        try:
            conn, _ = listener.accept()
        except socket.timeout:
            continue
        except OSError:
            return
        with conn:
            try:
                conn.settimeout(1.0)
                request = conn.recv(32).decode("ascii", "ignore").strip().upper()
                if request in VALID_REQUESTS:
                    inbox.put(request)
                    conn.sendall(b"OK")
                else:
                    conn.sendall(b"NO")
            except OSError:
                pass
