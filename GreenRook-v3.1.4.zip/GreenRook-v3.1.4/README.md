# Green Rook Antivirus (v3.1.4)

A free desktop security tool for Windows, Linux and macOS. Version 3.1 refreshes the desktop interface with grouped navigation, a clearer Home dashboard, a live scan view, and consistent status and empty states. Version 3 adds **Privacy shield** for the seven topics in the attached screenshots, signature-based false-alarm protection, and safer warning behavior. No paid subscription or account is required. Green Rook is an extra layer beside your operating system's own security, not a promise of perfect protection.

## Install and run (3 steps)
1. **Download** `GreenRook.zip` and unzip it (right-click > Extract All).
2. **Double-click `Install.bat`** (Windows). It installs everything for your Windows account and adds Green Rook to the Desktop and Start Menu. The regular install does not need administrator permission.
   (Linux/macOS: run `python3 gr_setup.py`.)
3. **Double-click the Green Rook icon** on your Desktop, then press **Scan my computer**. If the window does not appear, check `%APPDATA%\GreenRook\startup-error.log` for the startup details.

After opening the app, use **Privacy shield** for the added checks. Nothing is changed until you choose a fix.

To remove it: double-click `Uninstall.bat`, or Settings > Apps > Green Rook.

Needs Python 3.9 or newer on Windows (https://www.python.org/downloads/, tick "Add python.exe to PATH").

The `extras/` folder holds optional tools: `Build-EXE.bat` (one single `GreenRook.exe`), `Run-SelfTest.bat`,
`Unblock-Files.bat` (only if Windows says "app blocked"), and `build-windows.yml` (free cloud build of a Windows installer on GitHub).

## The screens
| Screen | What you do there |
|---|---|
| **Home** | See if you are protected. **Scan my computer**, **Full scan**. If threats were found: **Clean all**, **Review**, **Delete all**. Switch live protections on or off. |
| **Scan** | Quick scan, full scan, or scan one file or folder. Click a result to read why it was flagged. **Clean selected / Clean all** (lock away, can be undone), **Delete selected** (erase for good), **This file is safe**, **Save report**. |
| **Quarantine** | Files that were locked away. **Restore** or **Delete**. |
| **Ultra Rook** | Hide your internet address: connect through a private (WireGuard) server, see what address websites see, get warned if the connection drops. |
| **Camera & USB** | Camera alerts and drive scanning, and the camera apps you allowed. |
| **Attack blocker** | 13 rules against common attacker tricks. For each: Block / Ask me / Log only / Off. |
| **Running programs** | Everything running now. Scan or stop a program. |
| **Health check** | Read-only check of your PC's security settings, and a self-test of Green Rook. |
| **Privacy shield** | Review browser-saved password counts, cookies, camera/microphone permissions, remote access, likely sensitive documents, DNS and firewall. Review each suggested action before applying it. |
| **History** | Everything Green Rook noticed and did. |
| **Settings** | Watched folders, automatic scans, PIN, signed security updates, tools. |

## What changed in version 3

- **Privacy shield:** seven local checks for the exact topics shown in the screenshots. Passwords are counted, not opened or uploaded; cookie counts are local. It does not claim a password has been breached - the browser's own free password checkup can verify that.
- **Fewer false alarms:** on Windows, the scanner checks software signatures and Windows security catalogs. Heuristic guesses about a verified signed program are not shown; known-malware fingerprints are still reported. Guesses about operating-system files that cannot be checked are suppressed.
- **No guessed clean-up of Windows:** an unconfirmed guess cannot quarantine a Windows/system file or a verified signed program. Permanent deletion still requires confirmation.
- **Less warning spam:** repeated identical notices are throttled, the same blocking decision is remembered briefly, and an unanswered ordinary warning chooses the non-destructive option. The ransomware shield still stops a suspected file-encrypting process if its urgent prompt times out.
- **Optional, reviewed fixes:** users may clear cookies, block camera/microphone access for their Windows account, turn off Remote Desktop, enable the Windows firewall, add public-network stealth rules, switch physical network adapters to free Quad9 DNS, or remove suspicious hosts-file redirects. Windows asks for administrator approval where needed. Green Rook saves undo information for DNS/firewall/Remote Desktop changes; hosts-file edits keep a backup.
- **Private document safe:** the local check looks at filenames and small text files for likely sensitive information. It does not read document contents such as PDFs or images. You choose files and confirm before password-locking them; forgotten passwords cannot be recovered.

All checks are local and free. Quad9 is an optional free DNS resolver; it is not operated by Green Rook. Browser password breach checks depend on the browser provider. Camera, DNS and firewall settings that Green Rook can change vary by operating system; the app tells you when it cannot make a change itself. No antivirus can guarantee 100% protection, and this user-mode app cannot replace Microsoft Defender or system updates.

## Real-time protection (always running in the background)
| Live protection | What it does | How often it looks |
|---|---|---|
| **File watcher** | Checks every new or changed file in Downloads, Desktop and Temp (add more folders in Settings) once it has finished writing. Clear malware is locked away; anything uncertain asks you first. | every 2.5 s |
| **Program blocker** | Looks at each program the moment it starts. Risky ones are paused, judged by the scan engine and the 13 attack rules, then allowed or ended. | every 0.6 s |
| **Ransomware shield** | Hidden bait files plus mass-change detection. Also notices documents being overwritten with scrambled (encrypted) data and ransom-note file names. The program doing it is paused and you decide. | every 1.5 s |
| **Start-up watcher** | Run keys, Startup folders, scheduled tasks (Windows); autostart, systemd, cron (Linux/macOS). Suspicious new entries are removed or flagged. | every 4 s |
| **USB drive scanner** | Scans any drive the moment it is plugged in; programs that start from a drive are paused. | every 3 s |
| **Network watcher** | Hidden remote-control shells, known-bad websites and addresses (list in Settings), and **worm-style scanning** (one program contacting 20+ computers on file-sharing / remote-desktop ports within 30 s). | every 4 s |
| **Camera alerts** | Alert, plus a button to stop the app, the moment anything uses the webcam. | every 1.5 s |
| **Ultra Rook watcher** | If Ultra Rook is meant to be on and the tunnel drops, you are told at once (your real address is exposed). | every 5 s |
| **Self-protection** | Settings are signed (edits are undone and reported), program files are checked against `MANIFEST.sha256`, and a watchdog restarts Green Rook if it is killed. Turning a protection off asks for confirmation and an optional PIN. | every 15 s |

On demand: the online fingerprint check during scans (only a file's SHA-256 is sent, over DNS, to Team Cymru), and
signed security updates.

**What "real time" means here:** Green Rook watches by checking again and again (0.6 to 15 seconds, see the table). It does not run
inside the operating system's kernel, so a very fast program can run for a moment before it is caught. It is designed to run
next to Microsoft Defender, not to replace it.

## If Windows blocks something
| What you see | Do this |
|---|---|
| "Windows protected your PC" / app blocked | Double-click `extras/Unblock-Files.bat` once, then run Install.bat again. |
| A file cannot be deleted or quarantined | In the app: **Settings -> Restart as administrator** (or right-click the icon > Run as administrator). |
| Still blocked in Documents / Desktop / Pictures | Windows Security -> Ransomware protection -> Controlled folder access -> Allow an app -> add `pythonw.exe` or `GreenRook.exe`. |
| "File is in use" | Close the program using it. If it is a system file, Green Rook schedules the delete for the next restart. |
| Defender removed the file first | Fine - it is handled. Both can run side by side. |

Green Rook tries harder before giving up: it retries while antivirus or the indexer holds a file, clears read-only flags, takes ownership,
and (as administrator) schedules removal at the next restart. If the original cannot be removed, nothing is changed and you are told why.

## Ultra Rook (hide your address) - free
Ultra Rook hides your internet address from websites. It has two modes (switch at the top of the page):

**Free (Tor) - default, costs nothing, no account, no server.** Uses Tor, a free network run by volunteers. Press **Connect**; your browsers
are sent through Tor and Tor's own checker confirms it worked. On Windows the page installs the Tor engine for you with one button (it comes with Tor Browser).
- Covers programs that use the PC's proxy settings (Edge, Chrome, Firefox...). Not games, torrents or system services.
- Slower than normal; a few websites block Tor. For the strongest privacy browse with Tor Browser.
- Your old proxy setting is saved and always put back: on disconnect, if Tor stops, and after a crash.

**My own server (WireGuard) - advanced.** Sends ALL traffic through a server you choose. This needs a server (from a VPN company, or a small one you rent
and set up with `tools/ultrarook_makeconf.py`). Files with command hooks are refused, keys are stored encrypted, and the app checks your address really changed.

Both modes warn you if the connection drops. There is no automatic kill switch. It is not total anonymity and not an antivirus.
Developers: `sudo WG_QUICK_USERSPACE_IMPLEMENTATION=wireguard-go python3 tests/e2e_tunnel.py` runs a real WireGuard tunnel between simulated machines.

## Safety rules Green Rook follows
- **Clean is reversible.** Quarantined files are encrypted and can be restored byte-for-byte.
- **Guesses never delete.** Only hard evidence (known virus fingerprint, signature, EICAR) outside Windows/system folders is removed
  automatically. Anything based on behaviour only asks you first.
- **Delete** asks for confirmation, refuses folders and Green Rook's own files, and asks again for system folders.
- Critical Windows/Linux processes are never ended automatically.

## What else is included (full list: CHANGELOG.md)
Office macro analysis (Melissa-style), script-worm detection (ILOVEYOU-style), signed security updates (Ed25519, with rollback
protection; `tools/grsign.py` makes keys and packs), scan reports (HTML/JSON), a command line (`greenrook_cli.py`), and a built-in
self-test.

## Test it in five minutes
1. `extras/Run-SelfTest.bat` (or `python greenrook_cli.py selftest`) -> expect `21/21 checks passed`.
2. Start the app. **Settings -> Create a safe test virus** -> within seconds it is locked away (see **Quarantine**).
3. Put a few files in a folder, **Scan -> Scan a folder...**, click a result, read the explanation, try **Clean** and **Delete**.
4. Signed updates (files in `samples/`): **Settings -> Trust a publisher** -> `demo_publisher.pub`; **Install an update file** ->
   `demo_feed.grpack`; then **Scan a file** -> `demo_sample.txt` is reported (it is a harmless text file) and `rule_marker.txt`
   triggers the signed rule. `demo_feed_TAMPERED.grpack` must be refused. The demo private key was never saved anywhere.
5. **Health check -> Check my PC's settings**.
6. Developers: `python -m unittest discover -s tests -v` and `xvfb-run -a python tests/gui_smoke.py`. After editing a `.py` file
   run `python tools/make_manifest.py` (self-protection checks `MANIFEST.sha256`).

## Honest limits
- Nothing is "unbreakable". Green Rook is a normal (user-mode) program. Malware with the same or higher rights can stop it or edit its files;
  it raises the bar and tells you when something tampers with it.
- Worm-scan detection sees TCP only (not UDP floods like Slammer). It does not inspect memory, encrypted traffic or firmware.
- Macro analysis does not run anything, cannot read password-protected projects, and was tested on synthetic documents (cross-checked
  against the open-source `olefile` and `oletools`), not real malware.
- Windows-only parts (registry health checks, camera and scheduled-task watchers, hosts-file blocking, the .exe build) were not run in the
  Linux test environment used for 2.1. The optional public virus list (MalwareBazaar) may need an account key by now; it fails safely.

Data (settings, quarantine, logs) lives in `%APPDATA%\GreenRook` (Windows) or `~/.greenrook`, locked to your user account.
