"""
Green Rook - ULTRA ROOK: a private-network (VPN) client built on WireGuard.

What it does:   sends all your internet traffic through an encrypted tunnel to a server you choose, so websites see the
                SERVER's address instead of yours, and your internet provider / café Wi-Fi cannot read your traffic.
What it needs:  (1) the free WireGuard program (wireguard.com/install), and (2) a WireGuard server - from a VPN provider you trust
                or one you run yourself (tools/ultrarook_makeconf.py writes the files for your own). No app can hide an address
                without a server somewhere: that is how every VPN works.
What it is NOT: not anonymity. The server's owner can see which sites you visit. It does not stop malware, and it does not
                make illegal things legal.

Safety rules built in:
  * client files are checked strictly. Command hooks (PreUp / PostUp / PreDown / PostDown) are REFUSED: on Linux, wg-quick would run
    them as root, so an untrusted .conf could take over the PC.
  * profiles are stored encrypted (AES-256-GCM, the same vault key as quarantine); the plain file exists only while connected.
  * after connecting, the app checks that your public address really changed, and warns if it did not.
  * if the tunnel drops while you wanted it on, you are told straight away (your real address is exposed).
"""
import base64
import ipaddress
import os
import re
import secrets
import shutil
import subprocess
import time
import urllib.request
import uuid
from pathlib import Path

from gr_core import IS_LINUX, IS_WIN, Service, data_dir

TUNNEL = "UltraRook" if IS_WIN else "ultrarook"
NO_WINDOW = 0x08000000
IP_URLS = ["https://api.ipify.org", "https://icanhazip.com", "https://ifconfig.me/ip"]
HOOK_KEYS = {"preup", "postup", "predown", "postdown", "saveconfig"}
INTERFACE_KEYS = {"privatekey", "address", "dns", "mtu", "listenport"}
PEER_KEYS = {"publickey", "presharedkey", "allowedips", "endpoint", "persistentkeepalive"}
HOST_RE = re.compile(r"^(?=.{1,253}$)([A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?)(\.[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*$")


class UltraError(Exception):
    """Message is written for the person using the app."""


# ------------------------------------------------------------------ config validation
def _key(value, what):
    try:
        raw = base64.b64decode(value.strip(), validate=True)
    except Exception:
        raw = b""
    if len(raw) != 32:
        raise UltraError(f"The {what} is not a valid WireGuard key (it should be 44 characters ending in '=').")
    return value.strip()


def _endpoint(value):
    m = re.fullmatch(r"\[([0-9a-fA-F:.]+)\]:(\d{1,5})", value.strip()) or re.fullmatch(r"([^:\s\[\]]+):(\d{1,5})", value.strip())
    if not m:
        raise UltraError("The server address (Endpoint) should look like  vpn.example.com:51820  or  203.0.113.5:51820.")
    host, port = m.group(1), int(m.group(2))
    if not 1 <= port <= 65535:
        raise UltraError("The server port must be between 1 and 65535.")
    try:
        ipaddress.ip_address(host)
    except ValueError:
        if not HOST_RE.match(host):
            raise UltraError("The server name in Endpoint is not valid.") from None
    return value.strip()


def parse_wg_conf(text: str) -> dict:
    """Strictly validate a WireGuard client file. Returns a clean dict; raises UltraError with plain advice."""
    if len(text) > 20000:
        raise UltraError("That file is far too large to be a WireGuard config.")
    sections, cur = [], None
    for n, line in enumerate(text.splitlines(), 1):
        line = line.split("#", 1)[0].strip()
        if not line:
            continue
        m = re.fullmatch(r"\[(\w+)\]", line)
        if m:
            name = m.group(1).lower()
            if name not in ("interface", "peer"):
                raise UltraError(f"Line {n}: unknown section [{m.group(1)}].")
            cur = {"_type": name}
            sections.append(cur)
            continue
        if cur is None or "=" not in line:
            raise UltraError(f"Line {n} is not understood: '{line[:40]}'.")
        k, v = (x.strip() for x in line.split("=", 1))
        kl = k.lower()
        if kl in HOOK_KEYS:
            raise UltraError(f"This file contains a command hook ({k}). Those can run programs on your PC with full rights, so Ultra Rook "
                             "refuses it. Ask your VPN provider for a plain client config, or delete that line if you wrote it yourself.")
        allowed = INTERFACE_KEYS if cur["_type"] == "interface" else PEER_KEYS
        if kl not in allowed:
            raise UltraError(f"Line {n}: '{k}' is not a setting Ultra Rook accepts.")
        cur[kl] = v
    ifaces = [s for s in sections if s["_type"] == "interface"]
    peers = [s for s in sections if s["_type"] == "peer"]
    if len(ifaces) != 1 or not peers:
        raise UltraError("A WireGuard client file needs one [Interface] section and at least one [Peer] section.")
    i, warnings = ifaces[0], []
    out = {"interface": {"PrivateKey": _key(i.get("privatekey", ""), "PrivateKey")}, "peers": []}
    if "address" not in i:
        raise UltraError("The file has no Address line.")
    try:
        addrs = [str(ipaddress.ip_interface(a.strip())) for a in i["address"].split(",") if a.strip()]
    except ValueError:
        raise UltraError("The Address line is not valid.") from None
    out["interface"]["Address"] = ", ".join(addrs)
    if "dns" in i:
        dns = [d.strip() for d in i["dns"].split(",") if d.strip()]
        for d in dns:
            try:
                ipaddress.ip_address(d)
            except ValueError:
                if not HOST_RE.match(d):
                    raise UltraError(f"'{d}' in the DNS line is not valid.") from None
        out["interface"]["DNS"] = ", ".join(dns)
    else:
        warnings.append("The file has no DNS line, so your website lookups may still go to your internet provider and reveal where you browse.")
    for key, lo, hi, label in (("mtu", 576, 1500, "MTU"), ("listenport", 1, 65535, "ListenPort")):
        if key in i:
            if not (i[key].isdigit() and lo <= int(i[key]) <= hi):
                raise UltraError(f"{label} must be a number from {lo} to {hi}.")
            out["interface"][label] = i[key]
    full = False
    for p in peers:
        q = {"PublicKey": _key(p.get("publickey", ""), "server PublicKey")}
        if "presharedkey" in p:
            q["PresharedKey"] = _key(p["presharedkey"], "PresharedKey")
        if "endpoint" not in p:
            raise UltraError("The [Peer] section has no Endpoint (the server's address).")
        q["Endpoint"] = _endpoint(p["endpoint"])
        try:
            nets = [ipaddress.ip_network(a.strip(), strict=False) for a in p.get("allowedips", "").split(",") if a.strip()]
        except ValueError:
            raise UltraError("The AllowedIPs line is not valid.") from None
        if not nets:
            raise UltraError("The [Peer] section has no AllowedIPs line.")
        q["AllowedIPs"] = ", ".join(str(n) for n in nets)
        v4 = any(n.prefixlen == 0 and n.version == 4 for n in nets)
        v6 = any(n.prefixlen == 0 and n.version == 6 for n in nets)
        full = full or v4
        if v4 and not v6 and any(ipaddress.ip_interface(a).version == 6 for a in addrs):
            warnings.append("IPv6 is not routed through the tunnel (::/0 is missing from AllowedIPs), so IPv6 websites could see your real address.")
        if "persistentkeepalive" in p:
            if not (p["persistentkeepalive"].isdigit() and int(p["persistentkeepalive"]) <= 65535):
                raise UltraError("PersistentKeepalive must be a number.")
            q["PersistentKeepalive"] = p["persistentkeepalive"]
        out["peers"].append(q)
    if not full:
        warnings.append("Only some of your traffic goes through the tunnel (AllowedIPs does not contain 0.0.0.0/0), so your address is NOT hidden "
                        "for the rest. For full protection AllowedIPs must be 0.0.0.0/0, ::/0.")
    out["endpoint"], out["full_tunnel"], out["has_dns"], out["warnings"] = out["peers"][0]["Endpoint"], full, "DNS" in out["interface"], warnings
    return out


def render_conf(parsed: dict) -> str:
    """Rebuild the file from validated values only, so nothing unexpected can ride along."""
    lines = ["[Interface]"] + [f"{k} = {v}" for k, v in parsed["interface"].items()]
    for p in parsed["peers"]:
        lines += ["", "[Peer]"] + [f"{k} = {v}" for k, v in p.items()]
    return "\n".join(lines) + "\n"


# ------------------------------------------------------------------ public address check
def fetch_public_ip(urls=None, timeout=6):
    """Ask an address-echo service which address the internet sees. Returns the address or None."""
    for url in urls or IP_URLS:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "GreenRook-UltraRook"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                txt = r.read(200).decode("ascii", "ignore").strip()
            return str(ipaddress.ip_address(txt))
        except Exception:
            continue
    return None


# ------------------------------------------------------------------ server file generator (for people who run their own server)
def make_wireguard_pair(host: str, port=51820, dns="1.1.1.1, 1.0.0.1", subnet="10.66.66"):
    """Generate matching server + client WireGuard files and plain-English server steps. Needs the 'cryptography' package."""
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey
    _endpoint(f"{host}:{port}")

    def pair():
        k = X25519PrivateKey.generate()
        priv = k.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption())
        pub = k.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        return base64.b64encode(priv).decode(), base64.b64encode(pub).decode()
    s_priv, s_pub = pair()
    c_priv, c_pub = pair()
    psk = base64.b64encode(secrets.token_bytes(32)).decode()
    out_if = "$(ip route show default | awk '/default/ {print $5; exit}')"
    server = (f"[Interface]\nAddress = {subnet}.1/24\nListenPort = {port}\nPrivateKey = {s_priv}\n"
              f"PostUp = iptables -A FORWARD -i %i -j ACCEPT; iptables -A FORWARD -o %i -j ACCEPT; iptables -t nat -A POSTROUTING -o {out_if} -j MASQUERADE\n"
              f"PostDown = iptables -D FORWARD -i %i -j ACCEPT; iptables -D FORWARD -o %i -j ACCEPT; iptables -t nat -D POSTROUTING -o {out_if} -j MASQUERADE\n\n"
              f"[Peer]\nPublicKey = {c_pub}\nPresharedKey = {psk}\nAllowedIPs = {subnet}.2/32\n")
    client = (f"[Interface]\nPrivateKey = {c_priv}\nAddress = {subnet}.2/32\nDNS = {dns}\n\n"
              f"[Peer]\nPublicKey = {s_pub}\nPresharedKey = {psk}\nEndpoint = {host}:{port}\nAllowedIPs = 0.0.0.0/0, ::/0\nPersistentKeepalive = 25\n")
    steps = f"""ULTRA ROOK - SET UP YOUR OWN SERVER  (about 10 minutes)
================================================================
You need a small Linux server with a fixed internet address ({host}). Any $4-6/month "VPS" running Ubuntu or Debian works.
Pick a data-centre in the country you want websites to think you are in.

On the SERVER (log in with ssh), run these commands one by one:

  sudo apt update && sudo apt install -y wireguard iptables
  # copy the file 'server-wg0.conf' from this folder to the server as /etc/wireguard/wg0.conf, then:
  sudo chmod 600 /etc/wireguard/wg0.conf
  echo 'net.ipv4.ip_forward=1' | sudo tee /etc/sysctl.d/99-wireguard.conf && sudo sysctl --system
  sudo ufw allow {port}/udp        # skip if you do not use ufw; also open UDP {port} in your provider's firewall
  sudo systemctl enable --now wg-quick@wg0
  sudo wg show                     # should list one peer

On THIS PC:  open Green Rook > Ultra Rook > "Add a server file" and choose 'client.conf' from this folder. Then press Connect.

Keep 'server-wg0.conf' and 'client.conf' private: they contain secret keys. Delete the copies on this PC once installed.
Remember: whoever runs the server can see which sites you visit. Here that is you, which is the point.
"""
    return server, client, steps


# ------------------------------------------------------------------ profiles (encrypted at rest)
class Profiles:
    def __init__(self, cfg, vault, folder=None):
        self.cfg, self.vault = cfg, vault
        self.dir = Path(folder or data_dir()) / "ultrarook"
        self.dir.mkdir(parents=True, exist_ok=True)

    def list(self):
        return list(self.cfg.get("ultra_profiles") or [])

    def add(self, name: str, conf_text: str) -> dict:
        parsed = parse_wg_conf(conf_text)
        name = re.sub(r"[^\w .-]", "", name).strip()[:40] or "My server"
        pid = uuid.uuid4().hex[:10]
        (self.dir / f"{pid}.enc").write_bytes(self.vault.encrypt(render_conf(parsed).encode()))
        entry = {"id": pid, "name": name, "endpoint": parsed["endpoint"], "full": parsed["full_tunnel"], "dns": parsed["has_dns"],
                 "added": time.strftime("%Y-%m-%d"), "warnings": parsed["warnings"]}
        self.cfg.set("ultra_profiles", self.list() + [entry])
        if not self.cfg.get("ultra_active"):
            self.cfg.set("ultra_active", pid)
        return entry

    def load(self, pid: str) -> str:
        try:
            return self.vault.decrypt((self.dir / f"{pid}.enc").read_bytes()).decode()
        except Exception as e:
            raise UltraError("That server's saved file could not be opened (it may be damaged). Remove it and add it again.") from e

    def remove(self, pid: str):
        (self.dir / f"{pid}.enc").unlink(missing_ok=True)
        self.cfg.set("ultra_profiles", [p for p in self.list() if p["id"] != pid])
        if self.cfg.get("ultra_active") == pid:
            rest = self.list()
            self.cfg.set("ultra_active", rest[0]["id"] if rest else "")


# ------------------------------------------------------------------ controlling the tunnel
def _wg_windows():
    for base in (os.environ.get("ProgramFiles", r"C:\Program Files"), os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")):
        p = Path(base) / "WireGuard" / "wireguard.exe"
        if p.exists():
            return str(p)
    return None


def wireguard_tool():
    """Path of the WireGuard program, or None if it is not installed."""
    if IS_WIN:
        return _wg_windows()
    return shutil.which("wg-quick") if IS_LINUX and shutil.which("wg") else None


def is_admin() -> bool:
    try:
        if IS_WIN:
            import ctypes
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        return os.geteuid() == 0
    except Exception:
        return False


def conf_file() -> Path:
    d = Path(data_dir()) / "ultrarook"
    d.mkdir(parents=True, exist_ok=True)
    return d / f"{TUNNEL}.conf"


def tunnel_up() -> bool:
    try:
        if IS_WIN:
            r = subprocess.run(["sc", "query", f"WireGuardTunnel${TUNNEL}"], capture_output=True, text=True, creationflags=NO_WINDOW, timeout=10)
            return "RUNNING" in r.stdout
        return Path(f"/sys/class/net/{TUNNEL}").exists()
    except Exception:
        return False


def _wait(want_up: bool, seconds: float) -> bool:
    end = time.time() + seconds
    while time.time() < end:
        if tunnel_up() == want_up:
            return True
        time.sleep(0.4)
    return tunnel_up() == want_up


def _run_windows(args):
    """Run wireguard.exe; ask Windows for administrator permission (UAC) if we do not have it."""
    exe = wireguard_tool()
    if is_admin():
        r = subprocess.run([exe, *args], capture_output=True, text=True, creationflags=NO_WINDOW, timeout=60)
        return r.returncode == 0, (r.stderr or r.stdout).strip()
    import ctypes
    quoted = " ".join(f'"{a}"' if " " in a else a for a in args)
    rc = ctypes.windll.shell32.ShellExecuteW(None, "runas", exe, quoted, None, 0)
    return rc > 32, "" if rc > 32 else "Windows did not get permission (the permission window was closed or declined)."


def _linux_cmd(cmd):
    if os.geteuid() == 0:
        return cmd
    if shutil.which("pkexec"):
        return ["pkexec", *cmd]
    return ["sudo", "-n", *cmd]


def connect(conf_text: str) -> str:
    """Bring the tunnel up. Returns a short success message or raises UltraError."""
    if not wireguard_tool():
        raise UltraError("WireGuard is not installed yet. Use the 'Install WireGuard (free)' button first.")
    if tunnel_up():
        raise UltraError("Ultra Rook is already connected.")
    parse_wg_conf(conf_text)                               # never write an unchecked file
    path = conf_file()
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        f.write(conf_text)
    ok, err = False, ""
    try:
        if IS_WIN:
            ok, err = _run_windows(["/installtunnelservice", str(path)])
            ok = ok and _wait(True, 25)
        else:
            r = subprocess.run(_linux_cmd([wireguard_tool(), "up", str(path)]), capture_output=True, text=True, timeout=60)
            ok, err = r.returncode == 0 and _wait(True, 8), (r.stderr or r.stdout).strip()
    except (OSError, subprocess.TimeoutExpired) as e:
        err = str(e)
    if not ok:
        path.unlink(missing_ok=True)
        lines = [ln.strip() for ln in err.splitlines() if ln.strip() and not ln.startswith("[#]")]    # skip wg-quick's command echo
        tail = lines[-1] if lines else ""
        if "password" in err.lower() or "sudo" in err.lower() or "pkexec" in err.lower():
            raise UltraError("Ultra Rook needs administrator rights to create the tunnel. Start Green Rook as administrator (or with sudo).")
        raise UltraError("The tunnel could not be started." + (f" ({tail})" if tail else " Check that the server is running and the address is right."))
    return "Connected."


def disconnect() -> str:
    path = conf_file()
    if not tunnel_up():
        path.unlink(missing_ok=True)
        return "Already disconnected."
    try:
        if IS_WIN:
            _run_windows(["/uninstalltunnelservice", TUNNEL])
            down = _wait(False, 20)
        else:
            subprocess.run(_linux_cmd([wireguard_tool(), "down", str(path)]), capture_output=True, text=True, timeout=60)
            down = _wait(False, 8)
    except (OSError, subprocess.TimeoutExpired):
        down = False
    if down:
        path.unlink(missing_ok=True)
        return "Disconnected."
    raise UltraError("Could not disconnect cleanly. Start Green Rook as administrator and try again.")


def verify_hidden(before_ip, after_ip):
    """Compare public addresses. Returns (ok, plain-English sentence)."""
    if not after_ip:
        return False, "Connected, but the address check could not reach the internet. Check that the server forwards traffic."
    if before_ip and after_ip == before_ip:
        return False, (f"WARNING: your public address did not change ({after_ip}). The tunnel is up but not carrying your traffic. "
                       "Make sure the file's AllowedIPs is 0.0.0.0/0, ::/0 and the server has forwarding switched on.")
    return True, f"Your public address is now {after_ip}" + (f" (it was {before_ip})." if before_ip else ".")


# ------------------------------------------------------------------ watcher: tell the user if the tunnel drops
class UltraRookWatch(Service):
    interval = 5.0

    def __init__(self, cfg, bus):
        super().__init__("UltraRookWatch", True)
        self.cfg, self.bus, self.alerted = cfg, bus, False

    def tick(self):
        if not self.cfg.get("ultra_want"):
            self.alerted = False
            return
        if tunnel_up():
            self.alerted = False
        elif not self.alerted:
            self.alerted = True
            self.bus.emit("THREAT", "Ultra Rook", "The tunnel dropped. Your real address is visible until you reconnect.")
            self.bus.notify("bad", "Ultra Rook disconnected", "Your real address is exposed. Open Ultra Rook and press Connect.")
