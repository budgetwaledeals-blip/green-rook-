@echo off
setlocal
title Install Green Rook
cd /d "%~dp0"
echo.
echo   Installing Green Rook Antivirus...
echo.
if not exist "%~dp0gr_setup.py" (
  echo   The installer files are missing. This usually means Install.bat was opened from inside the ZIP.
  echo   Right-click the ZIP, choose "Extract All", open the extracted folder, then run Install.bat again.
  echo.
  pause
  exit /b 1
)
set "GR_PY="
py -3 -c "import sys" >nul 2>&1 && set "GR_PY=py -3"
if not defined GR_PY python -c "import sys" >nul 2>&1 && set "GR_PY=python"
if not defined GR_PY (
  echo   Python 3.9 or newer was not found.
  echo   Install it from https://www.python.org/downloads/ and tick "Add python.exe to PATH", then run Install.bat again.
  echo.
  pause
  exit /b 1
)
%GR_PY% gr_setup.py --yes
set "GR_RESULT=%errorlevel%"
if "%GR_RESULT%"=="0" (
  echo.
  echo   Green Rook is open. This installer will close in 5 seconds.
  timeout /t 5 /nobreak >nul
  exit /b 0
)
echo.
if "%GR_RESULT%"=="2" (
  echo   Green Rook installed, but its window did not open.
  echo   The details are shown above and saved in %%APPDATA%%\GreenRook\startup-error.log
) else (
  echo   Install did not finish. The reason is shown above.
)
echo   Please copy the text in this window when reporting the problem.
echo.
pause
exit /b %GR_RESULT%
