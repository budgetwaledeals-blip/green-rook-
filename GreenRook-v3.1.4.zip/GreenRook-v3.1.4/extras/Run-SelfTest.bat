@echo off
cd /d "%~dp0\.."
python greenrook_cli.py selftest
pause
