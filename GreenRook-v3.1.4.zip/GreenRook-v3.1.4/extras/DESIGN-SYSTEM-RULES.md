# Green Rook design-system rules (for Figma / design-to-code work)

**Stack:** Python 3 + Tkinter/ttk, no web frameworks, no bundler (PyInstaller only for the optional .exe). Styling is code, not CSS.

## 1. Tokens - `gr_ui.py` (top of file)
```python
BG, SIDE, CARD, CARD2, LINE = "#09140f", "#07100c", "#102018", "#192c21", "#2a4936"   # surfaces
FG, MUTED, FAINT = "#eaf6ee", "#a5bead", "#789180"                                  # text
ACCENT, ACCENT_D = "#43df88", "#259b59"; GOOD, WARN, BAD, INFO = "#3ddc84", "#f5b942", "#ef5350", "#5aa9e6"
FONT = "Segoe UI" (Windows) / "Helvetica Neue" (Mac) / "DejaVu Sans"; MONO = Consolas / Menlo / DejaVu Sans Mono
```
Plain Python constants, no transform pipeline. Map Figma colour styles to these names; never hard-code hex in pages.
Sizes in use: page padding 28x20; card padding 16x14; sidebar 232 px; buttons 32 / 40 / 52 high; radius 8-12; page title 21 bold, body 9-10, captions 8-9.

## 2. Components - `gr_ui.py`
`Btn` (kinds: primary, danger, neutral, ghost, warn; optional icon; `big=True`), `Switch` (toggle), `Seg` (segmented choice), `Hero` (animated status rook),
`ScrollFrame`, `card()`, `label()`, `icon_badge()`, `Toast`, `PromptDialog`, `rrect()` (rounded rectangle), `blend()`, `draw_rook()`.
Pages are methods `page_*` in `greenrook.py` (one per sidebar item, listed in `PAGES`). Use `card(parent)` + `label(...)` + `Btn(...)`; do not create raw `tk.Button`.
No Storybook; `tests/gui_smoke.py` builds every page under a virtual display, and screenshots are taken with `xvfb-run` + `import -window root`.

## 3. Icons - drawn in code, no files
`draw_icon(canvas, name, cx, cy, size, color)` on a 24x24 grid. Names: home, scan, shield, trash, globe, camera, block, list, pulse, clock, sliders, lock,
folder, file, check, warn, usb, eye, vpn, bolt, refresh, plus. To add one, add an `elif name == "..."` branch with `line()/poly()/oval()` calls.
Nav items use `(key, label, icon)` tuples in `PAGES`; protection cards use `SHIELDS`.

## 4. App icon / assets
`greenrook.png` (512) and `greenrook.ico` (7 sizes) at the project root; vector master and sizes in `extras/icon/` (`make_icon.py` regenerates all). No CDN, no remote assets, no optimisation step.

## 5. Layout rules
Pack action buttons `side="bottom"` BEFORE the expanding table so they are never pushed off-screen. Wrap long text with `wraplength`. Scrolling pages use `ScrollFrame`.
Keep words plain (no jargon); verdict words are Dangerous / Suspicious.

## 6. Figma -> code mapping
Frame -> `card()`; Auto-layout row -> `tk.Frame` with `side="left"` packs; corner radius -> `rrect()` radius; fills -> token constants; text styles -> `(FONT, size, "bold")`.
Responsive: window minimum 1100x660, content stretches (`fill="x"`/`expand=True`); there are no breakpoints.

## 7. Project structure
`greenrook.py` (app + pages) - `gr_ui.py` (toolkit) - `gr_core.py` (engine, vault, settings) - `gr_guards.py` (live protections) - `gr_ultra.py` + `gr_tor.py` (Ultra Rook) -
`gr_office.py`, `gr_intel.py`, `gr_health.py`, `gr_report.py`, `gr_selftest.py`, `gr_setup.py` - `tests/` - `tools/` - `extras/`.
