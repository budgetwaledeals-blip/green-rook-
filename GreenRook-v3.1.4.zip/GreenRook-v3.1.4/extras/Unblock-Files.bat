@echo off
rem Only needed if Windows says "app blocked" for files that came from the internet. Removes that mark.
cd /d "%~dp0\.."
powershell -NoProfile -Command "Get-ChildItem -LiteralPath '%cd%' -Recurse -File | Unblock-File"
echo Done.
pause
