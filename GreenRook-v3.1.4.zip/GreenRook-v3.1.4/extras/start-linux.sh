#!/bin/sh
# Linux/macOS: run Green Rook straight from this folder (without installing it).
cd "$(dirname "$0")/.." && exec python3 greenrook.py
