#!/usr/bin/env python3
"""
Green Rook icon generator. Draws the icon at any size (anti-aliased by drawing 4x larger and shrinking), writes the PNGs, the multi-size
Windows .ico and the SVG master.   Run:  python extras/icon/make_icon.py        (needs: pip install pillow numpy)

Design: a deep-green rounded tile (the app), a white chess ROOK (the castle: the name), and a green CHECK on its body (protected).
"""
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
sys.path.insert(0, str(ROOT))
from gr_ui import ROOK, ROOK_HI  # noqa: E402  (same rook outline as the in-app logo, so the brand matches everywhere)

# name: (tile top-left, tile bottom-right, check mark)
THEMES = {
    "green": ((52, 214, 126), (7, 70, 42), (14, 128, 72)),
    "blue": ((84, 170, 255), (10, 48, 120), (22, 92, 190)),
    "purple": ((178, 120, 255), (52, 20, 110), (96, 50, 190)),
    "gold": ((255, 205, 80), (120, 70, 5), (170, 110, 10)),
    "red": ((255, 110, 100), (110, 15, 20), (190, 40, 40)),
    "graphite": ((140, 150, 160), (25, 30, 35), (60, 70, 80)),
}
TOP, BOTTOM, CHECKC = THEMES["green"]
RADIUS = 0.225                                    # corner roundness (fraction of size)
SCALE, CX, CY = 3.55, 50.0, 53.0                  # rook size and centre on the 100-unit grid, as a fraction of the tile (x 0.01)
CHECK = [(37, 60), (47, 70.5), (65, 49.5)]


def tile_gradient(S, top=None, bottom=None):
    y, x = np.mgrid[0:S, 0:S].astype(np.float32) / (S - 1)
    t = np.clip((x * 0.45 + y * 0.55), 0, 1)[..., None]
    rgb = np.array(top or TOP, np.float32) * (1 - t) + np.array(bottom or BOTTOM, np.float32) * t
    return Image.fromarray(rgb.astype(np.uint8), "RGB").convert("RGBA")


def rook_xy(pts, S):
    k = S * SCALE / 100.0 / 3.55 * 0.0 + S / 512.0 * 3.55         # 3.55 px-per-unit at 512 px
    ox, oy = S / 2 - CX * k, S / 2 - CY * k
    return [(ox + x * k, oy + y * k) for x, y in pts], k


def draw(size, ss=4, check=True, theme="green"):
    top, bottom, checkc = THEMES[theme]
    S = size * ss
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    mask = Image.new("L", (S, S), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, S - 1, S - 1], radius=int(S * RADIUS), fill=255)
    img.paste(tile_gradient(S, top, bottom), (0, 0), mask)
    # soft glow at the top for a little depth
    glow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    ImageDraw.Draw(glow).ellipse([-S * 0.2, -S * 0.55, S * 1.2, S * 0.5], fill=(255, 255, 255, 38))
    glow.putalpha(Image.composite(glow.getchannel("A"), Image.new("L", (S, S), 0), mask))
    img = Image.alpha_composite(img, glow)
    pts, k = rook_xy(ROOK, S)
    hi, _ = rook_xy(ROOK_HI, S)
    # drop shadow
    sh = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    ImageDraw.Draw(sh).polygon([(x + S * 0.006, y + S * 0.018) for x, y in pts], fill=(0, 30, 15, 150))
    img = Image.alpha_composite(img, sh.filter(ImageFilter.GaussianBlur(S * 0.012)))
    d = ImageDraw.Draw(img)
    d.polygon(pts, fill=(236, 255, 244, 255))                      # rook body
    d.polygon(hi, fill=(255, 255, 255, 255))                       # lit left face
    d.line([pts[0], pts[-1]], fill=(236, 255, 244, 255), width=1)
    if check:
        c, _ = rook_xy(CHECK, S)
        w = max(2, int(7.2 * k))
        d.line(c, fill=checkc + (255,), width=w, joint="curve")
        for px, py in (c[0], c[-1]):
            d.ellipse([px - w / 2, py - w / 2, px + w / 2, py + w / 2], fill=checkc + (255,))
    return img.resize((size, size), Image.LANCZOS)


SVG = '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="tile" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#34d67e"/><stop offset="1" stop-color="#07462a"/></linearGradient>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="150%"><feGaussianBlur stdDeviation="6"/></filter>
    <clipPath id="clip"><rect width="512" height="512" rx="115" ry="115"/></clipPath>
  </defs>
  <rect width="512" height="512" rx="115" ry="115" fill="url(#tile)"/>
  <ellipse cx="256" cy="-30" rx="360" ry="290" fill="#ffffff" opacity="0.15" clip-path="url(#clip)"/>
  <polygon points="{shadow}" fill="#001e0f" opacity="0.59" filter="url(#shadow)"/>
  <polygon points="{rook}" fill="#ecfff4"/>
  <polygon points="{hi}" fill="#ffffff"/>
  <polyline points="{check}" fill="none" stroke="#0e8048" stroke-width="25.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
'''


def write_svg(path):
    def fmt(pts, dx=0, dy=0):
        p, _ = rook_xy(pts, 512)
        return " ".join(f"{x + dx:.1f},{y + dy:.1f}" for x, y in p)
    path.write_text(SVG.format(rook=fmt(ROOK), hi=fmt(ROOK_HI), shadow=fmt(ROOK, 3, 9), check=fmt(CHECK)))


def main():
    big = draw(1024)
    big.save(HERE / "greenrook-1024.png")
    for s in (512, 256, 128, 64, 48, 32, 24, 16):
        draw(s, ss=8 if s <= 64 else 4).save(HERE / f"greenrook-{s}.png")
    write_svg(HERE / "greenrook.svg")
    draw(512).save(ROOT / "greenrook.png")                          # used by the app window and the Linux menu
    ico = draw(256, ss=4)
    ico.save(ROOT / "greenrook.ico", format="ICO", sizes=[(256, 256), (128, 128), (64, 64), (48, 48), (32, 32), (24, 24), (16, 16)])
    out = ROOT / "icons"                                            # the ready-made choices offered in Settings > Appearance
    out.mkdir(exist_ok=True)
    for name in THEMES:
        draw(256, theme=name).save(out / f"{name}.png")
        draw(44, ss=8, theme=name).save(out / f"{name}-44.png")
        draw(256, theme=name).save(out / f"{name}.ico", format="ICO", sizes=[(256, 256), (128, 128), (64, 64), (48, 48), (32, 32), (24, 24), (16, 16)])
    print("icon written: greenrook.png, greenrook.ico, icons/*, extras/icon/*")


if __name__ == "__main__":
    main()
