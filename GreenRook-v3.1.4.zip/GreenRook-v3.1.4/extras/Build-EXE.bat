@echo off
rem Optional: builds a single GreenRook.exe into the dist folder. Needs Python on this PC.
cd /d "%~dp0\.."
python -m pip install --quiet -r requirements.txt pyinstaller
python -m PyInstaller --noconfirm --onefile --windowed --name GreenRook --icon greenrook.ico --add-data "greenrook.png;." --add-data "greenrook.ico;." --hidden-import gr_core --hidden-import gr_guards --hidden-import gr_office --hidden-import gr_intel --hidden-import gr_health --hidden-import gr_report --hidden-import gr_selftest --hidden-import gr_testkit --hidden-import gr_ui --hidden-import gr_ultra greenrook.py
echo Done: dist\GreenRook.exe
pause
