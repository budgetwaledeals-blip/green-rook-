#!/usr/bin/env python3
"""
End-to-end test of Ultra Rook with a REAL WireGuard tunnel, on one Linux machine using network namespaces:

     [ur_cli: your PC] --ISP link-- [ur_srv: VPN server, NAT] --link-- [ur_net: "the internet" + address-echo service]

Needs: Linux, root, `ip`, `wg`, `wg-quick`, `nft`, and either kernel WireGuard or `wireguard-go`.
Run:   sudo WG_QUICK_USERSPACE_IMPLEMENTATION=wireguard-go python3 tests/e2e_tunnel.py
It runs Ultra Rook's real connect()/disconnect()/fetch_public_ip() code from inside the client namespace.
"""
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
NS = ("ur_cli", "ur_srv", "ur_net")


def sh(cmd, check=True, **kw):
    r = subprocess.run(cmd, shell=isinstance(cmd, str), capture_output=True, text=True, **kw)
    if check and r.returncode != 0:
        raise RuntimeError(f"{cmd}\n{r.stdout}\n{r.stderr}")
    return r


def ns(name, cmd, **kw):
    return sh(f"ip netns exec {name} {cmd}", **kw)


def client_part(client_conf_path, echo_url):
    """Runs INSIDE the client namespace."""
    home = tempfile.mkdtemp(prefix="ur_client_")
    for k in ("HOME", "APPDATA", "USERPROFILE"):
        os.environ[k] = home
    import queue
    import gr_core as c
    import gr_ultra as u
    d = Path(home)
    cfg = c.Config(d / "config.json")
    bus = c.EventBus(d / "e.log", queue.Queue())
    vault = c.Vault(d, cfg, bus)
    prof = u.Profiles(cfg, vault)
    text = Path(client_conf_path).read_text()
    entry = prof.add("e2e server", text)
    assert "PrivateKey" not in (prof.dir / f"{entry['id']}.enc").read_bytes().decode("latin-1"), "profile must be encrypted at rest"
    results = []

    def check(name, ok, detail=""):
        results.append(ok)
        print(("PASS " if ok else "FAIL ") + name + (f"   [{detail}]" if detail else ""))
    check("WireGuard tool found", bool(u.wireguard_tool()), str(u.wireguard_tool()))
    before = u.fetch_public_ip([echo_url])
    check("real address seen before connecting", before == "198.51.100.2", str(before))
    check("tunnel is down before connecting", not u.tunnel_up())
    if os.environ.get("UR_DEBUG"):
        dbg = d / "debug.conf"
        dbg.write_text(prof.load(entry["id"]))
        os.chmod(dbg, 0o600)
        r = subprocess.run(["wg-quick", "up", str(dbg)], capture_output=True, text=True)
        print("--- wg-quick debug output (rc=%s) ---\n%s%s" % (r.returncode, r.stdout, r.stderr))
        subprocess.run(["wg-quick", "down", str(dbg)], capture_output=True)
    try:
        msg = u.connect(prof.load(entry["id"]))
        check("connect() brings the tunnel up", u.tunnel_up(), msg)
    except u.UltraError as e:
        check("connect() brings the tunnel up", False, str(e))
        sys.exit(1)
    time.sleep(1.0)
    after = u.fetch_public_ip([echo_url])
    ok, sentence = u.verify_hidden(before, after)
    check("public address CHANGED while connected", ok and after == "203.0.113.1", sentence)
    check("plain config file exists only while connected", u.conf_file().exists())
    watch = u.UltraRookWatch(cfg, bus)
    cfg.set("ultra_want", True)
    watch.tick()
    check("drop-watcher is quiet while the tunnel is up", not watch.alerted)
    try:
        u.disconnect()
    except u.UltraError as e:
        print("disconnect error:", e)
    check("disconnect() takes the tunnel down", not u.tunnel_up())
    check("plain config file is deleted afterwards", not u.conf_file().exists())
    back = u.fetch_public_ip([echo_url])
    check("real address is back after disconnecting", back == "198.51.100.2", str(back))
    watch.tick()
    check("drop-watcher alerts when the tunnel is gone but wanted", watch.alerted)
    sys.exit(0 if all(results) else 1)


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "--client":
        return client_part(sys.argv[2], sys.argv[3])
    if os.name != "posix" or os.geteuid() != 0 or not all(shutil.which(x) for x in ("ip", "wg", "wg-quick", "nft")):
        print("SKIP: needs Linux, root, ip, wg, wg-quick and nft")
        return 0
    from gr_ultra import make_wireguard_pair
    tmp = Path(tempfile.mkdtemp(prefix="ur_e2e_"))
    code = 1
    try:
        for n in NS:
            sh(f"ip netns del {n}", check=False)
        for n in NS:
            sh(f"ip netns add {n}")
            ns(n, "ip link set lo up")
        sh("ip link add cli0 type veth peer name srv_isp")
        sh("ip link add srv_net type veth peer name net0")
        sh("ip link set cli0 netns ur_cli")
        sh("ip link set srv_isp netns ur_srv")
        sh("ip link set srv_net netns ur_srv")
        sh("ip link set net0 netns ur_net")
        for n, dev, addr in (("ur_cli", "cli0", "198.51.100.2/24"), ("ur_srv", "srv_isp", "198.51.100.1/24"),
                             ("ur_srv", "srv_net", "203.0.113.1/24"), ("ur_net", "net0", "203.0.113.2/24")):
            ns(n, f"ip addr add {addr} dev {dev}")
            ns(n, f"ip link set {dev} up")
        ns("ur_cli", "ip route add default via 198.51.100.1")
        ns("ur_net", "ip route add 198.51.100.0/24 via 203.0.113.1")
        ns("ur_srv", "sysctl -w net.ipv4.ip_forward=1")
        server, client, _ = make_wireguard_pair("198.51.100.1", dns="1.1.1.1")
        server = "\n".join(line for line in server.splitlines() if not line.startswith(("PostUp", "PostDown"))) + "\n"
        # this sandbox has no resolver tools and its kernel has no IPv6 policy routing, so test the IPv4 path only
        client = "\n".join(line for line in client.splitlines() if not line.startswith("DNS")).replace(", ::/0", "") + "\n"
        (tmp / "wg0.conf").write_text(server)
        (tmp / "client.conf").write_text(client)
        os.chmod(tmp / "wg0.conf", 0o600)
        ns("ur_srv", f"wg-quick up {tmp / 'wg0.conf'}")
        ns("ur_srv", "nft add table ip nat")
        ns("ur_srv", "nft 'add chain ip nat post { type nat hook postrouting priority 100 ; }'")
        ns("ur_srv", "nft add rule ip nat post ip saddr 10.66.66.0/24 oifname srv_net masquerade")
        echo = ("import http.server\n"
                "class H(http.server.BaseHTTPRequestHandler):\n"
                "    def do_GET(self):\n"
                "        b = self.client_address[0].encode(); self.send_response(200); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)\n"
                "    def log_message(self, *a): pass\n"
                "http.server.HTTPServer(('203.0.113.2', 8080), H).serve_forever()\n")
        srv = subprocess.Popen(["ip", "netns", "exec", "ur_net", sys.executable, "-c", echo])
        time.sleep(1.0)
        r = subprocess.run(["ip", "netns", "exec", "ur_cli", sys.executable, str(Path(__file__).resolve()), "--client",
                            str(tmp / "client.conf"), "http://203.0.113.2:8080"])
        code = r.returncode
        srv.terminate()
    finally:
        ns("ur_cli", "wg-quick down ultrarook", check=False)
        ns("ur_srv", f"wg-quick down {tmp / 'wg0.conf'}", check=False)
        for n in NS:
            sh(f"ip netns del {n}", check=False)
        shutil.rmtree(tmp, ignore_errors=True)
    print("\nE2E RESULT:", "ALL PASSED" if code == 0 else "FAILED")
    return code


if __name__ == "__main__":
    sys.exit(main())
