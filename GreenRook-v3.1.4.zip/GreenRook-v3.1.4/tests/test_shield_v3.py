"""Regression tests for the Green Rook 3.0 false-positive and Privacy Shield layers."""
import json
import os
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import gr_core as core
import gr_shield as shield
import gr_trust as trust


class PrivacyShieldTests(unittest.TestCase):
    def test_password_card_and_iban_helpers(self):
        self.assertTrue(shield.luhn("4111 1111 1111 1111"))
        self.assertFalse(shield.luhn("4111 1111 1111 1112"))
        self.assertIn("a possible card number", shield.secret_kinds("Card number: 4111111111111111"))
        self.assertIn("a written-down password", shield.secret_kinds("password: dont-use-this"))

    def test_hosts_file_cleanup_keeps_safe_ad_block_entries(self):
        original = "127.0.0.1 localhost\n0.0.0.0 ads.example\n203.0.113.8 microsoft.com\n"
        cleaned, removed = shield.clean_hosts_text(original)
        self.assertEqual(len(removed), 1)
        self.assertIn("localhost", cleaned)
        self.assertIn("ads.example", cleaned)
        self.assertNotIn("microsoft.com", cleaned)

    def test_browser_password_count_does_not_read_password_columns(self):
        with tempfile.TemporaryDirectory() as td:
            profile = Path(td)
            con = sqlite3.connect(profile / "Login Data")
            con.execute("CREATE TABLE logins (blacklisted_by_user INTEGER, password_value BLOB)")
            con.executemany("INSERT INTO logins VALUES (?, ?)", [(0, b"secret"), (0, b"other"), (1, b"")])
            con.commit(); con.close()
            self.assertEqual(shield._password_count("chromium", profile), 2)

    def test_browser_cookie_clear_checks_running_browser_and_skips_it(self):
        with tempfile.TemporaryDirectory() as td:
            prof = Path(td)
            con = sqlite3.connect(prof / "Cookies")
            con.execute("CREATE TABLE cookies (name TEXT)"); con.execute("INSERT INTO cookies VALUES ('session')")
            con.commit(); con.close()
            result = shield.clear_cookies([("Chrome", "chromium", prof)], {"chrome"})
            self.assertFalse(result[0])
            self.assertTrue((prof / "Cookies").exists())

    def test_password_lock_is_reversible_and_wrong_password_keeps_file(self):
        with tempfile.TemporaryDirectory() as td:
            source = Path(td) / "private.txt"; source.write_bytes(b"harmless test data")
            ok, locked = shield.lock_file(source, "strong test password")
            self.assertTrue(ok, locked)
            self.assertFalse(source.exists())
            with self.assertRaises(ValueError): shield.unseal(Path(locked).read_bytes(), "wrong password")
            ok, restored = shield.unlock_file(locked, "strong test password")
            self.assertTrue(ok, restored)
            self.assertEqual(Path(restored).read_bytes(), b"harmless test data")

    def test_sensitive_document_scan_stores_only_kind_not_secret_value(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "notes.txt"; p.write_text("password: private-test-value", encoding="utf-8")
            hits = shield.find_sensitive([td])
            self.assertEqual(len(hits), 1)
            self.assertIn("written-down password", hits[0][1])
            self.assertNotIn("private-test-value", repr(hits))

    def test_all_seven_topics_are_reported(self):
        rows = shield.run_checks(online=False)
        self.assertEqual([r["id"] for r in rows], shield.ORDER)
        self.assertEqual(len(rows), 7)


class FalsePositiveTests(unittest.TestCase):
    def test_signed_heuristic_is_not_reported_but_hard_evidence_still_is(self):
        with tempfile.TemporaryDirectory() as td, patch.dict(os.environ, {"HOME": td}):
            cfg = core.Config(Path(td) / "config.json")
            bus = core.EventBus(Path(td) / "events.log", __import__("queue").Queue())
            engine = core.Engine(cfg, bus)
            p = Path(td) / "invoice.pdf.exe"
            p.write_bytes(b"ordinary test file")
            with patch.object(trust, "verify", return_value=(trust.TRUSTED, "test signature")):
                ordinary = engine.scan_file(p, cloud=False)
                self.assertEqual(ordinary.verdict, core.CLEAN)
                self.assertIn("Genuine software", ordinary.reasons[0])
            p.write_bytes(("X5O!P%@AP[4\\PZX54(P^)7CC)7}$" + "EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*").encode())
            with patch.object(trust, "verify", return_value=(trust.TRUSTED, "test signature")):
                eicar = engine.scan_file(p, cloud=False)
                self.assertEqual(eicar.verdict, core.MALICIOUS)
                self.assertTrue(eicar.confirmed)

    def test_unconfirmed_signed_file_cannot_be_quarantined(self):
        with tempfile.TemporaryDirectory() as td:
            cfg = core.Config(Path(td) / "config.json")
            bus = core.EventBus(Path(td) / "events.log", __import__("queue").Queue())
            vault = core.Vault(Path(td), cfg, bus)
            p = Path(td) / "signed.exe"; p.write_bytes(b"harmless")
            result = core.ScanResult(str(p), core.SUSPICIOUS, 45, ["heuristic"], "", len(p.read_bytes()), False)
            with patch.object(trust, "is_trusted", return_value=True):
                with self.assertRaises(PermissionError): vault.quarantine(result)
            self.assertTrue(p.exists())


if __name__ == "__main__":
    unittest.main()
