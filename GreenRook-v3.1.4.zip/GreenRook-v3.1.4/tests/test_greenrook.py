"""Regression tests.  Run:  python -m unittest discover -s tests -v"""
import hashlib
import io
import json
import os
import queue
import subprocess
import sys
import tempfile
import time
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
HOME = tempfile.mkdtemp(prefix="gr_test_")
for _k in ("HOME", "APPDATA", "USERPROFILE"):
    os.environ[_k] = HOME

import gr_core as c  # noqa: E402
import gr_guards as g  # noqa: E402
import gr_intel  # noqa: E402
import gr_office as o  # noqa: E402
import gr_testkit as tk  # noqa: E402
from gr_core import PackError  # noqa: E402

EICAR = "X5O!P%@AP[4\\PZX54(P^)7CC)7}$" + "EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*"


def fresh():
    d = Path(tempfile.mkdtemp(dir=HOME))
    cfg = c.Config(d / "config.json")
    bus = c.EventBus(d / "e.log", queue.Queue())
    eng = c.Engine(cfg, bus)
    return d, cfg, bus, eng, c.Vault(d, cfg, bus)


class Engine(unittest.TestCase):
    def setUp(self):
        self.d, self.cfg, self.bus, self.eng, self.vault = fresh()

    def scan(self, name, data):
        p = self.d / name
        p.write_bytes(data.encode("latin-1") if isinstance(data, str) else data)
        return self.eng.scan_file(p, cloud=False)

    def test_eicar_confirmed(self):
        r = self.scan("e.com", EICAR)
        self.assertEqual(r.verdict, c.MALICIOUS)
        self.assertTrue(r.confirmed and r.auto_safe)

    def test_empty_and_clean(self):
        self.assertEqual(self.scan("a.txt", "").verdict, c.CLEAN)
        self.assertEqual(self.scan("b.txt", "just notes").verdict, c.CLEAN)

    def test_allow_list_cache_sees_new_entries(self):
        r = self.scan("e.com", EICAR)
        self.cfg.append_unique("allow_hashes", r.sha256)
        self.assertEqual(self.eng.scan_file(self.d / "e.com", cloud=False).verdict, c.CLEAN)

    def test_heuristics_alone_never_auto_remove(self):
        worm = ('CreateObject("Outlook.' + 'Application")\nAddress' + 'Lists\nAddress' + 'Entries\nWScript.Shell\nReg' + 'Write\nScripting.File' + 'SystemObject\n')
        r = self.scan("w.vbs", worm)
        self.assertIn(r.verdict, (c.MALICIOUS, c.SUSPICIOUS))
        self.assertFalse(r.auto_safe)
        self.assertIn("heuristics", r.confidence)

    def test_os_folder_never_auto(self):
        path = "C:\\Windows\\System32\\x.dll" if c.IS_WIN else "/usr/bin/x"
        self.assertFalse(c.ScanResult(path, c.MALICIOUS, 100, ["k"], "ab", 1, True).auto_safe)

    def test_macro_findings(self):
        risky = {"ThisDocument": 'Sub Document_Open()\r\n CreateObject("WScript.Shell").Run "cmd /c x"\r\nEnd Sub\r\n'}
        calm = {"Module1": 'Sub A()\r\n Range("A1").Value = 3\r\nEnd Sub\r\n'}
        self.assertIn(self.scan("r.doc", tk.build_cfb(tk.make_vba_streams(risky))).verdict, (c.MALICIOUS, c.SUSPICIOUS))
        self.assertEqual(self.scan("c.xls", tk.build_cfb(tk.make_vba_streams(calm))).verdict, c.CLEAN)

    def test_corrupt_inputs_do_not_crash(self):
        blob = tk.build_cfb(tk.make_vba_streams({"M": "Sub A()\r\nEnd Sub\r\n"}))
        for i, junk in enumerate([blob[:700], blob[:512] + b"\xff" * 4000, o.OLE_MAGIC + b"\0" * 600, b"PK\x03\x04" + os.urandom(300), blob[:-1000]]):
            self.assertIn(self.scan(f"j{i}.doc", junk).verdict, (c.CLEAN, c.SUSPICIOUS, c.MALICIOUS))

    def test_ovba_matches_reference_roundtrip(self):
        for n in (0, 1, 100, 4096, 9000):
            data = (b"Sub X()\r\n  Shell(\"a\")\r\nEnd Sub\r\n" * (n // 20 + 1))[:n]
            self.assertEqual(o.ovba_decompress(tk.ovba_compress(data)), data)

    def test_zip_member_hash_hit_is_confirmed(self):
        self.eng.hashdb[hashlib.sha256(b"inner-bad").hexdigest()] = "test"
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            z.writestr("x.bin", b"inner-bad")
        r = self.scan("a.zip", buf.getvalue())
        self.assertEqual(r.verdict, c.MALICIOUS)
        self.assertTrue(r.confirmed)

    def test_symlinks_not_followed_by_iter_files(self):
        if c.IS_WIN:
            self.skipTest("symlinks need privileges on Windows")
        (self.d / "real.com").write_text(EICAR)
        sub = self.d / "scan"
        sub.mkdir()
        os.symlink(self.d / "real.com", sub / "link.com")
        import threading
        self.assertEqual(list(c.iter_files(self.eng, [str(sub)], False, threading.Event())), [])


class Vault(unittest.TestCase):
    def setUp(self):
        self.d, self.cfg, self.bus, self.eng, self.vault = fresh()

    def make(self, data=b"payload" * 300):
        p = self.d / "v.bin"
        p.write_bytes(data)
        return p, c.ScanResult(str(p), c.MALICIOUS, 90, ["t"], hashlib.sha256(data).hexdigest(), len(data))

    def test_roundtrip_never_overwrites(self):
        p, r = self.make()
        qid = self.vault.quarantine(r)
        self.assertFalse(p.exists())
        p.write_bytes(b"new")
        dest = Path(self.vault.restore(qid))
        self.assertNotEqual(dest, p)
        self.assertEqual(p.read_bytes(), b"new")
        self.assertEqual(dest.read_bytes(), b"payload" * 300)

    def test_restore_twice_gets_distinct_names(self):
        ids = []
        for _ in range(2):                      # the same original path is quarantined twice
            p, r = self.make()
            ids.append(self.vault.quarantine(r))
        dests = [Path(self.vault.restore(i)) for i in ids]
        self.assertEqual(len(set(dests)), 2)
        self.assertEqual(len(list(self.d.glob("v.bin*"))), 2)

    def test_damaged_blob_is_refused(self):
        p, r = self.make()
        qid = self.vault.quarantine(r)
        blob = self.d / "quarantine" / f"{qid}.sgq"
        raw = bytearray(blob.read_bytes())
        raw[-1] ^= 1
        blob.write_bytes(bytes(raw))
        with self.assertRaises(Exception):
            self.vault.restore(qid)

    def test_corrupt_index_recovers(self):
        p, r = self.make()
        self.vault.quarantine(r)
        (self.d / "quarantine" / "index.json").write_text("{not json")
        v2 = c.Vault(self.d, self.cfg, self.bus)
        self.assertEqual(v2.index, {})
        self.assertTrue((self.d / "quarantine" / "index.corrupt.json").exists())

    def test_atomic_write_leaves_no_temp(self):
        c.atomic_write(self.d / "x.txt", "hi")
        self.assertEqual((self.d / "x.txt").read_text(), "hi")
        self.assertFalse((self.d / "x.txt.tmp").exists())


class WindowsBlocking(unittest.TestCase):
    """Simulates the ways Windows / antivirus can refuse a file operation (the sandbox runs as root, so we inject the errors)."""

    def setUp(self):
        self.d, self.cfg, self.bus, self.eng, self.vault = fresh()
        self.f = self.d / "locked.bin"
        self.f.write_bytes(b"payload" * 100)

    def res(self):
        return c.ScanResult(str(self.f), c.MALICIOUS, 90, ["t"], hashlib.sha256(self.f.read_bytes()).hexdigest(), 700)

    def test_remove_retries_until_lock_clears(self):
        from unittest import mock
        real, calls = os.remove, []

        def flaky(path):
            calls.append(1)
            if len(calls) < 3:
                raise PermissionError(13, "in use")
            return real(path)
        with mock.patch("gr_core.os.remove", flaky), mock.patch("time.sleep"):
            ok, pending, msg = c.force_remove(str(self.f))
        self.assertTrue(ok)
        self.assertFalse(self.f.exists())
        self.assertEqual(len(calls), 3)

    def test_permanent_refusal_gives_actionable_advice(self):
        from unittest import mock
        with mock.patch("gr_core.os.remove", side_effect=PermissionError(13, "denied")), mock.patch("time.sleep"):
            ok, pending, msg = c.force_remove(str(self.f))
        self.assertFalse(ok)
        self.assertTrue("administrator" in msg or "sudo" in msg, msg)
        self.assertTrue(self.f.exists())

    def test_in_use_message_names_the_problem(self):
        self.assertIn("in use", c.explain_block(str(self.f), OSError(32, "sharing violation")))

    def test_quarantine_rolls_back_cleanly_when_original_cannot_be_removed(self):
        from unittest import mock
        with mock.patch("gr_core.force_remove", return_value=(False, False, "blocked for test")):
            with self.assertRaises(OSError) as cm:
                self.vault.quarantine(self.res())
        self.assertIn("blocked for test", str(cm.exception))
        self.assertTrue(self.f.exists(), "the original must be untouched")
        self.assertEqual(list((self.vault.dir).glob("*.sgq")), [])
        self.assertEqual(self.vault.index, {})

    def test_quarantine_records_restart_pending_removal(self):
        from unittest import mock
        with mock.patch("gr_core.force_remove", return_value=(True, True, "restart")):
            qid = self.vault.quarantine(self.res())
        self.assertIn("restart", self.vault.index[qid]["note"])
        self.assertTrue((self.vault.dir / f"{qid}.sgq").exists())

    def test_quarantine_survives_a_file_that_is_briefly_unreadable(self):
        from unittest import mock
        real, n = Path.read_bytes, []

        def flaky(self_):
            if str(self_) == str(self.f) and len(n) < 2:
                n.append(1)
                raise PermissionError(13, "scanner has it open")
            return real(self_)
        r = self.res()
        with mock.patch.object(Path, "read_bytes", flaky), mock.patch("time.sleep"):
            qid = self.vault.quarantine(r)
        self.assertIn(qid, self.vault.index)
        self.assertFalse(self.f.exists())

    def test_atomic_write_survives_target_locked_for_a_moment(self):
        from unittest import mock
        real, n = os.replace, []

        def flaky(a, b):
            if len(n) < 3:
                n.append(1)
                raise PermissionError(13, "locked")
            return real(a, b)
        with mock.patch("gr_core.os.replace", flaky), mock.patch("time.sleep"):
            c.atomic_write(self.d / "idx.json", "{}")
        self.assertEqual((self.d / "idx.json").read_text(), "{}")

    def test_unreadable_file_is_reported_not_lost(self):
        from unittest import mock
        r = self.res()
        with mock.patch.object(Path, "read_bytes", side_effect=PermissionError(13, "denied")), mock.patch("time.sleep"):
            with self.assertRaises(OSError):
                self.vault.quarantine(r)
        self.assertTrue(self.f.exists())


class Installer(unittest.TestCase):
    def setUp(self):
        import gr_setup
        self.s = gr_setup
        self.t = Path(tempfile.mkdtemp(dir=HOME)) / "app"

    def test_copy_installs_program_but_not_tests_or_caches(self):
        names = self.s.copy_program(self.t)
        for need in ("greenrook.py", "gr_core.py", "gr_ui.py", "gr_setup.py", "gr_launch.py", "MANIFEST.sha256", "requirements.txt", "greenrook.png"):
            self.assertTrue((self.t / need).exists(), need)
        self.assertFalse((self.t / "tests").exists())
        self.assertTrue((self.t / "samples" / "demo_feed.grpack").exists())
        self.assertGreater(len(names), 10)

    def test_installed_copy_passes_its_own_integrity_check(self):
        self.s.copy_program(self.t)
        for line in (self.t / "MANIFEST.sha256").read_text().split("\n"):
            if line.strip():
                h, n = line.split()
                self.assertEqual(hashlib.sha256((self.t / n).read_bytes()).hexdigest(), h, n)

    def test_reinstall_over_itself_is_safe(self):
        self.s.copy_program(self.t)
        self.assertTrue(self.s.copy_program(self.t))

    def test_windows_install_no_longer_waits_for_console_choice(self):
        from unittest import mock
        with mock.patch.object(self.s, "IS_WIN", True), mock.patch.object(self.s, "install") as install, \
             mock.patch("builtins.input", side_effect=AssertionError("installer must not wait for input")):
            self.assertEqual(self.s.main(["--no-launch"]), 0)
        self.assertEqual(install.call_args.args[1:], (True, False))

    def test_window_failure_returns_distinct_exit_code(self):
        from unittest import mock
        with mock.patch.object(self.s, "install", return_value=False):
            self.assertEqual(self.s.main(["--yes"]), 2)
        with mock.patch.object(self.s, "install", return_value=True):
            self.assertEqual(self.s.main(["--yes"]), 0)

    def test_install_bat_pauses_on_failure_and_detects_zip_launch(self):
        bat = (ROOT / "Install.bat").read_text()
        self.assertIn("Extract All", bat)
        self.assertIn('"%GR_RESULT%"=="2"', bat)
        self.assertNotIn("Start Green Rook automatically", (ROOT / "gr_setup.py").read_text())

    def test_failed_addons_do_not_stop_the_install(self):
        from unittest import mock
        fail = mock.Mock(returncode=1, stdout="", stderr="ERROR: No matching distribution found")
        with mock.patch.object(self.s.subprocess, "run", return_value=fail):
            self.assertEqual(self.s.install_addons(Path("python")), ["psutil", "cryptography"])

    def test_admin_shortcut_flag_only_touches_one_bit(self):
        lnk = self.t.parent / "x.lnk"
        raw = bytearray(0x4C + 20)
        raw[:4] = b"\x4c\x00\x00\x00"
        raw[0x14] = 0x81
        lnk.write_bytes(bytes(raw))
        self.s.lnk_run_as_admin(lnk)
        out = lnk.read_bytes()
        self.assertEqual(out[0x15], 0x20)
        self.assertEqual(out[0x14], 0x81)
        self.assertEqual(out[:0x14] + out[0x16:], bytes(raw[:0x14] + raw[0x16:]))
        (self.t.parent / "bad.lnk").write_bytes(b"not a shortcut at all" * 10)
        with self.assertRaises(ValueError):
            self.s.lnk_run_as_admin(self.t.parent / "bad.lnk")

    def test_installed_dir_detection_protects_downloads(self):
        self.t.mkdir(parents=True)
        (self.t / "greenrook.py").write_text("x")
        self.assertFalse(self.s.is_installed_dir(self.t))          # no private environment -> not an install
        (self.t / "venv").mkdir()
        self.assertTrue(self.s.is_installed_dir(self.t))

    def test_uninstall_leaves_a_non_installed_folder_alone(self):
        self.t.mkdir(parents=True)
        (self.t / "greenrook.py").write_text("x")
        from unittest import mock
        with mock.patch.object(self.s, "stop_running"):
            self.assertTrue(self.s.uninstall(self.t, assume_yes=True))
        self.assertTrue((self.t / "greenrook.py").exists())

    @unittest.skipIf(c.IS_WIN, "linux menu entry")
    def test_linux_menu_entry_and_clean_uninstall(self):
        from unittest import mock
        menu = Path(tempfile.mkdtemp(dir=HOME))
        self.t.mkdir(parents=True)
        (self.t / "greenrook.py").write_text("x")
        (self.t / "venv").mkdir()
        entry = menu / "greenrook.desktop"
        entry.write_text(self.s.desktop_entry(self.t))
        self.assertIn("Exec=", entry.read_text())
        with mock.patch.object(self.s, "stop_running"), mock.patch.object(self.s, "linux_menu_dir", return_value=menu):
            self.s.uninstall(self.t, assume_yes=True)
        self.assertFalse(self.t.exists())
        self.assertFalse(entry.exists())


class SafeDelete(unittest.TestCase):
    def test_deletes_readonly_file_and_is_idempotent(self):
        d = Path(tempfile.mkdtemp(dir=HOME))
        f = d / "x.txt"
        f.write_text("x")
        os.chmod(f, 0o444)
        self.assertEqual(c.safe_delete(str(f))[0], True)
        self.assertFalse(f.exists())
        self.assertTrue(c.safe_delete(str(f))[0])

    def test_refuses_folders_and_own_files(self):
        d = Path(tempfile.mkdtemp(dir=HOME))
        self.assertFalse(c.safe_delete(str(d))[0])
        self.assertTrue(d.exists())
        self.assertFalse(c.safe_delete(str(c.APP_DIR / "gr_core.py"))[0])
        self.assertFalse(c.safe_delete(str(c.data_dir() / "config.json"))[0])

    def test_link_removed_target_kept(self):
        if c.IS_WIN:
            self.skipTest("symlinks need privileges on Windows")
        d = Path(tempfile.mkdtemp(dir=HOME))
        (d / "t.txt").write_text("keep")
        os.symlink(d / "t.txt", d / "ln")
        self.assertTrue(c.safe_delete(str(d / "ln"))[0])
        self.assertTrue((d / "t.txt").exists())


class Config(unittest.TestCase):
    def test_tamper_detected_and_reset(self):
        d = Path(tempfile.mkdtemp(dir=HOME))
        cfg = c.Config(d / "c.json")
        cfg.set("pin", "abc")
        raw = json.loads((d / "c.json").read_text())
        raw["data"]["tamper_protection"] = False
        (d / "c.json").write_text(json.dumps(raw))
        again = c.Config(d / "c.json")
        self.assertTrue(again.tampered)
        self.assertTrue(again.get("tamper_protection"))


class Rules(unittest.TestCase):
    def ids(self, name, parent, cmd):
        return [h[0] for h in g.match_rules(name, parent, cmd.lower())]

    def test_positive(self):
        self.assertIn("R01", self.ids("cmd.exe", "winword.exe", "cmd /c dir"))
        self.assertIn("R02", self.ids("powershell.exe", "", "powershell -enc " + "QUJD" * 10))
        self.assertIn("R12", self.ids("wscript.exe", "", r"wscript c:\users\a\appdata\local\temp\x.vbs"))
        self.assertIn("R12", self.ids("wscript.exe", "", r"wscript c:\users\a\appdata\local\microsoft\windows\inetcache\content.outlook\ab\x.vbs"))

    def test_no_false_alarms(self):
        for n, p, cmd in [("notepad.exe", "", "notepad a.txt"), ("powershell.exe", "", "powershell get-date"),
                          ("wscript.exe", "", r"wscript c:\program files\app\run.vbs"), ("cmd.exe", "explorer.exe", "cmd /c dir")]:
            self.assertEqual(self.ids(n, p, cmd), [], cmd)

    def test_rule_registry(self):
        self.assertTrue({"R12", "R13"} <= set(g.RULE_DEFAULT))


class ProcessSafety(unittest.TestCase):
    @unittest.skipUnless(c.psutil and not c.IS_WIN, "needs psutil + POSIX")
    def test_resume_only_what_we_suspended(self):
        d, cfg, bus, eng, vault = fresh()
        guard = g.ProcessGuard(cfg, eng, vault, c.Broker(queue.Queue(), cfg), bus, False)
        a = subprocess.Popen(["sleep", "30"])
        b = subprocess.Popen(["sleep", "30"])
        try:
            pa, pb = c.psutil.Process(a.pid), c.psutil.Process(b.pid)
            pa.suspend()                    # stopped by "someone else"
            time.sleep(0.3)                 # let the OS apply SIGSTOP before we look
            guard._suspend(pa)
            guard._resume(pa)
            time.sleep(0.2)
            self.assertEqual(pa.status(), c.psutil.STATUS_STOPPED, "must not resume a process we did not suspend")
            guard._suspend(pb)
            time.sleep(0.3)
            self.assertEqual(pb.status(), c.psutil.STATUS_STOPPED)
            guard._resume(pb)
            time.sleep(0.2)
            self.assertNotEqual(pb.status(), c.psutil.STATUS_STOPPED)
        finally:
            for x in (a, b):
                x.kill()
                x.wait()

    def test_critical_never_killed(self):
        class F:
            pid = 700

            def name(self):
                return "lsass.exe"
        self.assertFalse(g.kill_tree(F()))


class Network(unittest.TestCase):
    def test_fanout(self):
        f = g.FanoutTracker()
        self.assertTrue(any(f.add(1, f"10.0.0.{i}", 445, now=i * 0.2) for i in range(30)))
        f = g.FanoutTracker()
        self.assertFalse(any(f.add(1, f"1.2.3.{i}", 443, now=i * 0.2) for i in range(30)))
        f = g.FanoutTracker()
        self.assertFalse(any(f.add(1, f"10.0.0.{i}", 445, now=i * 10) for i in range(30)))


class Ransomware(unittest.TestCase):
    def shield(self):
        d, cfg, bus, eng, vault = fresh()
        return d, g.RansomwareShield(cfg, eng, vault, c.Broker(queue.Queue(), cfg), bus, False)

    def run_case(self, content, names=None):
        d, sh = self.shield()
        for i in range(10):
            (d / f"d{i}.txt").write_text("report text " * 500)
        snap = lambda: dict(c.walk_limited(str(d), 2))  # noqa: E731
        sh.judge(snap())
        for i in range(10):
            (d / f"d{i}.txt").write_bytes(content())
        return sh.judge(snap())

    def test_encryption_triggers(self):
        self.assertIsNotNone(self.run_case(lambda: os.urandom(6000)))

    def test_edit_is_quiet(self):
        self.assertIsNone(self.run_case(lambda: b"edited " * 900))

    def test_ransom_extensions_trigger(self):
        d, sh = self.shield()
        sh.judge({})
        cur = {str(d / f"a{i}.docx.locked"): (1, 1) for i in range(4)}
        self.assertIsNotNone(sh.judge(cur))


class Intel(unittest.TestCase):
    def setUp(self):
        if not gr_intel.HAVE_ED25519:
            self.skipTest("cryptography missing")
        self.d, self.cfg, self.bus, self.eng, self.vault = fresh()
        for stale in self.eng.intel.dir.glob("*.grpack"):      # the data folder is shared between tests
            stale.unlink()
        self.eng.intel._cache = (None, None)
        self.priv, self.pub = gr_intel.generate_keypair()

    def pack(self, serial=1, priv=None, **kw):
        p = self.d / f"p{serial}.grpack"
        p.write_text(gr_intel.sign_pack({"name": "t", "serial": serial, **kw}, priv or self.priv))
        return p

    def test_untrusted_then_trusted(self):
        with self.assertRaises(PackError):
            self.eng.install_pack(self.pack())
        self.eng.intel.add_key(self.pub)
        self.assertEqual(self.eng.install_pack(self.pack())["serial"], 1)

    def test_wrong_signer_rejected(self):
        self.eng.intel.add_key(self.pub)
        other, _ = gr_intel.generate_keypair()
        with self.assertRaises(PackError):
            self.eng.install_pack(self.pack(priv=other))

    def test_rollback_and_upgrade(self):
        self.eng.intel.add_key(self.pub)
        self.eng.install_pack(self.pack(2))
        with self.assertRaises(PackError):
            self.eng.install_pack(self.pack(1))
        self.eng.install_pack(self.pack(3))

    def test_tampered_file_and_installed_tamper(self):
        self.eng.intel.add_key(self.pub)
        sha = hashlib.sha256(b"zzz").hexdigest()
        f = self.pack(hashes=[{"sha256": sha, "name": "z"}])
        self.eng.install_pack(f)
        self.assertIn(sha, self.eng.hashdb)
        inst = next(self.eng.intel.dir.glob("*.grpack"))
        doc = json.loads(inst.read_text())
        doc["payload"] = doc["payload"][:-6] + "AAAAAA"
        inst.write_text(json.dumps(doc))
        self.eng.reload_hashes()
        self.assertNotIn(sha, self.eng.hashdb)

    def test_expired_and_bad_schema(self):
        self.eng.intel.add_key(self.pub)
        with self.assertRaises(PackError):
            self.eng.install_pack(self.pack(expires="2000-01-01"))
        with self.assertRaises(PackError):
            gr_intel.sign_pack({"name": "t", "serial": 1, "rules": [{"name": "x", "any": ["ab"]}]}, self.priv)
        with self.assertRaises(PackError):
            gr_intel.sign_pack({"name": "t", "serial": 1, "hashes": ["nothex"]}, self.priv)

    def test_pack_rules_and_domains_apply(self):
        self.eng.intel.add_key(self.pub)
        self.eng.install_pack(self.pack(domains=["evil-pack.example"], rules=[{"name": "marker", "weight": 50, "any": ["GR-PACK-MARKER-XYZ"]}]))
        web = c.WebGuard(self.eng.intel)
        self.assertIn("evil-pack.example", web.blocklist)
        p = self.d / "m.txt"
        p.write_text("... GR-PACK-MARKER-XYZ ...")
        r = self.eng.scan_file(p, cloud=False)
        self.assertTrue(any("Signed rule" in x for x in r.reasons))


class WebAndHosts(unittest.TestCase):
    def test_hosts_backup_and_removal(self):
        d, cfg, bus, eng, vault = fresh()
        hosts = d / "hosts"
        hosts.write_text("127.0.0.1 localhost\n")
        web = c.WebGuard()
        web.hosts_path = staticmethod(lambda: hosts)
        web.blocklist = {"bad.example", "worse.example"}
        self.assertEqual(web.apply_hosts(True), 2)
        self.assertIn("0.0.0.0 bad.example", hosts.read_text())
        self.assertTrue((c.data_dir() / "hosts.backup").exists())
        web.apply_hosts(False)
        self.assertEqual(hosts.read_text().strip(), "127.0.0.1 localhost")

    def test_url_checks(self):
        web = c.WebGuard()
        self.assertEqual(web.analyze("https://www.google.com/")[2], "Looks safe")
        self.assertNotEqual(web.analyze("http://paypa1-secure-login.verify-account.xyz/signin")[2], "Looks safe")


class Cli(unittest.TestCase):
    def run_cli(self, *args):
        env = dict(os.environ, HOME=HOME, APPDATA=HOME, USERPROFILE=HOME)
        return subprocess.run([sys.executable, str(ROOT / "greenrook_cli.py"), *args], capture_output=True, text=True, env=env, timeout=120)

    def test_scan_exit_codes_and_quarantine(self):
        d = Path(tempfile.mkdtemp(dir=HOME))
        (d / "ok.txt").write_text("fine")
        self.assertEqual(self.run_cli("scan", str(d), "--all", "--no-cloud").returncode, 0)
        (d / "e.com").write_text(EICAR)
        self.assertEqual(self.run_cli("scan", str(d), "--no-cloud").returncode, 1)
        self.assertEqual(self.run_cli("scan", str(d), "--no-cloud", "--quarantine").returncode, 1)
        self.assertFalse((d / "e.com").exists())

    def test_selftest_via_cli(self):
        r = self.run_cli("selftest")
        self.assertEqual(r.returncode, 0, r.stdout[-500:])


class Manifest(unittest.TestCase):
    def test_manifest_matches_program_files(self):
        self.assertEqual(g.verify_manifest(), [], "run: python tools/make_manifest.py")


if __name__ == "__main__":
    unittest.main()


# ---------------------------------------------------------------------------------------------- Ultra Rook
import gr_ultra as u  # noqa: E402

K1, K2, K3 = "A" * 43 + "=", "B" * 43 + "=", "C" * 43 + "="


def wgconf(extra_if="", extra_peer="", allowed="0.0.0.0/0, ::/0", dns="DNS = 1.1.1.1", endpoint="vpn.example.com:51820", addr="10.0.0.2/32"):
    return (f"[Interface]\nPrivateKey = {K1}\nAddress = {addr}\n{dns}\n{extra_if}\n[Peer]\nPublicKey = {K2}\nEndpoint = {endpoint}\n"
            f"AllowedIPs = {allowed}\n{extra_peer}\n")


class UltraConfig(unittest.TestCase):
    def test_good_file_is_full_tunnel_with_private_dns(self):
        p = u.parse_wg_conf(wgconf())
        self.assertTrue(p["full_tunnel"] and p["has_dns"])
        self.assertEqual(p["warnings"], [])
        self.assertEqual(p["endpoint"], "vpn.example.com:51820")

    def test_command_hooks_are_refused(self):
        for hook in ("Post" + "Up = touch /tmp/pwned", "Pre" + "Up = id", "Pre" + "Down = id", "Post" + "Down = id", "Save" + "Config = true"):
            with self.assertRaises(u.UltraError) as cm:
                u.parse_wg_conf(wgconf(extra_if=hook))
            self.assertIn("command hook", str(cm.exception))
        with self.assertRaises(u.UltraError):
            u.parse_wg_conf(wgconf(extra_peer="Pre" + "Up = id"))

    def test_hook_hidden_by_case_or_spacing_is_still_refused(self):
        for hook in ("pOsTuP=touch /x", "   POSTUP   =   id", "Post" + "Up\t=\tid"):
            with self.assertRaises(u.UltraError):
                u.parse_wg_conf(wgconf(extra_if=hook))

    def test_unknown_settings_and_sections_refused(self):
        with self.assertRaises(u.UltraError):
            u.parse_wg_conf(wgconf(extra_if="Table = off"))
        with self.assertRaises(u.UltraError):
            u.parse_wg_conf(wgconf() + "\n[Script]\nx = y\n")

    def test_bad_keys_endpoint_and_missing_parts(self):
        with self.assertRaises(u.UltraError):
            u.parse_wg_conf(wgconf().replace(K1, "tooshort"))
        for bad in ("vpn.example.com", "vpn.example.com:99999", "bad host:51820", ":51820"):
            with self.assertRaises(u.UltraError, msg=bad):
                u.parse_wg_conf(wgconf(endpoint=bad))
        with self.assertRaises(u.UltraError):
            u.parse_wg_conf("[Interface]\nPrivateKey = " + K1 + "\n")
        with self.assertRaises(u.UltraError):
            u.parse_wg_conf("x" * 30000)

    def test_ipv6_and_ip_endpoints_accepted(self):
        self.assertTrue(u.parse_wg_conf(wgconf(endpoint="[2001:db8::1]:51820"))["endpoint"])
        self.assertTrue(u.parse_wg_conf(wgconf(endpoint="203.0.113.5:443"))["endpoint"])

    def test_warnings_for_weak_setups(self):
        no_dns = u.parse_wg_conf(wgconf(dns=""))
        self.assertTrue(any("DNS" in w for w in no_dns["warnings"]))
        partial = u.parse_wg_conf(wgconf(allowed="10.0.0.0/24"))
        self.assertFalse(partial["full_tunnel"])
        self.assertTrue(any("NOT hidden" in w for w in partial["warnings"]))
        v6 = u.parse_wg_conf(wgconf(allowed="0.0.0.0/0", addr="10.0.0.2/32, fd00::2/128"))
        self.assertTrue(any("IPv6" in w for w in v6["warnings"]))

    def test_render_only_contains_validated_fields(self):
        text = u.render_conf(u.parse_wg_conf(wgconf() + "# a comment with Post" + "Up inside\n"))
        self.assertNotIn("comment", text)
        self.assertEqual(u.parse_wg_conf(text)["endpoint"], "vpn.example.com:51820")


class UltraStorage(unittest.TestCase):
    def setUp(self):
        self.d, self.cfg, self.bus, self.eng, self.vault = fresh()
        self.prof = u.Profiles(self.cfg, self.vault, self.d)

    def test_encrypted_at_rest_and_roundtrip(self):
        e = self.prof.add("Home <server>!", wgconf())
        raw = (self.prof.dir / f"{e['id']}.enc").read_bytes()
        self.assertNotIn(K1.encode(), raw)
        self.assertIn(K1, self.prof.load(e["id"]))
        self.assertEqual(e["name"], "Home server")
        self.assertEqual(self.cfg.get("ultra_active"), e["id"])
        self.assertNotIn(K1, json.dumps(self.cfg.data))        # keys never appear in settings

    def test_remove_deletes_file_and_moves_active(self):
        a, b = self.prof.add("a", wgconf()), self.prof.add("b", wgconf())
        self.prof.remove(a["id"])
        self.assertFalse((self.prof.dir / f"{a['id']}.enc").exists())
        self.assertEqual(self.cfg.get("ultra_active"), b["id"])
        self.prof.remove(b["id"])
        self.assertEqual(self.cfg.get("ultra_active"), "")

    def test_invalid_file_is_not_stored(self):
        with self.assertRaises(u.UltraError):
            self.prof.add("evil", wgconf(extra_if="Post" + "Up = id"))
        self.assertEqual(self.prof.list(), [])
        self.assertEqual(list(self.prof.dir.glob("*.enc")), [])

    def test_damaged_profile_gives_clear_error(self):
        e = self.prof.add("x", wgconf())
        (self.prof.dir / f"{e['id']}.enc").write_bytes(b"garbage")
        with self.assertRaises(u.UltraError):
            self.prof.load(e["id"])


class UltraGenerator(unittest.TestCase):
    def test_pair_is_consistent_and_accepted_by_our_own_parser(self):
        server, client, steps = u.make_wireguard_pair("203.0.113.9")
        p = u.parse_wg_conf(client)
        self.assertTrue(p["full_tunnel"] and p["has_dns"] and p["warnings"] == [])
        self.assertIn("203.0.113.9:51820", client)
        self.assertIn("wg0.conf", steps)
        with self.assertRaises(u.UltraError):                   # the SERVER file has hooks: the app must refuse to import it as a client
            u.parse_wg_conf(server)

    def test_keys_are_unique_each_time(self):
        a, b = u.make_wireguard_pair("203.0.113.9"), u.make_wireguard_pair("203.0.113.9")
        self.assertNotEqual(a[1], b[1])

    @unittest.skipUnless(__import__("shutil").which("wg"), "needs the wg tool")
    def test_keys_match_the_real_wg_tool(self):
        server, client, _ = u.make_wireguard_pair("203.0.113.9")
        import re as _re
        get = lambda t, k: _re.search(rf"^{k} = (.+)$", t, _re.M).group(1)  # noqa: E731
        wgpub = lambda k: subprocess.run(["wg", "pubkey"], input=k + "\n", capture_output=True, text=True).stdout.strip()  # noqa: E731
        self.assertEqual(wgpub(get(client, "PrivateKey")), get(server, "PublicKey"))
        self.assertEqual(wgpub(get(server, "PrivateKey")), get(client, "PublicKey"))

    def test_bad_host_refused(self):
        with self.assertRaises(u.UltraError):
            u.make_wireguard_pair("bad host name")


class UltraNetwork(unittest.TestCase):
    def serve(self, body):
        import http.server
        import threading

        class H(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                b = body.encode()
                self.send_response(200)
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)

            def log_message(self, *a):
                pass
        srv = http.server.HTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        self.addCleanup(lambda: (srv.shutdown(), srv.server_close()))
        return f"http://127.0.0.1:{srv.server_port}"

    def test_fetch_ip_accepts_only_real_addresses(self):
        self.assertEqual(u.fetch_public_ip([self.serve("203.0.113.7\n")]), "203.0.113.7")
        self.assertIsNone(u.fetch_public_ip([self.serve("<html>blocked</html>")]))
        self.assertIsNone(u.fetch_public_ip(["http://127.0.0.1:9"], timeout=1))

    def test_fetch_ip_falls_back_to_next_service(self):
        self.assertEqual(u.fetch_public_ip(["http://127.0.0.1:9", self.serve("198.51.100.4")], timeout=1), "198.51.100.4")

    def test_verify_hidden_cases(self):
        self.assertTrue(u.verify_hidden("1.1.1.1", "2.2.2.2")[0])
        ok, msg = u.verify_hidden("1.1.1.1", "1.1.1.1")
        self.assertFalse(ok)
        self.assertIn("did not change", msg)
        self.assertFalse(u.verify_hidden("1.1.1.1", None)[0])
        self.assertTrue(u.verify_hidden(None, "2.2.2.2")[0])


class UltraControl(unittest.TestCase):
    def setUp(self):
        self.d, self.cfg, self.bus, self.eng, self.vault = fresh()
        self.q = self.bus.q if hasattr(self.bus, "q") else None

    def test_connect_refuses_without_wireguard(self):
        from unittest import mock
        with mock.patch.object(u, "wireguard_tool", return_value=None):
            with self.assertRaises(u.UltraError) as cm:
                u.connect(wgconf())
        self.assertIn("not installed", str(cm.exception))

    def test_connect_never_writes_an_unchecked_file(self):
        from unittest import mock
        with mock.patch.object(u, "wireguard_tool", return_value="/bin/true"), mock.patch.object(u, "tunnel_up", return_value=False):
            with self.assertRaises(u.UltraError):
                u.connect(wgconf(extra_if="Post" + "Up = id"))
        self.assertFalse(u.conf_file().exists())

    @unittest.skipIf(c.IS_WIN, "posix permissions")
    def test_failed_connect_cleans_up_and_explains(self):
        from unittest import mock

        class R:
            returncode, stdout, stderr = 1, "", "[#] ip link add x\nError: something specific\n[#] ip link delete dev x"
        with mock.patch.object(u, "wireguard_tool", return_value="/usr/bin/wg-quick"), mock.patch.object(u, "tunnel_up", return_value=False), \
                mock.patch.object(u, "_linux_cmd", side_effect=lambda x: x), mock.patch("gr_ultra.subprocess.run", return_value=R()):
            with self.assertRaises(u.UltraError) as cm:
                u.connect(wgconf())
        self.assertIn("something specific", str(cm.exception))
        self.assertFalse(u.conf_file().exists(), "the plain file must not be left behind")

    @unittest.skipIf(c.IS_WIN, "posix permissions")
    def test_plain_file_is_private_while_it_exists(self):
        from unittest import mock

        class R:
            returncode, stdout, stderr = 0, "", ""
        seen = {}

        def fake_run(cmd, **kw):
            seen["mode"] = os.stat(u.conf_file()).st_mode & 0o777
            return R()
        with mock.patch.object(u, "wireguard_tool", return_value="/usr/bin/wg-quick"), mock.patch.object(u, "tunnel_up", side_effect=[False, True, True]), \
                mock.patch.object(u, "_linux_cmd", side_effect=lambda x: x), mock.patch("gr_ultra.subprocess.run", side_effect=fake_run):
            u.connect(wgconf())
        self.assertEqual(seen["mode"], 0o600)
        u.conf_file().unlink(missing_ok=True)

    def test_watcher_alerts_once_when_tunnel_drops(self):
        from unittest import mock
        events = []
        self.bus.emit = lambda lvl, src, msg: events.append((lvl, msg))
        self.bus.notify = lambda *a: events.append(("notify", a[1]))
        w = u.UltraRookWatch(self.cfg, self.bus)
        with mock.patch.object(u, "tunnel_up", return_value=False):
            w.tick()
            self.assertEqual(events, [])                        # user did not want it on
            self.cfg.set("ultra_want", True)
            w.tick()
            w.tick()
        self.assertEqual(len([e for e in events if e[0] == "notify"]), 1, "alert exactly once")
        with mock.patch.object(u, "tunnel_up", return_value=True):
            w.tick()
        self.assertFalse(w.alerted)
        with mock.patch.object(u, "tunnel_up", return_value=False):
            w.tick()
        self.assertEqual(len([e for e in events if e[0] == "notify"]), 2, "alerts again after a recovery")

    def test_cli_makeconf_writes_private_files(self):
        out = Path(tempfile.mkdtemp(dir=HOME)) / "o"
        r = subprocess.run([sys.executable, str(ROOT / "tools" / "ultrarook_makeconf.py"), "203.0.113.5", "--out", str(out)], capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stderr)
        for n in ("server-wg0.conf", "client.conf", "SERVER-STEPS.txt"):
            self.assertTrue((out / n).exists())
            if not c.IS_WIN:
                self.assertEqual(os.stat(out / n).st_mode & 0o777, 0o600)
        self.assertNotEqual(subprocess.run([sys.executable, str(ROOT / "tools" / "ultrarook_makeconf.py"), "bad host"], capture_output=True).returncode, 0)


# ---------------------------------------------------------------------------------------------- Ultra Rook Free mode (Tor)
import gr_tor as tor  # noqa: E402


def fake_registry():
    """A stand-in for Windows' registry so the proxy logic can be tested anywhere."""
    import types
    reg = types.ModuleType("FakeReg")
    reg.HKEY_CURRENT_USER, reg.REG_SZ, reg.REG_DWORD = "HKCU", 1, 4
    reg.store = {}

    class Key:
        def __init__(self, path):
            self.path = path

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

    def open_key(hive, path, *a):
        if (hive, path) not in reg.store and not reg.store.get("__exists__"):
            reg.store.setdefault((hive, path), {})
        return Key((hive, path))
    reg.OpenKey = reg.CreateKey = open_key

    def query(k, name):
        try:
            return reg.store[k.path][name], 1
        except KeyError:
            raise OSError(2, "not found") from None
    reg.QueryValueEx = query

    def setv(k, name, _r, _t, val):
        reg.store.setdefault(k.path, {})[name] = val
    reg.SetValueEx = setv

    def delv(k, name):
        try:
            del reg.store[k.path][name]
        except KeyError:
            raise OSError(2, "not found") from None
    reg.DeleteValue = delv
    return reg


class TorConfig(unittest.TestCase):
    def test_torrc_listens_only_on_this_computer(self):
        p = tor.make_torrc(Path(tempfile.mkdtemp(dir=HOME)), 19050, 18118)
        text = p.read_text()
        self.assertIn("SocksPort 127.0.0.1:19050", text)
        self.assertIn("HTTPTunnelPort 127.0.0.1:18118", text)
        self.assertNotIn("0.0.0.0", text)
        for line in text.splitlines():
            if "Port" in line:
                self.assertIn("127.0.0.1:", line)
        self.assertIn("ClientOnly 1", text)      # never act as a relay for other people's traffic
        self.assertIn("SafeSocks 1", text)

    def test_progress_is_read_from_the_log(self):
        d = Path(tempfile.mkdtemp(dir=HOME))
        log = d / "tor.log"
        self.assertEqual(tor.read_progress(log), 0)
        log.write_text("Nov 10 [notice] Bootstrapped 5% (conn): x\nNov 10 [notice] Bootstrapped 45% (loading_descriptors): y\n")
        self.assertEqual(tor.read_progress(log), 45)
        log.write_text(log.read_text() + "[notice] Bootstrapped 100% (done): Done\n")
        self.assertEqual(tor.read_progress(log), 100)

    def test_free_ports_are_different_and_bindable(self):
        a, b = tor.free_port(), tor.free_port()
        self.assertTrue(1024 < a < 65536 and 1024 < b < 65536)

    def test_custom_engine_path_is_used(self):
        f = Path(tempfile.mkdtemp(dir=HOME)) / "tor"
        f.write_text("x")
        self.assertEqual(tor.find_tor(str(f)), str(f))

    def test_start_without_engine_explains(self):
        from unittest import mock
        r = tor.TorRunner(Path(tempfile.mkdtemp(dir=HOME)))
        with mock.patch.object(tor, "find_tor", return_value=None):
            with self.assertRaises(tor.TorError) as cm:
                r.start()
        self.assertIn("not installed", str(cm.exception))


class TorProxy(unittest.TestCase):
    def test_set_then_restore_brings_back_exactly_the_old_settings(self):
        reg = fake_registry()
        key = ("HKCU", tor.INET_KEY)
        reg.store[key] = {"ProxyEnable": 1, "ProxyServer": "corp-proxy:3128", "ProxyOverride": "*.corp;<local>"}
        prev = tor.set_system_proxy(18118, reg)
        self.assertEqual(prev["ProxyServer"], "corp-proxy:3128")
        self.assertEqual(reg.store[key]["ProxyServer"], "127.0.0.1:18118")
        self.assertEqual(reg.store[key]["ProxyEnable"], 1)
        tor.restore_system_proxy(prev, reg)
        self.assertEqual(reg.store[key], {"ProxyEnable": 1, "ProxyServer": "corp-proxy:3128", "ProxyOverride": "*.corp;<local>"})

    def test_restore_when_there_was_no_proxy_at_all(self):
        reg = fake_registry()
        key = ("HKCU", tor.INET_KEY)
        reg.store[key] = {}
        prev = tor.set_system_proxy(18118, reg)
        tor.restore_system_proxy(prev, reg)
        self.assertEqual(reg.store[key].get("ProxyEnable"), 0)
        self.assertNotIn("ProxyServer", reg.store[key])

    def test_crash_recovery_restores_the_proxy_so_internet_is_not_broken(self):
        reg = fake_registry()
        key = ("HKCU", tor.INET_KEY)
        reg.store[key] = {"ProxyEnable": 0}
        d, cfg, bus, eng, vault = fresh()
        runner = tor.TorRunner(d)
        prev = tor.set_system_proxy(18118, reg)
        cfg.set("tor_proxy_set", True)
        cfg.set("tor_prev_proxy", prev)
        cfg.set("tor_want", True)
        self.assertTrue(tor.recover_after_crash(cfg, runner, reg))      # Tor is not running -> must restore
        self.assertEqual(reg.store[key]["ProxyEnable"], 0)
        self.assertFalse(cfg.get("tor_proxy_set"))
        self.assertFalse(tor.recover_after_crash(cfg, runner, reg))      # nothing to do the second time

    def test_watcher_restores_proxy_and_alerts_once_when_tor_dies(self):
        from unittest import mock
        reg = fake_registry()
        key = ("HKCU", tor.INET_KEY)
        reg.store[key] = {"ProxyEnable": 0}
        d, cfg, bus, eng, vault = fresh()
        events = []
        bus.emit = lambda lvl, src, msg: events.append(lvl)
        bus.notify = lambda *a: events.append("notify")
        runner = tor.TorRunner(d)
        prev = tor.set_system_proxy(18118, reg)
        cfg.set("tor_proxy_set", True)
        cfg.set("tor_prev_proxy", prev)
        w = tor.TorWatch(cfg, bus, runner, reg)
        with mock.patch.object(runner, "running", return_value=False):
            w.tick()
            self.assertEqual(events, [])                                  # user did not switch it on
            cfg.set("tor_want", True)
            w.tick()
            w.tick()
        self.assertEqual(events.count("notify"), 1)
        self.assertEqual(reg.store[key]["ProxyEnable"], 0, "proxy must be restored when Tor dies")
        self.assertFalse(cfg.get("tor_proxy_set"))


class TorCheck(unittest.TestCase):
    def fake_proxy(self, payload):
        import http.server
        import threading

        class H(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                b = payload.encode()
                self.send_response(200)
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)

            def log_message(self, *a):
                pass
        srv = http.server.HTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        self.addCleanup(lambda: (srv.shutdown(), srv.server_close()))
        return srv.server_port

    def test_checker_says_tor(self):
        port = self.fake_proxy('{"IsTor": true, "IP": "185.220.101.1"}')
        self.assertEqual(tor.check_through_tor(port, "http://check.test/api/ip", 5), (True, "185.220.101.1"))

    def test_checker_says_not_tor(self):
        port = self.fake_proxy('{"IsTor": false, "IP": "203.0.113.9"}')
        self.assertEqual(tor.check_through_tor(port, "http://check.test/api/ip", 5), (False, "203.0.113.9"))

    def test_unreachable_or_garbage_is_unverified_not_trusted(self):
        self.assertEqual(tor.check_through_tor(9, "http://check.test/api/ip", 1), (None, None))
        port = self.fake_proxy("<html>captive portal</html>")
        self.assertEqual(tor.check_through_tor(port, "http://check.test/api/ip", 5), (None, None))


@unittest.skipUnless(tor.find_tor() and not c.IS_WIN, "needs the real Tor program")
class TorReal(unittest.TestCase):
    """Runs the genuine Tor program. (It cannot finish joining the real Tor network from a sealed test machine.)"""

    def test_start_listen_locally_and_stop(self):
        r = tor.TorRunner(Path(tempfile.mkdtemp(dir=HOME)))
        r.start()
        try:
            end = time.time() + 15
            while time.time() < end and not (r.state().get("http") and tor.port_open(r.state()["http"])):
                time.sleep(0.3)
            st = r.state()
            self.assertTrue(r.running())
            self.assertTrue(tor.port_open(st["http"]) and tor.port_open(st["socks"]))
            out = subprocess.run(["ss", "-ltn"], capture_output=True, text=True).stdout if __import__("shutil").which("ss") else ""
            if out:
                self.assertNotIn(f"0.0.0.0:{st['http']}", out)
                self.assertNotIn(f"*:{st['http']}", out)
            self.assertGreaterEqual(r.progress(), 0)
        finally:
            r.stop()
        time.sleep(1)
        self.assertFalse(r.running())
        self.assertFalse(tor.port_open(st["http"]))


# ---------------------------------------------------------------------------------------------- self-recognition + app icon
import gr_icons as icons  # noqa: E402


class SelfRecognition(unittest.TestCase):
    def test_own_files_list_is_trusted_only_when_the_manifest_vouches_for_it(self):
        own = c.Engine._load_own_hashes()
        self.assertGreater(len(own), 20)
        self.assertIn(hashlib.sha256((ROOT / "gr_office.py").read_bytes()).hexdigest(), own)

    def test_green_rook_source_files_are_never_flagged_as_threats(self):
        d, cfg, bus, eng, vault = fresh()
        flagged = [p.name for p in ROOT.glob("*.py") if eng.scan_file(p, cloud=False).verdict in (c.MALICIOUS, c.SUSPICIOUS)]
        self.assertEqual(flagged, [])

    def test_a_copy_inside_a_zip_is_clean_but_an_edited_file_is_not(self):
        d, cfg, bus, eng, vault = fresh()
        for mode in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED):          # uncompressed zips show the raw text, so test both
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", mode) as z:
                z.write(ROOT / "gr_office.py", "GreenRook/gr_office.py")
                z.write(ROOT / "gr_selftest.py", "GreenRook/gr_selftest.py")
            (d / f"own{mode}.zip").write_bytes(buf.getvalue())
            self.assertEqual(eng.scan_file(d / f"own{mode}.zip", cloud=False).verdict, c.CLEAN, mode)
        edited = (ROOT / "gr_office.py").read_text() + "\n# CreateObject(\"Outlook.Application\") AddressEntries RegWrite AutoOpen URLDownloadToFile\n"
        (d / "gr_office.py").write_text(edited)
        self.assertIn(eng.scan_file(d / "gr_office.py", cloud=False).verdict, (c.MALICIOUS, c.SUSPICIOUS), "an altered copy must still be caught")

    def test_samples_are_not_whitelisted(self):
        own = Path(ROOT / "OWNFILES.sha256").read_text()
        self.assertNotIn("samples/", own)

    @unittest.skipUnless(c.psutil and not c.IS_WIN, "needs psutil + POSIX")
    def test_programs_started_by_green_rook_are_recognised(self):
        child = subprocess.Popen(["sleep", "20"])
        try:
            self.assertTrue(g.is_own_descendant(c.psutil.Process(child.pid), os.getpid()))
            self.assertFalse(g.is_own_descendant(c.psutil.Process(1), os.getpid()))
        finally:
            child.kill()
            child.wait()

    def test_no_suspicious_powershell_option_in_our_own_scripts(self):
        for f in ("gr_setup.py", "extras/Unblock-Files.bat"):
            self.assertNotIn("ExecutionPolicy", (ROOT / f).read_text(), f)


class AppIcon(unittest.TestCase):
    def test_every_preset_has_its_files(self):
        for name, _ in icons.PRESETS:
            p = icons.paths(name)
            self.assertTrue(all(x.exists() for x in p.values()), name)
            self.assertEqual(icons.png_size(p["png"].read_bytes()), (256, 256))
            self.assertEqual(icons.png_size(p["logo"].read_bytes()), (44, 44))

    def test_unknown_choice_falls_back_to_default(self):
        self.assertEqual(icons.paths("nope")["png"].name, "green.png")

    def test_png_to_ico_is_a_valid_icon_file(self):
        png = icons.paths("blue")["png"].read_bytes()
        ico = icons.png_to_ico(png)
        self.assertEqual(ico[:6], b"\x00\x00\x01\x00\x01\x00")
        try:
            from PIL import Image
        except ImportError:
            self.skipTest("Pillow not installed")
        im = Image.open(io.BytesIO(ico))
        self.assertEqual(im.size, (256, 256))

    def test_bad_images_are_refused_with_clear_messages(self):
        d = Path(tempfile.mkdtemp(dir=HOME))
        (d / "x.png").write_bytes(b"not a png")
        with self.assertRaises(icons.IconError) as cm:
            icons.make_custom(str(d / "x.png"))
        self.assertIn("PNG", str(cm.exception))
        with self.assertRaises(icons.IconError):
            icons.png_to_ico(b"\x89PNG\r\n\x1a\n" + b"\0" * 8 + (1000).to_bytes(4, "big") + (1000).to_bytes(4, "big"))

    def test_install_for_shortcuts_replaces_the_icon_files_in_the_install_folder(self):
        target = Path(tempfile.mkdtemp(dir=HOME))
        self.assertTrue(icons.install_for_shortcuts("gold", target))
        self.assertEqual((target / "greenrook.ico").read_bytes(), icons.paths("gold")["ico"].read_bytes())
        self.assertFalse(icons.install_for_shortcuts("gold", target / "missing" / "deeper") and False)
