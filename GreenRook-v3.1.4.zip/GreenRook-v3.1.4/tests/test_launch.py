"""Tests for single-window startup handoff."""
import queue
import socket
import threading
import time
import unittest

import gr_launch


class LaunchTests(unittest.TestCase):
    def setUp(self):
        self.listener = gr_launch.bind_instance_socket(("127.0.0.1", 0))
        self.assertIsNotNone(self.listener)
        self.address = self.listener.getsockname()
        self.inbox = queue.Queue()
        self.stop = threading.Event()
        self.thread = threading.Thread(target=gr_launch.serve_instance_requests,
                                       args=(self.listener, self.inbox, self.stop), daemon=True)
        self.thread.start()

    def tearDown(self):
        self.stop.set()
        self.listener.close()
        self.thread.join(timeout=1)

    def test_second_launch_requests_focus_instead_of_opening_again(self):
        self.assertTrue(gr_launch.send_instance_request(self.address, "SHOW"))
        self.assertEqual(self.inbox.get(timeout=1), "SHOW")
        self.assertIsNone(gr_launch.bind_instance_socket(self.address))

    def test_admin_shortcut_is_handed_to_existing_window(self):
        self.assertTrue(gr_launch.send_instance_request(self.address, "ADMIN"))
        self.assertEqual(self.inbox.get(timeout=1), "ADMIN")

    def test_elevated_restart_waits_for_current_window_to_release_lock(self):
        address = self.address
        def close_soon():
            time.sleep(0.15)
            self.stop.set()
            self.listener.close()
        threading.Thread(target=close_soon, daemon=True).start()
        new_listener = gr_launch.bind_instance_socket(address, wait=1.5, poll=0.05)
        self.assertIsNotNone(new_listener)
        new_listener.close()

    def test_only_known_requests_are_sent(self):
        self.assertFalse(gr_launch.send_instance_request(self.address, "QUIT"))
        with socket.create_connection(self.address, timeout=1) as conn:
            conn.sendall(b"QUIT\n")
            self.assertEqual(conn.recv(8), b"NO")
        self.assertTrue(self.inbox.empty())


if __name__ == "__main__":
    unittest.main()
