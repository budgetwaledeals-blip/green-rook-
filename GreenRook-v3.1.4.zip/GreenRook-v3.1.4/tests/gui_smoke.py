"""GUI smoke test. Run:  xvfb-run -a python tests/gui_smoke.py     (skipped automatically when no display is available)"""
import os
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.argv.append("--no-watchdog")
home = tempfile.mkdtemp(prefix="gr_gui_")
for k in ("HOME", "APPDATA", "USERPROFILE"):
    os.environ[k] = home

try:
    import tkinter as tk
    from tkinter import filedialog, messagebox
    probe = tk.Tk()
    probe.destroy()
except Exception as e:  # no tkinter / no display
    print("SKIP: no display available:", e)
    sys.exit(0)

import greenrook  # noqa: E402
import gr_intel  # noqa: E402

shown = []
for name in ("showinfo", "showwarning", "showerror"):
    setattr(messagebox, name, lambda *a, _n=name, **k: shown.append((_n, a)))
messagebox.askyesno = lambda *a, **k: True
messagebox.askyesnocancel = lambda *a, **k: False

app = greenrook.App()
fails = []


def pump(seconds=0.5):
    end = time.time() + seconds
    while time.time() < end:
        app.update()
        time.sleep(0.02)


def wait(cond, limit=40):
    end = time.time() + limit
    while time.time() < end and not cond():
        pump(0.1)
    return cond()


def check(name, ok, detail=""):
    print(("PASS " if ok else "FAIL ") + name + (f"  [{detail}]" if detail else ""))
    if not ok:
        fails.append(name)


try:
    for key, _, _ in greenrook.PAGES:
        app.show(key)
        pump(0.1)
    check("every page builds and shows", True, f"{len(greenrook.PAGES)} pages")
    check("grouped navigation includes every screen", len(app.nav) == len(greenrook.PAGES))
    check("Ramparts page is registered", "ramparts" in app.pages)
    app.show("sweep")
    check("scan view has the filling rook and three stages", hasattr(app, "scan_rook") and len(app.scan_stage_labels) == 3)

    # scan a folder holding EICAR + a clean file
    d = Path(home) / "scanme"
    d.mkdir()
    (d / "bad.com").write_text("X5O!P%@AP[4\\PZX54(P^)7CC)7}$" + "EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*")
    (d / "bad2.com").write_text("X5O!P%@AP[4\\PZX54(P^)7CC)7}$" + "EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*")
    (d / "fine.txt").write_text("hello")
    app.engine.cfg.set("cloud_lookup", False)
    app.show("sweep")
    check("start_scan accepts a folder", app.start_scan([str(d)], False, "Folder scan") is True)
    check("scan finishes", wait(lambda: app.scan_total >= 1 and not app.scan_thread.is_alive()))
    pump(0.5)
    check("scan counters and rook finish cleanly", app.scan_metrics["files"].cget("text") == "3" and app.scan_rook.value == 1.0)
    check("threats listed", len(app.scan_tree.get_children()) == 2, f"{len(app.all_hits)} hit(s)")
    app.show("keep")
    pump(0.4)
    check("Home shows the 'threats waiting' card with Clean/Delete", app.threat_card.winfo_ismapped() and "2 threats" in app.threat_title.cget("text"),
          app.status_title.cget("text"))
    app.show("sweep")
    iid = app.scan_tree.get_children()[0]
    app.scan_tree.selection_set(iid)
    pump(0.3)
    txt = app.explain_box.get("1.0", "end")
    check("explanation pane fills in", "How sure" in txt and "hard evidence" in txt, txt.splitlines()[0])
    out = Path(home) / "rep.html"
    filedialog.asksaveasfilename = lambda *a, **k: str(out)
    greenrook.open_path = lambda p: None
    app.save_report()
    check("report saved", out.exists() and "bad.com" in out.read_text(), f"{out.stat().st_size} bytes" if out.exists() else "")
    jout = Path(home) / "rep.json"
    filedialog.asksaveasfilename = lambda *a, **k: str(jout)
    app.save_report()
    check("JSON report saved", jout.exists() and '"flagged": 2' in jout.read_text())
    # Delete selected: erase one file for good
    victim = [i for i, r in app.scan_items.items() if r.path.endswith("bad2.com")][0]
    app.scan_tree.selection_set(victim)
    app.delete_selected()
    check("Delete selected erases the file", not (d / "bad2.com").exists() and victim not in app.scan_items and len(app.vault.index) == 0)
    check("Delete never touches Green Rook's own files", __import__("gr_core").safe_delete(str(__import__("gr_core").APP_DIR / "gr_core.py"))[0] is False)
    # Clean all: the rest goes to quarantine
    app.clean_all()
    check("Clean all moves the rest to Quarantine", not (d / "bad.com").exists() and len(app.vault.index) == 1 and not app.scan_items)
    app.show("keep")
    pump(0.4)
    check("Home goes back to 'protected' and hides the card", not app.threat_card.winfo_ismapped() and "protected" in app.status_title.cget("text"),
          app.status_title.cget("text"))
    app.show("vault")
    pump(0.2)
    check("Quarantine page lists the cleaned file", len(app.q_tree.get_children()) == 1)
    app.show("chronicle")
    app.set_history_filter("threats")
    check("history filter can switch to threats", app.history_filter == "threats")
    app.set_history_filter("all")
    app.show("sweep")

    # health + self-test buttons
    app.show("ramparts")
    app.run_health()
    check("health check fills the table", wait(lambda: len(app.health_tree.get_children()) >= 3), f"{len(app.health_tree.get_children())} rows")
    app.run_selftest()
    check("self-test finishes and passes", wait(lambda: "checks passed" in app.selftest_box.get("1.0", "end")) and "FAIL" not in app.selftest_box.get("1.0", "end"),
          app.selftest_box.get("1.0", "end").strip().splitlines()[-1])

    # signed pack through the UI handlers
    priv, pub = gr_intel.generate_keypair()
    pubf, packf = Path(home) / "k.pub", Path(home) / "p.grpack"
    pubf.write_text(pub)
    packf.write_text(gr_intel.sign_pack({"name": "guitest", "serial": 1, "domains": ["gui-evil.example"]}, priv))
    filedialog.askopenfilename = lambda *a, **k: str(pubf)
    app.cfg.set("tamper_protection", False)          # skip the confirmation dialog
    app.trust_key()
    filedialog.askopenfilename = lambda *a, **k: str(packf)
    app.install_pack()
    check("signed pack installs from the Armory", "gui-evil.example" in app.web.blocklist and any(m[0] == "showinfo" for m in shown))
    app.show("armory")
    check("Armory lists the active pack", "guitest" in app.intel_lbl.cget("text"), app.intel_lbl.cget("text")[:70])

    # Ultra Rook page (the WireGuard engine itself is replaced by a stand-in; the real tunnel is covered by tests/e2e_tunnel.py)
    import gr_ultra
    state = {"up": False}
    gr_ultra.wireguard_tool = lambda: "/x/wg-quick"
    gr_ultra.tunnel_up = lambda: state["up"]
    gr_ultra.connect = lambda conf: state.update(up=True) or "Connected."
    gr_ultra.disconnect = lambda: state.update(up=False) or "Disconnected."
    gr_ultra.fetch_public_ip = lambda *a, **k: "203.0.113.77" if state["up"] else "198.51.100.2"
    app.show("ultra")
    pump(0.3)
    check("Ultra Rook opens in FREE (Tor) mode by default", app.ur_mode() == "tor" and app.ur_free.winfo_ismapped() and not app.ur_wg.winfo_ismapped())
    # ---- Free mode with a stand-in Tor (real Tor is covered by the unit tests)
    import gr_tor

    class FakeTor:
        http_port, ups = 18118, False

        def running(self):
            return self.ups

        def start(self):
            self.ups = True

        def wait_ready(self, secs, on_progress=None):
            on_progress and on_progress(60)
            return True

        def stop(self):
            self.ups = False

        def explain_failure(self):
            return "failed"
    import gr_tor as _gt
    _gt.find_tor = lambda custom=None: None
    app.refresh_ultra()
    pump(0.3)
    check("missing Tor engine shows the free 'Install Tor' card", app.tor_tool_card.winfo_ismapped())
    app.tor = FakeTor()
    app.tor_watch.runner = app.tor
    changes = []
    gr_tor.find_tor = lambda custom=None: "/x/tor"
    app.refresh_ultra()
    pump(0.2)
    check("the install card disappears once the engine is found", not app.tor_tool_card.winfo_ismapped())
    gr_tor.set_system_proxy = lambda port, reg=None: changes.append(("set", port)) or {"ProxyEnable": 0}
    gr_tor.restore_system_proxy = lambda prev, reg=None: changes.append(("restore", prev))
    gr_tor.check_through_tor = lambda port, *a, **k: (True, "185.220.101.9")
    app.refresh_ultra()
    app.ur_connect()
    check("Free mode connects and Tor's checker verifies it", wait(lambda: "ON" in app.ur_title.cget("text") and "OFF" not in app.ur_title.cget("text"))
          and "185.220.101.9" in app.ur_ip.cget("text"), app.ur_title.cget("text"))
    check("the PC's proxy was pointed at local Tor", ("set", 18118) in changes and app.cfg.get("tor_proxy_set") is True)
    app.ur_disconnect()
    check("Free mode off restores the proxy", wait(lambda: "OFF" in app.ur_title.cget("text")) and changes[-1][0] == "restore" and not app.cfg.get("tor_proxy_set"))
    app.tor.ups = True
    app.ur_set_mode("wg")
    check("cannot change mode while connected", app.ur_mode() == "tor")
    app.tor.ups = False
    app.ur_set_mode("wg")
    pump(0.3)
    check("own-server mode shows the server panel", app.ur_mode() == "wg" and app.ur_wg.winfo_ismapped() and not app.ur_free.winfo_ismapped())
    check("Ultra Rook page starts OFF with no servers", "OFF" in app.ur_title.cget("text") and not app.ur_tree.get_children())
    server, client, _ = gr_ultra.make_wireguard_pair("203.0.113.5")
    goodf, badf = Path(home) / "client.conf", Path(home) / "evil.conf"
    goodf.write_text(client)
    badf.write_text(client.replace("[Peer]", "Post" + "Up = id\n\n[Peer]"))
    filedialog.askopenfilename = lambda *a, **k: str(badf)
    shown.clear()
    app.ur_add()
    check("a config with command hooks is refused with a clear message", not app.ur_tree.get_children() and shown and "command hook" in str(shown[-1][1]))
    filedialog.askopenfilename = lambda *a, **k: str(goodf)
    app.ur_add()
    check("a normal server file is added and shown", len(app.ur_tree.get_children()) == 1 and "client" in app.ur_tree.item(app.ur_tree.get_children()[0], "values")[0])
    enc = list((Path(home) / ".greenrook" / "ultrarook").glob("*.enc")) if (Path(home) / ".greenrook").exists() else list(Path(home).rglob("ultrarook/*.enc"))
    check("its keys are stored encrypted", enc and b"PrivateKey" not in enc[0].read_bytes())
    app.ur_connect()
    check("Connect turns Ultra Rook ON and verifies the address changed", wait(lambda: "ON" in app.ur_title.cget("text") and "OFF" not in app.ur_title.cget("text")) and "203.0.113.77" in app.ur_ip.cget("text"),
          app.ur_ip.cget("text"))
    check("the app remembers you wanted it on (for drop alerts)", app.cfg.get("ultra_want") is True)
    app.ur_disconnect()
    check("Disconnect turns it OFF again", wait(lambda: "OFF" in app.ur_title.cget("text")) and app.cfg.get("ultra_want") is False)
    state["up"] = True
    app.ur_check_ip()
    check("Check my address shows what websites see", wait(lambda: "203.0.113.77" in app.ur_ip.cget("text")))
    state["up"] = False
    app.show("armory")
    pump(0.2)
    check("website list moved to Settings", "websites" in app.block_status.cget("text"))
    check("the old Web safety page is gone", "gate" not in app.pages and all(k != "gate" for k, _, _ in greenrook.PAGES))

    # ---- changing the app icon from inside the app
    import gr_icons
    before = (greenrook.INSTALL_DIR / "greenrook.ico").read_bytes()
    app.show("armory")
    pump(0.3)
    check("Settings shows six icon choices", len(app.icon_boxes) == 6)
    app.pick_icon("blue")
    pump(0.2)
    check("choosing an icon saves it and updates the sidebar logo", app.cfg.get("app_icon") == "blue" and str(app.logo_label.cget("image")) == str(app.logo_img))
    check("running from the download folder does not overwrite its files", (greenrook.INSTALL_DIR / "greenrook.ico").read_bytes() == before)
    own = Path(home) / "mine.png"
    __import__("shutil").copy(gr_icons.ICON_DIR / "purple.png", own)
    filedialog.askopenfilename = lambda *a, **k: str(own)
    shown.clear()
    app.pick_own_icon()
    pump(0.2)
    check("'Use my own image' works with a square PNG", app.cfg.get("app_icon") == "custom" and gr_icons.paths("custom")["ico"].exists())
    check("the custom icon is a valid .ico", gr_icons.paths("custom")["ico"].read_bytes()[:6] == b"\x00\x00\x01\x00\x01\x00")
    tall = Path(home) / "tall.png"
    import tkinter as _tk
    im = _tk.PhotoImage(width=100, height=60)
    im.put("#336699", to=(0, 0, 100, 60))
    im.write(str(tall), format="png")
    filedialog.askopenfilename = lambda *a, **k: str(tall)
    shown.clear()
    app.pick_own_icon()
    check("a non-square picture is refused with a clear message", app.cfg.get("app_icon") == "custom" and shown and "square" in str(shown[-1][1]))
    app.pick_icon("green")
    check("'Back to the original' restores the default", app.cfg.get("app_icon") == "green")

    # shield toggling / dashboard
    app.toggle_shield("camera_guard", False, "Camera Guard")
    app.refresh_dashboard()
    check("dashboard reacts to a guard being off", "Camera" in app.status_sub.cget("text"))
    check("scheduled-scan helper reports whether a scan started", app.run_preset("quick", silent=True) in (True, False))
finally:
    app.broker.shutdown = True
    for s in (*app.services.values(), app.tamper):
        s.alive = False
    try:
        app.destroy()
    except Exception:
        pass
print("\n" + ("ALL GUI CHECKS PASSED" if not fails else f"{len(fails)} FAILED: {fails}"))
sys.exit(1 if fails else 0)
