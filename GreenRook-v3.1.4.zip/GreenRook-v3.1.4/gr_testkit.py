"""Green Rook test kit: builds harmless SYNTHETIC documents (an MS-OVBA compressor and a minimal OLE compound-file
writer) so the Office-macro analysis can be tested without shipping any real macro document."""
import struct


def _compress_chunk(chunk: bytes) -> bytes:
    out, i = bytearray(), 0
    while i < len(chunk):
        flag_pos, flag = len(out), 0
        out.append(0)
        for bit in range(8):
            if i >= len(chunk):
                break
            bits = max((i - 1).bit_length(), 4) if i > 1 else 4
            max_len, max_off = (0xFFFF >> bits) + 3, 1 << bits
            best_len = best_off = 0
            for off in range(1, min(i, max_off) + 1):
                n = 0
                while n < max_len and i + n < len(chunk) and chunk[i - off + n] == chunk[i + n]:
                    n += 1
                if n > best_len:
                    best_len, best_off = n, off
            if best_len >= 3:
                out += (((best_off - 1) << (16 - bits)) | (best_len - 3)).to_bytes(2, "little")
                flag |= 1 << bit
                i += best_len
            else:
                out.append(chunk[i])
                i += 1
        out[flag_pos] = flag
    return bytes(out)


def ovba_compress(data: bytes) -> bytes:
    out = bytearray([1])
    for cs in range(0, len(data), 4096):
        chunk = data[cs:cs + 4096]
        comp = _compress_chunk(chunk)
        if len(comp) < 4096:
            out += struct.pack("<H", 0xB000 | (len(comp) + 2 - 3)) + comp
        else:
            out += struct.pack("<H", 0x3000 | (4096 + 2 - 3)) + chunk.ljust(4096, b"\0")
    return bytes(out)


def _rec(rid, payload):
    return struct.pack("<HI", rid, len(payload)) + payload


def build_vba_dir(modules):
    """modules: [(name, text_offset)] -> uncompressed 'dir' stream with the records the parser needs."""
    d = bytearray()
    d += _rec(0x0001, struct.pack("<I", 1)) + _rec(0x0002, struct.pack("<I", 0x409)) + _rec(0x0014, struct.pack("<I", 0x409))
    d += _rec(0x0003, struct.pack("<H", 1252)) + _rec(0x0004, b"VBAProject")
    d += _rec(0x0005, b"") + _rec(0x0040, b"") + _rec(0x0006, b"") + _rec(0x003D, b"") + _rec(0x0007, struct.pack("<I", 0)) + _rec(0x0008, struct.pack("<I", 0))
    d += struct.pack("<HI", 0x0009, 4) + struct.pack("<IH", 1, 1)          # PROJECTVERSION quirk
    d += _rec(0x000C, b"") + _rec(0x003C, b"")
    d += _rec(0x000F, struct.pack("<H", len(modules))) + _rec(0x0013, struct.pack("<H", 0xFFFF))
    for name, off in modules:
        nb = name.encode()
        d += _rec(0x0019, nb) + _rec(0x0047, name.encode("utf-16le")) + _rec(0x001A, nb) + _rec(0x0032, name.encode("utf-16le"))
        d += _rec(0x001C, b"") + _rec(0x0048, b"") + _rec(0x0031, struct.pack("<I", off)) + _rec(0x001E, struct.pack("<I", 0))
        d += _rec(0x002C, struct.pack("<H", 0xFFFF)) + _rec(0x0021, b"") + _rec(0x002B, b"")
    d += _rec(0x0010, b"")
    return bytes(d)


def make_vba_streams(sources):
    """sources: {module_name: vba_source_text} -> {stream_path: bytes} for Macros/VBA/*"""
    streams, mods = {}, []
    for name, src in sources.items():
        header = b"\x00" * 16                                   # stand-in for the performance-cache header
        streams[f"Macros/VBA/{name}"] = header + ovba_compress(src.encode("cp1252"))
        mods.append((name, len(header)))
    streams["Macros/VBA/dir"] = ovba_compress(build_vba_dir(mods))
    streams["Macros/VBA/_VBA_PROJECT"] = b"\xcc\x61\xff\xff\x00\x00\x00"
    return streams


def build_cfb(streams, mini=True):
    """Write a minimal valid OLE compound file (v3, 512-byte sectors).
    mini=True stores streams smaller than 4096 bytes in the mini stream, exactly like Office does."""
    SS, MSS, EOC, FREE = 512, 64, 0xFFFFFFFE, 0xFFFFFFFF
    nodes = [{"name": "Root Entry", "type": 5, "children": {}, "data": b""}]
    for path, data in streams.items():
        cur = nodes[0]
        parts = path.split("/")
        for k, part in enumerate(parts):
            last = k == len(parts) - 1
            if part not in cur["children"]:
                n = {"name": part, "type": 2 if last else 1, "children": {}, "data": b""}
                nodes.append(n)
                cur["children"][part] = n
            cur = cur["children"][part]
        cur["data"] = data
    order = []

    def number(n):
        n["id"] = len(order)
        order.append(n)
        for c in n["children"].values():
            number(c)
    number(nodes[0])

    sectors, fatmap = [], {}

    def alloc(data, pad=b"\0"):
        if not data:
            return EOC
        cnt = (len(data) + SS - 1) // SS
        data = data.ljust(cnt * SS, pad)
        start = len(sectors)
        for k in range(cnt):
            sectors.append(data[k * SS:(k + 1) * SS])
            fatmap[start + k] = start + k + 1 if k < cnt - 1 else EOC
        return start

    ministream, minifat = bytearray(), []
    for n in order:
        if n["type"] != 2:
            continue
        data = n["data"]
        n["size"] = len(data)
        if mini and 0 < len(data) < 4096:
            first, cnt = len(minifat), (len(data) + MSS - 1) // MSS
            ministream += data.ljust(cnt * MSS, b"\0")
            minifat += [first + k + 1 if k < cnt - 1 else EOC for k in range(cnt)]
            n["start"] = first
        else:
            if len(data) < 4096:                      # without a mini stream every stream must be >= 4096 bytes
                n["size"] = 4096
                data = data.ljust(4096, b"\0")
            n["start"] = alloc(data)
    root_start = alloc(bytes(ministream))
    mf_bytes = struct.pack(f"<{len(minifat)}I", *minifat) if minifat else b""
    mf_start = alloc(mf_bytes, b"\xff")
    n_mf = (len(mf_bytes) + SS - 1) // SS

    ents = []
    for n in order:
        kids = list(n["children"].values())
        for a, b in zip(kids, kids[1:]):
            a["right"] = b["id"]
        e = bytearray(128)
        nm = n["name"].encode("utf-16le")
        e[:len(nm)] = nm
        struct.pack_into("<H", e, 64, len(nm) + 2)
        e[66], e[67] = n["type"], 1
        struct.pack_into("<III", e, 68, FREE, n.get("right", FREE), kids[0]["id"] if kids else FREE)
        if n["type"] == 2:
            struct.pack_into("<I", e, 116, n["start"])
            struct.pack_into("<Q", e, 120, n["size"])
        elif n["type"] == 5:
            struct.pack_into("<I", e, 116, root_start)
            struct.pack_into("<Q", e, 120, len(ministream))
        else:
            struct.pack_into("<I", e, 116, EOC)
        ents.append(bytes(e))
    while len(ents) % 4:
        blank = bytearray(128)
        struct.pack_into("<III", blank, 68, FREE, FREE, FREE)
        ents.append(bytes(blank))
    dir_start = alloc(b"".join(ents))
    ndir = len(ents) // 4

    nfat = 1
    while nfat * 128 < len(sectors) + nfat:
        nfat += 1
    fat_start = len(sectors)
    fat = [FREE] * (nfat * 128)
    for k, v in fatmap.items():
        fat[k] = v
    for k in range(nfat):
        fat[fat_start + k] = 0xFFFFFFFD
    fatbytes = struct.pack(f"<{len(fat)}I", *fat)
    for k in range(nfat):
        sectors.append(fatbytes[k * SS:(k + 1) * SS])

    hdr = bytearray(512)
    hdr[:8] = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"
    struct.pack_into("<HHHHH", hdr, 0x18, 0x3E, 3, 0xFFFE, 9, 6)
    struct.pack_into("<I", hdr, 0x2C, nfat)
    struct.pack_into("<I", hdr, 0x30, dir_start)
    struct.pack_into("<I", hdr, 0x38, 4096)
    struct.pack_into("<III", hdr, 0x3C, mf_start if n_mf else EOC, n_mf, 0)
    struct.pack_into("<I", hdr, 0x44, EOC)
    struct.pack_into("<I", hdr, 0x40, n_mf)
    struct.pack_into("<109I", hdr, 0x4C, *([fat_start + k for k in range(nfat)] + [FREE] * (109 - nfat)))
    del ndir
    return bytes(hdr) + b"".join(sectors)
