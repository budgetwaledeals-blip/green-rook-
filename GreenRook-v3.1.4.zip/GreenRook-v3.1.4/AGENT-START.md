# Green Rook - coding-agent handoff

This is the existing Green Rook desktop antivirus, written in Python with Tkinter. It is not a web app. Keep the desktop app and its current UI; do not replace it with a browser interface.

## Start here

- `greenrook.py` is the desktop window and screen flow.
- `gr_core.py` is scanning, quarantine, configuration, and file analysis.
- `gr_ui.py` contains the visual widgets.
- `gr_setup.py` and `Install.bat` install the app for the current Windows user; an ordinary install does not require administrator permission.
- `gr_launch.py` ensures repeated starts reuse the existing window.
- `tests/` contains the regression suite and a GUI smoke test. The GUI smoke test needs a working Tk display.
- `README.md` documents install, use, tests, and limits. `CHANGELOG.md` records changes.

## Important safeguards

Preserve the checks that prevent unconfirmed heuristic findings from deleting files, including Windows system files and signed software. Do not remove the confirmation steps for destructive actions. Keep quarantine and settings behavior intact.

After changing Python files, run `python tools/make_manifest.py` to refresh `OWNFILES.sha256` and `MANIFEST.sha256`. Then run `python -m unittest discover -s tests -v`. For a desktop-window check, run `xvfb-run -a python tests/gui_smoke.py` on a machine with Tk and Xvfb, or open the app on Windows.

## Current release

Version 3.1.4 keeps the refreshed dashboard, grouped sidebar, scan counters, animated scan rook, History filters, and keyboard-operable controls from 3.1.0. The rook fill shows scanning activity, not percent complete. The startup and installer fixes are listed at the top of `CHANGELOG.md`.

On Windows, startup diagnostics are saved under `%APPDATA%\\GreenRook\\startup-error.log`; interface callback errors go to `interface-error.log` in the same folder.
