# Green Rook changelog

## 3.1.4 - Add-on failures no longer block install
- psutil and cryptography are installed one at a time from ready-made packages; if either fails, setup shows pip's reason and continues.
- Green Rook opens without them (those extras stay off) and Install.bat can add them later.

## 3.1.3 - Installer failures stay visible
- Install.bat no longer closes when the app window fails to open; it pauses and shows the startup error.
- Setup checks that Tk can open a real window before finishing, not only that it imports.
- Detects Install.bat opened from inside the ZIP and prefers the Windows `py` launcher over a Store `python` alias.

## 3.1.2 - Installer startup confirmation
- Removed the console question about starting at login; normal setup now proceeds without waiting for keyboard input.
- The installer waits for the desktop window to initialize and prints the startup log excerpt if it exits early.
- Preserved the 3.1.1 single-window launch and visible startup-error handling.

## 3.1.1 - Startup and installer fixes
- Prevented repeat launches from opening another window; the existing window is brought forward instead.
- Made the in-app administrator restart wait for the previous window to close before starting the elevated window.
- Added clear startup and interface error messages with local diagnostic logs so silent launch failures are easier to report.
- Fixed the scan-stage color reference that could stop the Scan page from opening, and corrected the toast timer redraw.
- Preserved the 3.1.0 dashboard, grouped navigation, scan animation, and scan-result safeguards.

## 3.1.0 - Desktop interface refresh
- Reworked the Home dashboard with clearer protection status, compact metrics, live-shield controls, and a five-entry recent-activity list.
- Grouped the sidebar into Protect, Live shields, Privacy & health, and More; added keyboard focus navigation and compact rows for smaller screens.
- Rebuilt Scan around quick, full, and choose-location actions, live file/findings/rate/time counters, a step indicator, and an animated rook that fills with activity (not a misleading percentage).
- Standardized page headers, table styling, empty states, buttons, status badges, and toast stacking; added keyboard operation for switches and segmented choices.

## 3.0.0 - Privacy shield and safer scan results
- Added seven local checks: browser-saved password count, cookie count, camera/microphone access, Remote Desktop and known remote listeners, likely sensitive documents, DNS/hosts-file redirection, and firewall status.
- Added verified Authenticode / Windows catalog signature checks to avoid flagging genuine signed programs on heuristic-only clues. Windows system-file heuristics are suppressed if signatures cannot be checked; known-malware evidence still takes priority.
- Prevented unconfirmed heuristic results from quarantining system files or signed programs; added direct guardrails to manual deletion.
- Reduced repeat notifications and changed unanswered ordinary prompts to the safe, non-destructive option; ransomware prompts still stop the suspected process on timeout.
- Added explicit, user-confirmed options to clear cookies, manage camera/microphone permissions, disable Remote Desktop, enable Windows Firewall, add public-network stealth rules, use optional Quad9 DNS, and remove suspicious hosts-file redirects. Reversible changes save their prior settings; hosts edits keep a backup.
- Added a password-protected local file safe and tests for scanning, safe lock/unlock, browser data handling and false-positive suppression. The ransomware shield also fingerprints small document samples to catch rapid same-size rewrites on filesystems with coarse timestamps.
- No paid features or subscriptions were added. Protection remains imperfect; keep the OS and its built-in antivirus enabled.


## 2.2.0 - Ultra Rook, installer, Windows fixes
(everything below the "Ultra Rook replaces Web safety" heading is new in 2.2; the rest is 2.1)

## 2.1.0 - hardening upgrade

### Bugs fixed
- **Process Guard resumed every process it touched, even ones a user or another tool had deliberately paused.** It now records
  exactly which processes *it* suspended and resumes only those.
- **Scheduled scans were marked "done" even when they were skipped** (a scan was already running) - `run_preset` returned nothing.
  A skipped scan is now retried on the next tick.
- **Quarantine index could be lost**: it was written non-atomically, and a damaged index silently emptied the vault list.
  All settings / index / blocklist / vault writes are now atomic (temp file + fsync + rename); a damaged index is kept as
  `index.corrupt.json`.
- **Restoring a file could overwrite an existing one** (`.restored` collided on the second restore). Names are now unique, and
  restored bytes are checked against the original SHA-256.
- **Anyone could stop Green Rook from starting** by binding TCP port 47653 first ("already running"). It now only believes
  that if a genuine Green Rook process is alive.
- **Watchdog trusted a recycled PID**; it now checks the process really is Green Rook.
- **Real-time Guard froze while waiting for you to answer a prompt** (the prompt ran on the scanning thread). Files are now
  judged in helper threads (max 4 at once).
- **Heuristic scores could delete good programs.** Green Rook now separates *hard evidence* (known hash, cloud hit, EICAR,
  strong signature) from *behaviour-only guesses*. Only hard evidence, outside operating-system folders, is ever removed
  automatically; guesses always ask. Applies to Real-time, Process, Persistence, USB and scheduled-scan paths.
- Automatic actions could kill critical OS processes (e.g. a `svchost.exe` involved in a network rule). They are now protected.
- File symlinks inside a scanned folder were followed outside it; they are now skipped.
- Allow-list was deep-copied for every file scanned; now a cached set.
- Hosts-file blocklist now keeps a pristine backup (`hosts.backup`) before the first change; blocklist import/update no longer
  mixes signed-pack entries into your own list file.
- Removed dead code (`and True`, `or True`) and unused imports.

### New
- **Office macro analysis**: reads OLE compound files (.doc/.xls/.ppt and `vbaProject.bin` inside .docm/.xlsm/...), decompresses
  the VBA source (MS-OVBA) and judges what it does (auto-run + launching programs, downloads, Outlook mass-mailing, obfuscation).
  Detects macros hidden in files named `.docx/.xlsx/.pptx`.
- **Script-worm / mass-mailer detection** (Melissa / ILOVEYOU behaviour) and rule **R12** (scripts launched from e-mail, browser
  cache, Temp or Downloads folders).
- **Worm-style scanning detector, rule R13** (one program contacting 20+ computers on SMB/RDP/SQL/RPC ports within 30 s - how
  WannaCry, Slammer-era and Conficker-era worms spread). Includes LAN addresses.
- **Ransomware Shield**: new signal - documents that suddenly become random-looking (encrypted) data, so it reacts after ~5 files
  instead of ~30.
- **Signed threat-intelligence packs** (Ed25519): publisher keys you choose to trust, anti-rollback serial numbers, strict schema,
  re-verification on every load. `tools/grsign.py` creates keys and packs. Optional public SHA-256 hash feed over HTTPS.
- **"Explain" pane + confidence rating** on every finding, and **HTML/JSON scan reports**.
- **Ramparts page**: read-only hardening audit (SMBv1, UAC, AutoRun, Secure Boot, firewall, RDP, script host, PATH permissions,
  ...), each tied to the incident it would have blunted.
- **Built-in self-test** (19 checks, harmless files only, checks both detection *and* false positives) - GUI button,
  `Run-SelfTest.bat`, or `python greenrook_cli.py selftest`.
- **Command line** (`greenrook_cli.py`): scan, selftest, health, install-pack, trust-key, update-feeds.
- 36 regression tests (`python -m unittest discover -s tests`) and a GUI smoke test (`xvfb-run -a python tests/gui_smoke.py`).

### Interface redesign (2.1)
- New look: rounded buttons, clean on/off toggles, drawn icons, bordered cards, bigger text. Every screen is written in plain English
  (Home, Scan, Quarantine, Web safety, Camera & USB, Attack blocker, Running programs, Health check, History, Settings).
- **Scan my computer** is the biggest button on Home and Scan. New **Clean all**, **Clean selected**, **Delete selected**, **Delete all**
  and **This file is safe** buttons; Home shows a "threats waiting" card with Clean all / Review / Delete all.
- Delete is safe: it confirms, refuses folders and Green Rook's own files, asks again for system folders, and removes a link without touching its target.
- Action buttons are pinned to the bottom of each page so they can never be pushed off-screen on a small laptop; the window sizes itself to the screen.
- Notifications stack instead of overlapping. The question window uses plain words and a clear countdown.
- Rule texts, settings, buttons and messages rewritten without jargon.

### More bugs fixed in the interface
- **One failing message could permanently freeze the screen loop** (and so stop warnings and questions from appearing, which then
  expired into "block"). Each message is now handled separately and the loop always continues.
- Mouse-wheel scrolling stopped working whenever the pointer was over a child widget.
- Toggle switches could show a stale state after a setting changed elsewhere.
- "Scan selected program" froze the window on large files; it now runs in the background.
- The window could be taller than a small laptop screen, and several buttons silently did nothing when no item was selected; they now say what to do.

### Windows blocking fixes
- Delete and Clean now retry while Defender / the indexer holds a file, clear read-only/hidden flags, take ownership, support very long
  paths, and (as administrator) schedule removal for the next restart when a file is in use.
- If a file cannot be removed, the quarantine copy is rolled back so nothing is lost, and the message says exactly why and what to do
  (administrator, Controlled folder access, or which program has the file open).
- Settings, the quarantine index and other saved files survive another program holding them for a moment (they used to fail with "access denied").
- A quarantine can no longer fail halfway: the original is only removed after the encrypted copy is safely stored.
- The data-folder lock-down verifies the user can still use the folder and undoes itself otherwise.
- New: `Start-GreenRook-Admin.bat`, `Fix-Windows-Blocking.bat`, **Settings -> Restart as administrator**, and a Controlled-folder-access line in Health check.

### Real app installer
- `Install-GreenRook.bat` / `gr_setup.py`: installs Green Rook as a normal app: private Python environment, Desktop + Start Menu icons,
  an Administrator icon, an "Apps & features" entry with a working uninstaller, optional start-with-Windows, and (Linux) a menu entry.
  Installs Python automatically via winget when it is missing. Re-running it upgrades in place.
- Uninstall asks for your Green Rook PIN (if set), keeps your quarantine unless you ask otherwise, and refuses to delete a folder that is not a real installation.
- Optional single-file build: PyInstaller settings corrected for the new modules; Inno Setup script + GitHub Actions workflow that produce `GreenRook-Setup.exe`.
- The protection against deleting Green Rook's own files now also covers the folder a packaged .exe runs from.

### Ultra Rook replaces Web safety
- **New: Ultra Rook** (private connection / VPN client on WireGuard): server profiles stored encrypted, one-click Connect/Disconnect, public-address
  check that proves the address changed, alert if the tunnel drops, strict config validation (refuses command hooks and unknown settings),
  one-click WireGuard install on Windows, and `tools/ultrarook_makeconf.py` to create your own server + client files (keys verified against the real `wg` tool).
- **Removed: the Web safety page.** The dangerous-website list (used by the network watcher) moved to **Settings**; the link checker is now `greenrook_cli.py check-link URL`.
- New tests: 25 Ultra Rook unit tests, GUI tests for the new page, two new self-test checks (21 total), and `tests/e2e_tunnel.py`, which runs a real WireGuard
  tunnel between simulated client, server and internet machines and verifies the visible address changes and is restored.

### Free Ultra Rook, new icon
- **Ultra Rook Free mode (Tor)**: no payment, account or server. Starts Tor locally (127.0.0.1 only), shows connection progress, points browsers at it, verifies with Tor's own
  checker, and always restores the PC's proxy (on disconnect, if Tor dies, and after a crash). WireGuard stays as the advanced "My own server" mode.
- **New icon**: rounded green tile, white rook, protection check. Vector master, PNGs and multi-size .ico in `extras/icon/` (`make_icon.py` regenerates them).
- Fixed: the Tor install card could not be placed when the engine was missing.
