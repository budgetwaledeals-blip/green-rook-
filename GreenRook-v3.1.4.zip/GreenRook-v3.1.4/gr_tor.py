"""
Green Rook - ULTRA ROOK FREE MODE (Tor).

Tor is a free network run by volunteers. Your traffic passes through three of their computers, so websites see the
address of the LAST one instead of yours. No account, no payment, no server of your own.

Honest limits (the app tells the user the same):
  * only programs that use the PC's proxy settings are covered (Edge, Chrome, Firefox and most browsers) - not games, torrents or system services;
  * it is slower than a normal connection and some websites block Tor;
  * browsers can still leak your real address through features such as WebRTC; Tor Browser is the safest way to browse;
  * it hides your address from websites. It is not magic and it is not an antivirus.

Safety rules built in:
  * Tor only listens on THIS computer (127.0.0.1), never on the network;
  * the PC's proxy setting is changed only while connected, the previous setting is saved, and it is ALWAYS restored - on disconnect,
    if Tor dies, and on the next start of Green Rook after a crash (otherwise your internet would appear to be broken);
  * after connecting, Tor's own checker confirms the traffic really leaves through Tor.
"""
import json
import os
import re
import shutil
import socket
import subprocess
import time
import urllib.request
from pathlib import Path

from gr_core import IS_LINUX, IS_WIN, Service, data_dir, psutil

NO_WINDOW = 0x08000000
CHECK_URL = "https://check.torproject.org/api/ip"
INET_KEY = r"Software\Microsoft\Windows\CurrentVersion\Internet Settings"


class TorError(Exception):
    """Message is written for the person using the app."""


# ------------------------------------------------------------------ finding the engine
def find_tor(custom=None):
    """Path of tor(.exe) or None. On Windows the engine lives inside Tor Browser, which the app can install for free with winget."""
    if custom and Path(custom).is_file():
        return str(custom)
    if IS_WIN:
        home = Path.home()
        roots = [os.environ.get("LOCALAPPDATA", ""), os.environ.get("ProgramFiles", ""), os.environ.get("ProgramFiles(x86)", ""),
                 str(home / "Desktop"), str(home / "Downloads"), str(home / "OneDrive" / "Desktop")]
        for r in roots:
            if not r:
                continue
            for sub in ("Tor Browser/Browser/TorBrowser/Tor/tor.exe", "Programs/Tor Browser/Browser/TorBrowser/Tor/tor.exe"):
                p = Path(r) / sub
                if p.exists():
                    return str(p)
    return shutil.which("tor") or (str(Path("/usr/sbin/tor")) if Path("/usr/sbin/tor").exists() else None)


def free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def port_open(port: int, timeout=0.5) -> bool:
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=timeout):
            return True
    except OSError:
        return False


# ------------------------------------------------------------------ configuration
def make_torrc(folder: Path, socks_port: int, http_port: int) -> Path:
    """Write Tor's settings. Everything is bound to 127.0.0.1 so nothing is reachable from the network."""
    folder.mkdir(parents=True, exist_ok=True)
    data = (folder / "tor-data").as_posix()
    log = (folder / "tor.log").as_posix()
    text = (f"DataDirectory {data}\nSocksPort 127.0.0.1:{socks_port}\nHTTPTunnelPort 127.0.0.1:{http_port}\n"
            f"ClientOnly 1\nAvoidDiskWrites 1\nSafeSocks 1\nLog notice file {log}\n")
    p = folder / "torrc"
    p.write_text(text)
    return p


BOOT_RE = re.compile(r"Bootstrapped (\d+)%")


def read_progress(log_path: Path) -> int:
    """How far Tor's connection to its network has got (0-100), read from its log."""
    try:
        hits = BOOT_RE.findall(Path(log_path).read_text("utf-8", "ignore")[-20000:])
        return int(hits[-1]) if hits else 0
    except OSError:
        return 0


# ------------------------------------------------------------------ running Tor
class TorRunner:
    def __init__(self, folder=None):
        self.dir = Path(folder or data_dir()) / "tor"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.state_file = self.dir / "state.json"
        self.log = self.dir / "tor.log"
        self._proc = None

    def state(self) -> dict:
        try:
            return json.loads(self.state_file.read_text())
        except (OSError, ValueError):
            return {}

    def _alive(self, pid) -> bool:
        if not pid:
            return False
        try:
            if psutil:
                p = psutil.Process(pid)
                return p.is_running() and p.status() != psutil.STATUS_ZOMBIE and "tor" in (p.name() or "").lower()
            os.kill(pid, 0)
            return True
        except Exception:
            return False

    def running(self) -> bool:
        return self._alive(self.state().get("pid"))

    @property
    def http_port(self):
        return self.state().get("http")

    def progress(self) -> int:
        return read_progress(self.log)

    def start(self):
        exe = find_tor()
        if not exe:
            raise TorError("The free Tor engine is not installed yet. Use the 'Install Tor (free)' button first.")
        if self.running():
            raise TorError("Free mode is already running.")
        socks, http = free_port(), free_port()
        torrc = make_torrc(self.dir, socks, http)
        self.log.write_text("")
        kw = {"creationflags": NO_WINDOW} if IS_WIN else {"start_new_session": True}
        proc = subprocess.Popen([exe, "-f", str(torrc)], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **kw)
        self._proc = proc
        self.state_file.write_text(json.dumps({"pid": proc.pid, "socks": socks, "http": http, "started": time.time()}))
        return proc

    def wait_ready(self, seconds=90, on_progress=None):
        """Wait until Tor has joined its network (100%). Returns True/False."""
        end, last = time.time() + seconds, -1
        while time.time() < end:
            if not self.running():
                return False
            pct = self.progress()
            if pct != last and on_progress:
                on_progress(pct)
            last = pct
            if pct >= 100:
                return True
            time.sleep(1.0)
        return False

    def stop(self):
        pid = self.state().get("pid")
        if pid and self._alive(pid):
            try:
                if psutil:
                    p = psutil.Process(pid)
                    p.terminate()
                    try:
                        p.wait(6)
                    except Exception:
                        p.kill()
                else:
                    os.kill(pid, 15)
            except Exception:
                pass
        if self._proc is not None:                       # reap the finished child so no zombie is left behind
            try:
                self._proc.wait(timeout=5)
            except Exception:
                pass
            self._proc = None
        try:
            self.state_file.unlink()
        except OSError:
            pass

    def explain_failure(self):
        tail = ""
        try:
            lines = [ln for ln in self.log.read_text("utf-8", "ignore").splitlines() if "[warn]" in ln or "[err]" in ln]
            tail = lines[-1].split("] ", 1)[-1][:160] if lines else ""
        except OSError:
            pass
        return ("Tor could not join its network. Some networks (offices, schools, some countries) block Tor, or the internet may be down." +
                (f"\nLast message from Tor: {tail}" if tail else ""))


# ------------------------------------------------------------------ proof that it works
def check_through_tor(http_port: int, url=CHECK_URL, timeout=30):
    """Ask Tor's own checker what it sees when we connect through our local Tor. Returns (is_tor, address) or (None, None) if unreachable."""
    proxy = f"http://127.0.0.1:{http_port}"
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({"http": proxy, "https": proxy}))
    try:
        with opener.open(urllib.request.Request(url, headers={"User-Agent": "GreenRook-UltraRook"}), timeout=timeout) as r:
            data = json.loads(r.read(2000).decode("utf-8", "ignore"))
        return bool(data.get("IsTor")), str(data.get("IP", ""))
    except Exception:
        return None, None


# ------------------------------------------------------------------ the PC's proxy setting (always restored)
def _flush_windows_proxy():
    try:
        import ctypes
        wininet = ctypes.windll.wininet
        wininet.InternetSetOptionW(None, 39, None, 0)      # settings changed
        wininet.InternetSetOptionW(None, 37, None, 0)      # refresh
    except Exception:
        pass


def get_proxy_settings(reg=None) -> dict:
    """Current system proxy (Windows). Returned so it can be put back exactly."""
    if IS_WIN or reg:
        reg = reg or __import__("winreg")
        out = {}
        try:
            with reg.OpenKey(reg.HKEY_CURRENT_USER, INET_KEY) as k:
                for name in ("ProxyEnable", "ProxyServer", "ProxyOverride"):
                    try:
                        out[name] = reg.QueryValueEx(k, name)[0]
                    except OSError:
                        out[name] = None
        except OSError:
            pass
        return out
    return {}


def set_system_proxy(http_port: int, reg=None) -> dict:
    """Point the PC's proxy at the local Tor. Returns the previous settings (save them!). Windows: registry. Linux: GNOME settings if present."""
    if IS_WIN or reg:
        reg = reg or __import__("winreg")
        prev = get_proxy_settings(reg)
        with reg.CreateKey(reg.HKEY_CURRENT_USER, INET_KEY) as k:
            reg.SetValueEx(k, "ProxyServer", 0, reg.REG_SZ, f"127.0.0.1:{http_port}")
            reg.SetValueEx(k, "ProxyOverride", 0, reg.REG_SZ, "<local>")
            reg.SetValueEx(k, "ProxyEnable", 0, reg.REG_DWORD, 1)
        if not reg.__name__.startswith("Fake"):
            _flush_windows_proxy()
        return prev
    if IS_LINUX and shutil.which("gsettings"):
        def gs(*a):
            return subprocess.run(["gsettings", *a], capture_output=True, text=True, timeout=10).stdout.strip()
        prev = {"mode": gs("get", "org.gnome.system.proxy", "mode")}
        for scheme in ("http", "https"):
            gs("set", f"org.gnome.system.proxy.{scheme}", "host", "127.0.0.1")
            gs("set", f"org.gnome.system.proxy.{scheme}", "port", str(http_port))
        gs("set", "org.gnome.system.proxy", "mode", "manual")
        return prev
    return {}


def restore_system_proxy(prev: dict, reg=None):
    if IS_WIN or reg:
        reg = reg or __import__("winreg")
        with reg.CreateKey(reg.HKEY_CURRENT_USER, INET_KEY) as k:
            enable = prev.get("ProxyEnable")
            reg.SetValueEx(k, "ProxyEnable", 0, reg.REG_DWORD, int(enable or 0))
            for name in ("ProxyServer", "ProxyOverride"):
                if prev.get(name) is None:
                    try:
                        reg.DeleteValue(k, name)
                    except OSError:
                        pass
                else:
                    reg.SetValueEx(k, name, 0, reg.REG_SZ, prev[name])
        if not reg.__name__.startswith("Fake"):
            _flush_windows_proxy()
        return
    if IS_LINUX and shutil.which("gsettings") and prev.get("mode"):
        subprocess.run(["gsettings", "set", "org.gnome.system.proxy", "mode", prev["mode"].strip("'")], capture_output=True, timeout=10)


def recover_after_crash(cfg, runner: "TorRunner", reg=None) -> bool:
    """On start-up: if we changed the proxy earlier but Tor is no longer running, put the old proxy back so the internet works."""
    if cfg.get("tor_proxy_set") and not runner.running():
        restore_system_proxy(cfg.get("tor_prev_proxy") or {}, reg)
        cfg.set("tor_proxy_set", False)
        cfg.set("tor_want", False)
        return True
    return False


# ------------------------------------------------------------------ watcher
class TorWatch(Service):
    interval = 5.0

    def __init__(self, cfg, bus, runner, reg=None):
        super().__init__("TorWatch", True)
        self.cfg, self.bus, self.runner, self.reg, self.alerted = cfg, bus, runner, reg, False

    def tick(self):
        if not self.cfg.get("tor_want"):
            self.alerted = False
            return
        if self.runner.running():
            self.alerted = False
            return
        if self.alerted:
            return
        self.alerted = True
        if self.cfg.get("tor_proxy_set"):                  # never leave the PC pointing at a proxy that is gone
            try:
                restore_system_proxy(self.cfg.get("tor_prev_proxy") or {}, self.reg)
            except Exception:
                pass
            self.cfg.set("tor_proxy_set", False)
        self.bus.emit("THREAT", "Ultra Rook", "Free mode stopped unexpectedly. Your normal connection was restored, so your real address is visible.")
        self.bus.notify("bad", "Ultra Rook (Free) stopped", "Your real address is visible again. Open Ultra Rook and press Connect.")
