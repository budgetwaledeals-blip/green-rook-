"""
Green Rook - app icon choices.  Pick a ready-made colour or use your own square PNG; it changes the window, the logo in the sidebar and
(when installed) the Desktop / Start Menu shortcut icon. Needs only Tkinter (no extra packages).
"""
import struct
import sys
import tkinter as tk
from pathlib import Path

from gr_core import APP_DIR, INSTALL_DIR, IS_WIN, atomic_write, data_dir

PRESETS = [("green", "Classic green"), ("blue", "Ocean blue"), ("purple", "Royal purple"), ("gold", "Gold"), ("red", "Alert red"), ("graphite", "Graphite")]
ICON_DIR = APP_DIR / "icons"
PNG_MAGIC = b"\x89PNG\r\n\x1a\n"


class IconError(Exception):
    """Message is written for the person using the app."""


def custom_dir() -> Path:
    d = Path(data_dir()) / "icon"
    d.mkdir(parents=True, exist_ok=True)
    return d


def paths(choice: str) -> dict:
    """Files for an icon choice ('green'... or 'custom'). Falls back to the default green icon if anything is missing."""
    if choice == "custom":
        d = custom_dir()
        got = {"png": d / "custom.png", "logo": d / "custom-44.png", "ico": d / "custom.ico"}
        if all(p.exists() for p in got.values()):
            return got
        choice = "green"
    names = {n for n, _ in PRESETS}
    choice = choice if choice in names else "green"
    got = {"png": ICON_DIR / f"{choice}.png", "logo": ICON_DIR / f"{choice}-44.png", "ico": ICON_DIR / f"{choice}.ico"}
    if not all(p.exists() for p in got.values()):                      # an older install without the icons folder
        got = {"png": APP_DIR / "greenrook.png", "logo": APP_DIR / "greenrook.png", "ico": APP_DIR / "greenrook.ico"}
    return got


def png_size(data: bytes):
    if data[:8] != PNG_MAGIC or len(data) < 24:
        raise IconError("Please choose a PNG image (a file ending in .png).")
    return struct.unpack(">II", data[16:24])


def png_to_ico(png: bytes) -> bytes:
    """Wrap one PNG picture in a Windows .ico container (Windows Vista and newer read PNG inside .ico)."""
    w, h = png_size(png)
    if max(w, h) > 256:
        raise IconError("Icons can be at most 256 x 256 pixels.")
    head = struct.pack("<HHH", 0, 1, 1)
    entry = struct.pack("<BBBBHHII", w % 256, h % 256, 0, 0, 1, 32, len(png), 22)
    return head + entry + png


def make_custom(src: str) -> dict:
    """Turn the user's own square PNG into the three files the app needs. Uses Tk for resizing, so it needs the app window to exist."""
    src = Path(src)
    try:
        raw = src.read_bytes()
    except OSError as e:
        raise IconError(f"That file could not be read: {e}") from e
    if len(raw) > 8 * 1024 * 1024:
        raise IconError("That image is too large (over 8 MB). Choose a smaller one.")
    w, h = png_size(raw)
    if abs(w - h) > 1:
        raise IconError(f"The image must be square (this one is {w} x {h}). Crop it to a square and try again.")
    if w < 64:
        raise IconError("The image is too small. Use at least 64 x 64 pixels (256 x 256 or bigger is best).")
    try:
        img = tk.PhotoImage(file=str(src))
    except tk.TclError as e:
        raise IconError("That PNG could not be opened. Try saving it again as a normal PNG.") from e
    out = custom_dir()
    big = img if w <= 256 else img.subsample(-(-w // 256))
    big.write(str(out / "custom.png"), format="png")
    img.subsample(max(1, round(w / 44))).write(str(out / "custom-44.png"), format="png")
    atomic_write(out / "custom.ico", png_to_ico((out / "custom.png").read_bytes()), binary=True)
    return paths("custom")


def install_for_shortcuts(choice: str, install_dir=None) -> bool:
    """Copy the chosen icon over greenrook.ico / greenrook.png in the install folder, which is what the Desktop and Start Menu shortcuts point at."""
    if install_dir is None and not (getattr(sys, "frozen", False) or (INSTALL_DIR / "venv").is_dir()):
        return False                            # running straight from the download folder: leave its files alone
    target = Path(install_dir or INSTALL_DIR)
    p = paths(choice)
    try:
        atomic_write(target / "greenrook.ico", p["ico"].read_bytes(), binary=True)
        atomic_write(target / "greenrook.png", p["png"].read_bytes(), binary=True)
    except OSError:
        return False
    if IS_WIN:
        try:                                    # ask Explorer to refresh its icon cache so shortcuts update straight away
            import ctypes
            ctypes.windll.shell32.SHChangeNotify(0x08000000, 0, None, None)
        except Exception:
            pass
    return True
