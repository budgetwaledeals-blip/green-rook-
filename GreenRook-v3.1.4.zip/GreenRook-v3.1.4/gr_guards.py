"""
Green Rook behavioural guards - the layers modelled on Microsoft Defender's design:

  * Rook Rules      ~ Attack Surface Reduction rules (block / ask / audit / off per rule)
  * Process Guard   ~ behaviour monitoring (parent/child, command lines, file reputation, suspend-then-decide)
  * Ransomware Shield ~ Controlled Folder Access (decoy files + mass-change detection + culprit suspension)
  * Persistence Guard ~ autoruns watch (Run keys, Startup folders, scheduled tasks, systemd, cron, launch agents)
  * USB Guard       ~ removable-media scanning and "untrusted program from USB" rule
  * Network Guard   ~ network protection (reverse shells, known-bad hosts, C2-style connections)
  * Tamper Guard    ~ tamper protection (file manifest, config MAC, watchdog restart)
"""
import csv
import hashlib
import hmac
import io
import os
import re
import secrets
import subprocess
import sys
import threading
import time
import zipfile
from collections import deque
from pathlib import Path

from gr_core import (APP_DIR, IS_MAC, IS_WIN, MALICIOUS, SUSPICIOUS, OFFICE, SHELLS, RISKY_DIRS,
                     Service, data_dir, entropy, iter_files, psutil, system_protected, walk_limited)

# --------------------------------------------------------------------------- Rook Rules
RULES = [
    ("R01", "Documents can't start command windows", "Stops Word, Excel, PDF readers and similar apps from opening a command window or script. This is how macro viruses run.", "block"),
    ("R02", "Hidden or scrambled PowerShell", "Stops PowerShell commands that are disguised, hidden, or built to download and run something.", "ask"),
    ("R03", "Password theft", "Stops tools that try to steal Windows passwords or copy the system's secret stores.", "block"),
    ("R04", "Download-and-run tricks", "Stops Windows' own helper programs (certutil, mshta, regsvr32, bitsadmin, rundll32) being used to fetch and start malware.", "block"),
    ("R05", "Ransomware preparation", "Stops commands that delete your backups and restore points - what ransomware does just before it locks your files.", "block"),
    ("R06", "Switching off your security", "Stops commands that turn off Defender or the firewall, or wipe the security logs.", "block"),
    ("R07", "Risky programs in user folders", "Checks any program started from Downloads, Temp or other user folders before it is allowed to keep running.", "ask"),
    ("R08", "Sneaky start-up entries", "Catches programs that add themselves to start-up or scheduled tasks and point at scripts, Temp folders or web addresses.", "ask"),
    ("R09", "Remote control of this PC", "Stops other computers from starting programs here using WMI or PsExec-style tools.", "ask"),
    ("R10", "Programs started from a USB drive", "Holds any program that runs straight from a USB stick or external drive.", "ask"),
    ("R11", "Remote access and bad websites", "Stops hidden remote-control connections and connections to websites on the block list.", "ask"),
    ("R12", "Scripts from e-mail and downloads", "Holds a script saved in an e-mail, browser cache, Temp or Downloads folder when Windows tries to run it (the 'ILOVEYOU' trick).", "ask"),
    ("R13", "Worm-style network scanning", "Holds a program that suddenly contacts dozens of other computers on file-sharing or remote-desktop ports. This is how WannaCry and Conficker spread.", "ask"),
]
RULE_DEFAULT = {r[0]: r[3] for r in RULES}
MODES = ["block", "ask", "audit", "off"]
PS_NAMES = {"powershell.exe", "pwsh.exe", "powershell", "pwsh"}
USB_MOUNTS = []  # filled by USBGuard
def is_own_descendant(proc, me) -> bool:
    """True if `proc` was started by Green Rook itself (directly or through another helper)."""
    try:
        return any(p.pid == me for p in proc.parents())
    except Exception:
        return False


OWN_HELPERS = {"schtasks.exe", "icacls.exe", "crontab", "xdg-open", "open", "pythonw.exe"}


def rule_mode(cfg, rid):
    return (cfg.get("rule_modes") or {}).get(rid, RULE_DEFAULT[rid])


_R03 = re.compile(r"procdump.*lsass|lsass.*\.dmp|comsvcs\.dll.*minidump|" + "sekur" + "lsa|reg(\\.exe)?\\s+save\\s+hklm\\\\(sam|security|system)")
_R04 = re.compile(r"certutil.*-urlcache|mshta(\.exe)?\s+(https?:|vbscript:|javascript:)|regsvr32.*(/i:https?|scrobj\.dll)|"
                  r"bitsadmin.*/transfer|rundll32.*javascript:|curl[^|]*\|\s*(ba)?sh|wget[^|]*\|\s*(ba)?sh")
_R05 = re.compile(r"vssadmin.*delete.*shadows|wmic.*shadowcopy.*delete|wbadmin.*delete.*(catalog|backup)|"
                  r"bcdedit.*recoveryenabled\s+no|bcdedit.*ignoreallfailures|cipher\s+/w")
_R06 = re.compile(r"set-mppreference.*-disable|sc(\.exe)?\s+(stop|config)\s+(windefend|wdnissvc|sense|mpssvc)|net\s+stop\s+(windefend|mpssvc)|"
                  r"advfirewall\s+set\s+\w+\s+state\s+off|wevtutil.*\scl\s|taskkill.*(msmpeng|mssense|greenrook)|disable" + "antispyware")
_R08 = re.compile(r"schtasks.*/create.*(\\temp\\|appdata|powershell|cmd\s*/c|mshta|wscript|https?:)|"
                  r"reg\s+add.*\\run.*(\\temp\\|appdata|powershell|mshta|https?:)|crontab.*(curl|wget|/tmp/)")
_R09 = re.compile(r"wmic.*process\s+call\s+create|psexec.*\\\\|winrs\s+-r:")
_R12 = re.compile(r"(content\.outlook|inetcache|\\temp\\|/tmp/|\\downloads\\|/downloads/|\\appdata\\local\\microsoft\\windows\\temporary internet files)"
                  r".*\.(vbs|vbe|js|jse|wsf|wsh|hta)\b")
SCRIPT_HOSTS = {"wscript.exe", "cscript.exe", "mshta.exe"}


def match_rules(name, parent, cmd):
    """Return [(rule_id, why)] for a process, from its name, parent name and lower-cased command line."""
    n, hits = name.lower(), []
    if parent in OFFICE and n in SHELLS:
        hits.append(("R01", f"{parent} launched {n}"))
    if n in PS_NAMES and (
            re.search(r"\s-(e|ec|enc|enco|encodedcommand)\s+[a-z0-9+/=]{20,}", cmd)
            or (("frombase64" + "string") in cmd and re.search(r"\biex\b|invoke-" + "expression", cmd))
            or (re.search(r"-w(indowstyle)?\s+hidden", cmd) and re.search(r"download" + r"string|download" + r"file|net\.web" + r"client|iwr|invoke-web" + r"request", cmd))):
        hits.append(("R02", "PowerShell started with an encoded, hidden or downloader command line"))
    if n == "mimi" + "katz.exe" or _R03.search(cmd):
        hits.append(("R03", "Command line matches credential dumping"))
    if _R04.search(cmd):
        hits.append(("R04", "Download-and-run technique in command line"))
    if _R05.search(cmd):
        hits.append(("R05", "Command deletes backups / disables recovery"))
    if _R06.search(cmd):
        hits.append(("R06", "Command disables or tampers with security tools"))
    if _R08.search(cmd):
        hits.append(("R08", "Command creates suspicious persistence"))
    if _R09.search(cmd):
        hits.append(("R09", "Remote process creation"))
    if n in SCRIPT_HOSTS and _R12.search(cmd):
        hits.append(("R12", f"{n} is running a script saved in an e-mail, browser or download folder"))
    return hits


def respond(cfg, bus, broker, rid, headline, details, key, allow_key, on_block):
    """Apply the user's mode for a rule: block / ask / audit / off. Returns what happened."""
    mode = rule_mode(cfg, rid)
    if mode == "off":
        return "off"
    if allow_key in (cfg.get("proc_allowed") or []):
        return "allowed"
    if mode == "audit":
        bus.emit("AUDIT", "Rook Rules", f"[{rid}] would have acted: {headline}")
        return "audit"
    if mode == "block":
        on_block()
        bus.emit("THREAT", "Rook Rules", f"[{rid}] blocked: {headline}")
        bus.notify("bad", f"Rule {rid} blocked an attack", headline)
        return "blocked"
    choice = broker.ask(key=key, title="Green Rook - Rook Rule " + rid, headline=headline, details=details,
                        options=[("block", "Block it", "danger"), ("once", "Allow once", "neutral"),
                                 ("always", "Always allow", "neutral")], default="block")
    if choice == "block":
        on_block()
        bus.emit("THREAT", "Rook Rules", f"[{rid}] blocked: {headline}")
        return "blocked"
    if choice == "always":
        cfg.append_unique("proc_allowed", allow_key)
    bus.emit("INFO", "Rook Rules", f"[{rid}] user allowed: {headline}")
    return "allowed"


CRITICAL_PROCS = {"system", "system idle process", "registry", "smss.exe", "csrss.exe", "wininit.exe", "services.exe", "lsass.exe",
                  "winlogon.exe", "svchost.exe", "init", "systemd", "launchd", "kernel_task", "dbus-daemon", "explorer.exe", "dwm.exe",
                  "msmpeng.exe"}


def is_critical(p) -> bool:
    """Killing these can blue-screen / log you out. Automatic actions must never do it."""
    try:
        return p.pid <= 4 or (p.name() or "").lower() in CRITICAL_PROCS
    except Exception:
        return True


def kill_tree(p):
    """Kill a process and its children - except operating-system-critical ones. Returns True if p itself was ended."""
    if is_critical(p):
        return False
    try:
        for c in p.children(recursive=True):
            try:
                if not is_critical(c):
                    c.kill()
            except Exception:
                pass
        p.kill()
        return True
    except Exception:
        return False


def user_writable(exe: str) -> bool:
    e = exe.lower()
    if IS_WIN:
        e = e.replace("/", "\\")
        return any(x in e for x in ("\\users\\", "\\programdata\\", "\\windows\\temp\\", "\\$recycle.bin\\"))
    return e.startswith(("/tmp/", "/var/tmp/", "/dev/shm/", "/home/", "/root/", "/mnt/", "/media/", "/run/media/", "/users/"))


def is_risky_dir(exe: str) -> bool:
    e = exe.lower().replace("\\", "/")
    return any(r.replace("\\", "/") in e for r in RISKY_DIRS)


# --------------------------------------------------------------------------- Process Guard
class ProcessGuard(Service):
    """Inspects every new process. Suspicious ones are *suspended first*, then judged, then resumed or killed."""
    interval = 0.6

    def __init__(self, cfg, engine, vault, broker, bus, enabled):
        super().__init__("ProcessGuard", enabled)
        self.cfg, self.engine, self.vault, self.broker, self.bus = cfg, engine, vault, broker, bus
        self.cache, self.known, self.me = {}, None, os.getpid()
        self._held = set()          # (pid, start-time) of processes WE suspended - only those may be resumed

    def reset(self):
        self.known = None

    def tick(self):
        if not psutil:
            return
        cur = {}
        for p in psutil.process_iter(["pid", "create_time"]):
            cur[p.pid] = p.info.get("create_time") or 0
        if self.known is None:
            self.known = cur
            return
        new = [pid for pid, ct in cur.items() if self.known.get(pid) != ct]
        self.known = cur
        for pid in new:
            threading.Thread(target=self.inspect, args=(pid,), daemon=True).start()

    def inspect(self, pid):
        try:
            p = psutil.Process(pid)
            info = p.as_dict(["name", "exe", "cmdline", "ppid"])
            name, exe = (info["name"] or "").lower(), info["exe"] or ""
            if pid == self.me or (info["ppid"] == self.me and name in OWN_HELPERS) or is_own_descendant(p, self.me):
                return                                      # Green Rook's own helpers (Tor, WireGuard, PowerShell, ...) are not threats
            if exe and self.engine.is_excluded(exe):
                return
            cmd = " ".join(info["cmdline"] or []).lower()
            try:
                parent = psutil.Process(info["ppid"]).name().lower()
            except Exception:
                parent = ""
            hits = match_rules(name, parent, cmd)
            on_usb = bool(exe) and any(exe.lower().startswith(m.lower()) for m in USB_MOUNTS)
            if on_usb:
                hits.append(("R10", f"Program started from a removable drive: {exe}"))
            res, hold = None, bool(hits)
            scan_it = bool(exe) and user_writable(exe) and os.path.isfile(exe)
            if scan_it:
                st = os.stat(exe)
                key = (exe, st.st_mtime_ns)
                res = self.cache.get(key)
                if res is None and st.st_size <= 60 * 1024 * 1024:
                    if is_risky_dir(exe):
                        hold = True
                    if hold:
                        self._suspend(p)
                    res = self.engine.scan_file(exe)
                    self.cache[key] = res
                    if len(self.cache) > 2000:
                        self.cache.clear()
                if res and res.verdict in (MALICIOUS, SUSPICIOUS):
                    hits.append(("R07", f"{res.verdict} program: " + (res.reasons[0] if res.reasons else exe)))
            elif hold:
                self._suspend(p)
            outcome = self.decide(p, info, name, exe, parent, hits, res)
            if outcome != "blocked":
                self._resume(p)
        except (psutil.NoSuchProcess, psutil.AccessDenied, OSError, ProcessLookupError):
            pass

    def _suspend(self, p):
        if is_critical(p):
            return
        try:
            if p.status() != psutil.STATUS_STOPPED:     # already stopped by someone else -> not ours to resume later
                p.suspend()
                self._held.add((p.pid, p.create_time()))
        except Exception:
            pass

    def _resume(self, p):
        """Resume only a process that Green Rook itself suspended (never one a user or another tool stopped)."""
        try:
            key = (p.pid, p.create_time())
            if key in self._held:
                self._held.discard(key)
                p.resume()
        except Exception:
            pass

    def decide(self, p, info, name, exe, parent, hits, res):
        active = [(rid, why) for rid, why in hits if rule_mode(self.cfg, rid) != "off"]
        if not active:
            return "none"
        active.sort(key=lambda h: 0 if rule_mode(self.cfg, h[0]) == "block" else 1)
        rid, why = active[0]
        for r2, w2 in active[1:]:
            if rule_mode(self.cfg, r2) == "audit":
                self.bus.emit("AUDIT", "Rook Rules", f"[{r2}] {name}: {w2}")

        def on_block():
            kill_tree(p)
            if res and res.auto_safe and self.cfg.get("auto_quarantine"):     # hard evidence only, never OS folders
                try:
                    self.vault.quarantine(res)
                except OSError:
                    pass

        details = [("Program", exe or name), ("PID", str(info["pid"] if "pid" in info else p.pid)),
                   ("Started by", parent or "unknown"), ("Why", why)]
        if cmd := " ".join(info["cmdline"] or [])[:220]:
            details.append(("Command", cmd))
        return respond(self.cfg, self.bus, self.broker, rid, f"{info['name']}: {why}", details,
                       key=f"proc:{p.pid}", allow_key=f"{rid}|{name}", on_block=on_block)


# --------------------------------------------------------------------------- Ransomware Shield
RANSOM_EXT = {".locked", ".encrypted", ".crypt", ".crypted", ".enc", ".locky", ".cerber", ".zepto", ".wncry", ".wnry",
              ".ryk", ".lockbit", ".conti", ".akira", ".blackcat", ".hive", ".royal", ".basta", ".rhysida",
              ".medusa", ".djvu", ".ransom", ".crypto", ".cry", ".pays", ".gotham", ".crab"}


def _decoy_bytes():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_STORED) as z:
        zi = zipfile.ZipInfo("word/document.xml", date_time=(2020, 1, 1, 0, 0, 0))
        z.writestr(zi, "<w:document>Decoy file placed by Green Rook to detect ransomware. Please do not edit or delete.</w:document>" * 20)
    return buf.getvalue()


DECOY = _decoy_bytes()
DECOY_SHA = hashlib.sha256(DECOY).hexdigest()


class RansomwareShield(Service):
    """Decoy files in your documents folders + detection of mass modification. Suspends the writer first."""
    interval = 1.5
    DECOY_NAME = "!GreenRook_decoy.docx" if IS_WIN else ".!GreenRook_decoy.docx"

    def __init__(self, cfg, engine, vault, broker, bus, enabled):
        super().__init__("RansomwareShield", enabled)
        self.cfg, self.engine, self.vault, self.broker, self.bus = cfg, engine, vault, broker, bus
        self.reset()

    def reset(self):
        self.snap, self.baselined, self.window, self.cool = {}, False, deque(), 0.0
        self.content_snap = {}
        self.decoys = set()

    def dirs(self):
        return [d for d in (self.cfg.get("protected_dirs") or []) if os.path.isdir(d)]

    def place_decoys(self, dirs):
        for d in dirs:
            path = os.path.join(d, self.DECOY_NAME)
            try:
                if os.path.exists(path):
                    if path not in self.decoys and hashlib.sha256(Path(path).read_bytes()).hexdigest() != DECOY_SHA:
                        self._unhide(path)
                        Path(path).write_bytes(DECOY)
                elif path not in self.decoys:
                    Path(path).write_bytes(DECOY)
                else:
                    continue
                self.decoys.add(path)
                if IS_WIN:
                    import ctypes
                    ctypes.windll.kernel32.SetFileAttributesW(path, 0x2 | 0x4)
            except OSError:
                pass

    @staticmethod
    def _unhide(path):
        if IS_WIN:
            try:
                import ctypes
                ctypes.windll.kernel32.SetFileAttributesW(path, 0x80)
            except Exception:
                pass

    def tick(self):
        dirs = self.dirs()
        self.place_decoys(dirs)
        for path in list(self.decoys):
            try:
                ok = hashlib.sha256(Path(path).read_bytes()).hexdigest() == DECOY_SHA
            except OSError:
                ok = False
            if not ok:
                self.trigger(f"A hidden decoy file was changed or deleted: {path}", True, path)
                return
        cur = {}
        for d in dirs:
            for p, sig in walk_limited(d, depth=2, cap=15000):
                if os.path.basename(p) != self.DECOY_NAME:
                    cur[p] = sig
        verdict = self.judge(cur)
        if verdict:
            self.trigger(verdict[0], verdict[1], None)

    # Documents that are stored uncompressed. If one of these suddenly turns into random-looking bytes, it was encrypted.
    PLAIN_EXTS = {".txt", ".csv", ".doc", ".xls", ".ppt", ".rtf", ".md", ".html", ".htm", ".xml", ".json", ".log", ".sql", ".py",
                  ".c", ".cpp", ".h", ".java", ".js", ".ini", ".cfg", ".tex", ".odt", ".bmp", ".wav"}

    @staticmethod
    def looks_encrypted(path):
        try:
            with open(path, "rb") as f:
                blk = f.read(4096)
            return len(blk) >= 1024 and entropy(blk) > 7.6
        except OSError:
            return False

    @classmethod
    def _content_fingerprints(cls, cur):
        """Small local samples catch fast same-size rewrites even on filesystems with coarse timestamps.
        Limit the extra reads to 2,000 plain-document files per pass; normal metadata watching still covers all files."""
        out = {}
        for p in cur:
            if len(out) >= 2000:
                break
            if os.path.splitext(p)[1].lower() not in cls.PLAIN_EXTS:
                continue
            try:
                with open(p, "rb") as f:
                    out[p] = hashlib.sha256(f.read(1024)).digest()
            except OSError:
                continue
        return out

    def judge(self, cur):
        """Compare folder metadata and small document fingerprints. Returns (reason, high_confidence) or None.
        The content sample catches rapid same-size rewrites when a filesystem does not update timestamps immediately."""
        content = self._content_fingerprints(cur)
        if not self.baselined:
            self.snap, self.content_snap, self.baselined = cur, content, True
            return None
        mod = new = ext = enc = checked = 0
        for p, sig in cur.items():
            old = self.snap.get(p)
            low = os.path.splitext(p)[1].lower()
            if old is None:
                new += 1
                if low in RANSOM_EXT:
                    ext += 1
            elif old != sig or (p in content and self.content_snap.get(p) != content[p]):
                mod += 1
                if low in self.PLAIN_EXTS and checked < 40:
                    checked += 1
                    if self.looks_encrypted(p):
                        enc += 1
        gone = sum(1 for p in self.snap if p not in cur)
        self.snap, self.content_snap = cur, content
        now = time.time()
        self.window.append((now, mod + gone, new, ext, enc))
        while self.window and now - self.window[0][0] > 10:
            self.window.popleft()
        m = sum(w[1] for w in self.window)
        n = sum(w[2] for w in self.window)
        e = sum(w[3] for w in self.window)
        x = sum(w[4] for w in self.window)
        if e >= 3:
            return f"{e} files with ransomware-style extensions appeared in protected folders", True
        if x >= 5:
            return f"{x} documents were just overwritten with random-looking (encrypted) data", True
        if m >= 30 or (m >= 15 and n >= 15):
            return f"{m} files modified or deleted (and {n} created) within 10 seconds", False
        return None

    def culprits(self):
        def sample():
            out = {}
            for p in psutil.process_iter(["pid", "name", "exe", "io_counters"]):
                io = p.info.get("io_counters")
                if io:
                    out[p.pid] = (p, io.write_bytes)
            return out
        a = sample()
        time.sleep(1.0)
        b = sample()
        allowed = self.cfg.get("proc_allowed") or []
        ranked = []
        for pid, (p, w2) in b.items():
            if pid in a and pid != os.getpid():
                d = w2 - a[pid][1]
                exe = (p.info.get("exe") or "").lower()
                nm = (p.info.get("name") or "").lower()
                if d > 128 * 1024 and f"RW|{nm}" not in allowed and not (IS_WIN and exe.startswith(os.environ.get("SystemRoot", "C:\\windows").lower())):
                    ranked.append((d, p))
        ranked.sort(key=lambda x: -x[0])
        return [p for _, p in ranked[:3]]

    def trigger(self, reason, high, decoy):
        now = time.time()
        if now < self.cool or not psutil:
            return
        self.cool = now + 60
        self.bus.emit("THREAT", "Ransomware Shield", reason)
        suspects = self.culprits()
        for p in suspects:
            try:
                p.suspend()
            except Exception:
                pass
        names = ", ".join(f"{p.info.get('name')} (PID {p.pid})" for p in suspects) or "none identified"
        if decoy:
            self.decoys.discard(decoy)
            try:
                self._unhide(decoy)
                os.remove(decoy)
            except OSError:
                pass
        if not suspects:
            self.bus.notify("bad", "Ransomware Shield", reason + "\nNo single program could be identified.")
            return
        choice = self.broker.ask(
            key="ransomware", title="Green Rook - Ransomware Shield", headline="Possible ransomware activity",
            details=[("What happened", reason), ("Suspected programs", names), ("Status", "Suspended until you decide")],
            options=[("block", "Stop & remove", "danger"), ("once", "It's safe", "neutral")], default="block",
            on_timeout="block")       # the one place where "no answer" still stops the program: every second costs files
        for p in suspects:
            if choice == "block":
                exe = p.info.get("exe") or ""
                kill_tree(p)
                if exe and os.path.isfile(exe) and user_writable(exe) and not system_protected(exe):
                    r = self.engine.scan_file(exe)
                    if r.verdict in (MALICIOUS, SUSPICIOUS):      # the user just chose "Stop & remove" for this program
                        try:
                            self.vault.quarantine(r)
                        except OSError:
                            pass
            else:
                self.cfg.append_unique("proc_allowed", f"RW|{(p.info.get('name') or '').lower()}")
                try:
                    p.resume()
                except Exception:
                    pass
        self.bus.emit("THREAT" if choice == "block" else "INFO", "Ransomware Shield",
                      "Stopped: " + names if choice == "block" else "User marked activity as safe: " + names)

    def remove_decoys(self):
        for path in list(self.decoys):
            try:
                self._unhide(path)
                os.remove(path)
            except OSError:
                pass
        self.decoys.clear()


# --------------------------------------------------------------------------- Persistence Guard
def extract_exe(value: str) -> str:
    v = os.path.expandvars(value.strip())
    m = re.match(r'"([^"]+)"', v)
    if m:
        return m.group(1)
    m = re.match(r"([^\s]+(?:\s[^\s/-]+)*?\.(?:exe|bat|cmd|ps1|vbs|js|scr|com|lnk|jar|sh|py))", v, re.I)
    return m.group(1) if m else (v.split()[0] if v.split() else "")


class PersistenceGuard(Service):
    interval = 4.0

    def __init__(self, cfg, engine, vault, broker, bus, enabled):
        super().__init__("PersistenceGuard", enabled)
        self.cfg, self.engine, self.vault, self.broker, self.bus = cfg, engine, vault, broker, bus
        self.reset()

    def reset(self):
        self.base, self.n = None, 0

    # -- collectors
    def collect(self):
        out = {}
        if IS_WIN:
            try:
                import winreg
                for hive, hn in ((winreg.HKEY_CURRENT_USER, "HKCU"), (winreg.HKEY_LOCAL_MACHINE, "HKLM")):
                    for sub in (r"Software\Microsoft\Windows\CurrentVersion\Run", r"Software\Microsoft\Windows\CurrentVersion\RunOnce",
                                r"Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run"):
                        try:
                            k = winreg.OpenKey(hive, sub)
                        except OSError:
                            continue
                        i = 0
                        while True:
                            try:
                                nm, val, _ = winreg.EnumValue(k, i)
                            except OSError:
                                break
                            i += 1
                            out[f"reg|{hn}|{sub}|{nm}"] = str(val)
            except ImportError:
                pass
            for env, rel in (("APPDATA", r"Microsoft\Windows\Start Menu\Programs\Startup"),
                             ("PROGRAMDATA", r"Microsoft\Windows\Start Menu\Programs\StartUp")):
                base = os.environ.get(env)
                if base:
                    self._folder(out, Path(base) / rel, "*")
            if self.n % 5 == 0:
                self._tasks(out)
            elif self.base:
                out.update({k: v for k, v in self.base.items() if k.startswith("task|")})
        else:
            home = Path.home()
            self._folder(out, home / ".config/autostart", "*.desktop")
            self._folder(out, home / ".config/systemd/user", "*.service")
            self._folder(out, home / "Library" / ("Launch" + "Agents"), "*.plist")
            if self.n % 3 == 0 and not IS_MAC:
                try:
                    r = subprocess.run(["crontab", "-l"], capture_output=True, text=True, timeout=5)
                    for ln in r.stdout.splitlines():
                        if ln.strip() and not ln.startswith("#"):
                            out["cron|" + ln.strip()] = ln.strip()
                except Exception:
                    pass
            elif self.base:
                out.update({k: v for k, v in self.base.items() if k.startswith("cron|")})
        return out

    @staticmethod
    def _folder(out, folder, pattern):
        try:
            for f in folder.glob(pattern):
                if f.is_file() and f.name.lower() != "desktop.ini":
                    val = str(f)
                    if f.suffix == ".desktop":
                        for ln in f.read_text("utf-8", "ignore").splitlines():
                            if ln.startswith("Exec="):
                                val = ln[5:]
                    elif f.suffix == ".service":
                        for ln in f.read_text("utf-8", "ignore").splitlines():
                            if ln.startswith("ExecStart="):
                                val = ln[10:]
                    out[f"file|{f}"] = val
        except OSError:
            pass

    def _tasks(self, out):
        try:
            r = subprocess.run(["schtasks", "/query", "/fo", "csv", "/v", "/nh"], capture_output=True, text=True,
                               timeout=25, creationflags=0x08000000)
            for row in csv.reader(io.StringIO(r.stdout)):
                if len(row) > 8 and row[1] and not row[1].lower().startswith("\\microsoft\\"):
                    out[f"task|{row[1]}"] = row[8]
        except Exception:
            pass

    def tick(self):
        cur = self.collect()
        self.n += 1
        if self.base is None:
            self.base = cur
            return
        for key, val in cur.items():
            if self.base.get(key) != val:
                self.base[key] = val
                threading.Thread(target=self.handle, args=(key, val), daemon=True).start()
        for k in list(self.base):
            if k not in cur:
                del self.base[k]

    def handle(self, key, val):
        label = key.split("|")[-1] if key.startswith(("reg", "task")) else os.path.basename(key.split("|", 1)[1])
        exe = extract_exe(val)
        res = self.engine.scan_file(exe) if exe and os.path.isfile(exe) else None
        reasons = []
        if res and res.verdict in (MALICIOUS, SUSPICIOUS):
            reasons.append(f"Target is {res.verdict.lower()}: " + (res.reasons[0] if res.reasons else exe))
        if exe and is_risky_dir(exe):
            reasons.append("Runs from a Temp / Downloads folder")
        if _R08.search(val.lower()) or re.search(r"powershell|mshta|wscript|cscript|https?://", val.lower()):
            reasons.append("Startup command uses a script host or a web address")
        self.bus.emit("INFO", "Persistence Guard", f"New startup entry: {label} -> {val[:120]}")
        if not reasons:
            self.bus.notify("warn", "New startup entry", f"{label}\n{val[:90]}")
            return

        def remove():
            self.remove(key, val, res)

        respond(self.cfg, self.bus, self.broker, "R08", f"New startup entry '{label}' looks suspicious",
                [("Entry", label), ("Runs", val[:200]), ("Why", "\n".join(reasons))],
                key="persist:" + key, allow_key="R08|" + key, on_block=remove)

    def remove(self, key, val, res):
        kind, rest = key.split("|", 1)
        try:
            if kind == "reg" and IS_WIN:
                import winreg
                hn, sub, nm = rest.split("|", 2)
                hive = winreg.HKEY_CURRENT_USER if hn == "HKCU" else winreg.HKEY_LOCAL_MACHINE
                k = winreg.OpenKey(hive, sub, 0, winreg.KEY_SET_VALUE)
                winreg.DeleteValue(k, nm)
            elif kind == "file":
                os.remove(rest)
            elif kind == "task":
                subprocess.run(["schtasks", "/delete", "/tn", rest, "/f"], capture_output=True, timeout=20, creationflags=0x08000000)
            self.bus.emit("THREAT", "Persistence Guard", f"Removed startup entry {rest}")
        except Exception as e:
            self.bus.emit("ERROR", "Persistence Guard", f"Could not remove {rest}: {e}")
        if res and res.auto_safe and self.cfg.get("auto_quarantine"):
            try:
                self.vault.quarantine(res)
            except OSError:
                pass


# --------------------------------------------------------------------------- USB Guard
def removable_mounts():
    out = []
    if not psutil:
        return out
    try:
        for d in psutil.disk_partitions(all=False):
            if IS_WIN:
                if "removable" in d.opts.lower():
                    out.append(d.mountpoint)
            elif d.mountpoint.startswith(("/media/", "/run/media/", "/mnt/", "/Volumes/")) and d.mountpoint != "/Volumes/Macintosh HD":
                out.append(d.mountpoint)
    except Exception:
        pass
    return out


class USBGuard(Service):
    interval = 3.0

    def __init__(self, cfg, engine, vault, broker, bus, enabled):
        super().__init__("USBGuard", enabled)
        self.cfg, self.engine, self.vault, self.broker, self.bus = cfg, engine, vault, broker, bus
        self.known = None

    def reset(self):
        self.known = None

    def tick(self):
        cur = removable_mounts()
        USB_MOUNTS[:] = cur
        if self.known is None:
            self.known = set(cur)
            return
        for mp in cur:
            if mp not in self.known:
                self.known.add(mp)
                threading.Thread(target=self.scan_drive, args=(mp,), daemon=True).start()
        self.known &= set(cur) | set()

    def scan_drive(self, mp):
        self.bus.emit("INFO", "USB Guard", f"Drive connected: {mp} - scanning")
        self.bus.notify("warn", "USB drive connected", f"Scanning {mp} before you open anything\u2026")
        cancel, mal, sus, n = threading.Event(), [], [], 0
        for p in iter_files(self.engine, [mp], False, cancel, limit=10000):
            r = self.engine.scan_file(p)
            n += 1
            if r.auto_safe:
                mal.append(r)
            elif r.verdict in (MALICIOUS, SUSPICIOUS):
                sus.append(r)
        done = 0
        for r in mal:
            try:
                self.vault.quarantine(r)
                done += 1
            except OSError:
                pass
        if sus:
            lines = "\n".join(os.path.relpath(r.path, mp) for r in sus[:6]) + (f"\n\u2026and {len(sus) - 6} more" if len(sus) > 6 else "")
            if self.broker.ask(key="usb:" + mp, title="Green Rook - USB drive", headline=f"{len(sus)} suspicious file(s) on {mp}",
                               details=[("Drive", mp), ("Files", lines)],
                               options=[("block", "Quarantine all", "danger"), ("once", "Leave them", "neutral")], default="block") == "block":
                for r in sus:
                    try:
                        self.vault.quarantine(r)
                        done += 1
                    except OSError:
                        pass
        level = "bad" if (mal or sus) else "good"
        self.bus.notify(level, "USB scan finished", f"{n} files checked, {len(mal) + len(sus)} threat(s), {done} quarantined.")
        self.bus.emit("THREAT" if mal or sus else "INFO", "USB Guard", f"{mp}: {n} files, {len(mal)} malicious, {len(sus)} suspicious")


# --------------------------------------------------------------------------- Network Guard
_PRIVATE = re.compile(r"^(127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|169\.254\.|::1$|fe80|fc|fd|0\.0\.0\.0)", re.I)
C2_PORTS = {4444, 4445, 1337, 31337, 5555}
WORM_PORTS = {445, 139, 135, 1433, 3389, 23}      # SMB, NetBIOS, RPC, SQL Server, RDP, telnet - the usual worm targets
WORM_WINDOW, WORM_FANOUT = 30.0, 20               # >= 20 different computers within 30 seconds


class FanoutTracker:
    """Counts how many distinct computers each process contacts on worm-favoured ports. Pure logic, easy to test."""

    def __init__(self, window=WORM_WINDOW, limit=WORM_FANOUT):
        self.window, self.limit, self.seen = window, limit, {}

    def add(self, pid, ip, port, now=None):
        """Record one connection. Returns the number of distinct targets if it just crossed the limit, else 0."""
        if port not in WORM_PORTS or ip.startswith("127.") or ip in ("::1", "0.0.0.0"):
            return 0
        now = time.time() if now is None else now
        d = self.seen.setdefault(pid, {})
        d[ip] = now
        for k in [k for k, t in d.items() if now - t > self.window]:
            del d[k]
        if len(d) >= self.limit:
            n = len(d)
            d.clear()                       # report once per burst
            return n
        if len(self.seen) > 2000:
            self.seen.clear()
        return 0
SHELL_NAMES = {"bash", "sh", "zsh", "dash", "cmd.exe", "powershell.exe", "pwsh.exe", "nc", "ncat", "netcat", "nc.exe", "ncat.exe"}


class NetworkGuard(Service):
    interval = 4.0

    def __init__(self, cfg, engine, vault, broker, bus, web, enabled):
        super().__init__("NetworkGuard", enabled)
        self.cfg, self.engine, self.vault, self.broker, self.bus, self.web = cfg, engine, vault, broker, bus, web
        self.seen = set()
        self.fan = FanoutTracker()

    def reset(self):
        self.seen.clear()

    def check_worm(self, c):
        """Called for every connection (including ones to your own network - worms spread sideways)."""
        if not c.raddr or not c.pid or c.pid == os.getpid() or c.status not in ("ESTABLISHED", "SYN_SENT"):
            return
        n = self.fan.add(c.pid, c.raddr.ip, c.raddr.port)
        if not n:
            return
        try:
            p = psutil.Process(c.pid)
            name, exe = (p.name() or "").lower(), p.exe() or ""
        except Exception:
            return
        if exe and self.engine.is_excluded(exe):
            return
        why = f"{name} contacted {n} different computers on file-sharing / remote-access ports within {int(WORM_WINDOW)} s (worm-style scanning)"
        respond(self.cfg, self.bus, self.broker, "R13", why,
                [("Program", exe or name), ("PID", str(c.pid)), ("Last target", f"{c.raddr.ip}:{c.raddr.port}")],
                key=f"worm:{c.pid}", allow_key=f"R13|{name}", on_block=lambda p=p: kill_tree(p))

    def tick(self):
        if not psutil:
            return
        try:
            conns = psutil.net_connections(kind="inet")
        except Exception:
            return
        for c in conns:
            try:
                self.check_worm(c)
            except Exception:
                pass
            if c.status != "ESTABLISHED" or not c.raddr or not c.pid or _PRIVATE.match(c.raddr.ip):
                continue
            key = (c.pid, c.raddr.ip, c.raddr.port)
            if key in self.seen:
                continue
            self.seen.add(key)
            if len(self.seen) > 5000:
                self.seen.clear()
            try:
                p = psutil.Process(c.pid)
                name, exe = (p.name() or "").lower(), p.exe() or ""
            except Exception:
                continue
            if c.pid == os.getpid() or (exe and self.engine.is_excluded(exe)):
                continue
            why = None
            if c.raddr.ip in self.web.blocklist:
                why = f"{name} is connected to blocklisted host {c.raddr.ip}"
            elif name in SHELL_NAMES:
                why = f"{name} has an outbound connection to {c.raddr.ip}:{c.raddr.port} (reverse-shell behaviour)"
            elif exe and user_writable(exe) and c.raddr.port in C2_PORTS:
                why = f"{name} from a user folder is connected to {c.raddr.ip}:{c.raddr.port}, a port used by remote-access tools"
            if why:
                respond(self.cfg, self.bus, self.broker, "R11", why,
                        [("Program", exe or name), ("PID", str(c.pid)), ("Remote", f"{c.raddr.ip}:{c.raddr.port}")],
                        key=f"net:{c.pid}", allow_key=f"R11|{name}", on_block=lambda p=p: kill_tree(p))


# --------------------------------------------------------------------------- Tamper protection
MANIFEST = APP_DIR / "MANIFEST.sha256"
PID_FILE_NAMES = ("main.pid", "watchdog.pid", "clean_exit.flag")


def compute_manifest(names=None):
    names = names or sorted(p.name for p in APP_DIR.glob("*.py")) + (["OWNFILES.sha256"] if (APP_DIR / "OWNFILES.sha256").exists() else [])
    return "\n".join(f"{hashlib.sha256((APP_DIR / n).read_bytes()).hexdigest()}  {n}" for n in names) + "\n"


def verify_manifest():
    """None = no manifest (development / packaged build). Otherwise list of files that no longer match."""
    if getattr(sys, "frozen", False) or not MANIFEST.exists():
        return None
    bad = []
    for ln in MANIFEST.read_text("utf-8").splitlines():
        if "  " not in ln:
            continue
        h, n = ln.split("  ", 1)
        try:
            if hashlib.sha256((APP_DIR / n).read_bytes()).hexdigest() != h:
                bad.append(n)
        except OSError:
            bad.append(n)
    return bad


def hash_pin(pin: str, salt=None) -> str:
    salt = salt or secrets.token_bytes(16)
    return salt.hex() + "$" + hashlib.pbkdf2_hmac("sha256", pin.encode(), salt, 200_000).hex()


def check_pin(stored: str, pin: str) -> bool:
    try:
        salt, _ = stored.split("$")
        return hmac.compare_digest(stored, hash_pin(pin, bytes.fromhex(salt)))
    except Exception:
        return False


def self_cmd(*extra):
    if getattr(sys, "frozen", False):
        return [sys.executable, *extra]
    exe = sys.executable
    if IS_WIN and exe.lower().endswith("python.exe"):
        w = exe[:-10] + "pythonw.exe"
        if os.path.exists(w):
            exe = w
    return [exe, str(APP_DIR / "greenrook.py"), *extra]


def spawn(*args):
    kw = {}
    if IS_WIN:
        kw["creationflags"] = 0x00000008 | 0x08000000 | 0x00000200
    else:
        kw["start_new_session"] = True
    return subprocess.Popen(self_cmd(*args), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL, close_fds=True, **kw)


def _read_pid(name):
    try:
        return int((data_dir() / name).read_text().strip())
    except Exception:
        return 0


def _alive_with(pid, marker=None):
    if not pid or not psutil or not psutil.pid_exists(pid):
        return False
    if marker:
        try:
            return marker.lower() in " ".join(psutil.Process(pid).cmdline()).lower()
        except Exception:
            return False
    return True


def main_running() -> bool:
    """Is a genuine Green Rook instance alive? (A recycled PID or a stranger holding our port does not count.)"""
    return _alive_with(_read_pid("main.pid"), "greenrook")


def ensure_watchdog():
    if "--no-watchdog" in sys.argv:
        return
    if psutil and not _alive_with(_read_pid("watchdog.pid"), "--watchdog"):
        try:
            spawn("--watchdog")
        except Exception:
            pass


def run_watchdog():
    """Second process: if Green Rook is killed (and wasn't quit properly) it is started again."""
    d = data_dir()
    (d / "watchdog.pid").write_text(str(os.getpid()))
    restarts = deque()
    while True:
        time.sleep(2)
        if (d / "clean_exit.flag").exists():
            break
        if (d / "watchdog.pid").exists() and _read_pid("watchdog.pid") != os.getpid():
            break  # another watchdog took over
        mp = _read_pid("main.pid")
        if not mp or _alive_with(mp, "greenrook"):
            continue
        now = time.time()
        while restarts and now - restarts[0] > 600:
            restarts.popleft()
        if len(restarts) >= 5:
            time.sleep(30)
            continue
        restarts.append(now)
        try:
            with open(d / "events.log", "a", encoding="utf-8") as f:
                f.write(time.strftime("%Y-%m-%d %H:%M:%S") + " [THREAT] Watchdog: Green Rook was stopped unexpectedly - restarting it\n")
            spawn("--restarted")
        except Exception:
            pass
        time.sleep(6)


class TamperGuard(Service):
    interval = 15.0

    def __init__(self, cfg, bus, enabled):
        super().__init__("TamperGuard", enabled)
        self.cfg, self.bus = cfg, bus
        self.last_bad = None
        self.integrity = "unknown"

    def tick(self):
        if not self.cfg.get("tamper_protection"):
            return
        bad = verify_manifest()
        if bad is None:
            self.integrity = "not available in this build"
        elif bad:
            self.integrity = "MODIFIED: " + ", ".join(bad)
            if bad != self.last_bad:
                self.bus.emit("THREAT", "Tamper Guard", "Program files were changed: " + ", ".join(bad))
                self.bus.notify("bad", "Green Rook files were modified", "Reinstall from the original download:\n" + ", ".join(bad))
        else:
            self.integrity = "all files verified"
        self.last_bad = bad
        if not self.cfg.verify_disk():
            self.bus.emit("THREAT", "Tamper Guard", "Settings file was modified from outside - restored from memory")
            self.bus.notify("bad", "Settings tampering blocked", "Something edited Green Rook's settings file. It was restored.")
        ensure_watchdog()
