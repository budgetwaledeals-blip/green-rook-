#!/usr/bin/env python3
"""
Green Rook setup - installs Green Rook as a normal app (or removes it).

    Windows: double-click Install.bat        Linux/macOS: python3 gr_setup.py
    python gr_setup.py                 install  (Windows: Desktop + Start Menu icons, "Apps & features" entry; Linux: menu entry)
    python gr_setup.py --uninstall     remove it (asks for your Green Rook PIN if you set one)

Options:  --yes  (no questions)   --no-autostart   --no-launch   --target FOLDER   --remove-data (uninstall: also delete quarantine/settings)
Nothing here needs administrator rights: everything goes under your own user profile.
"""
import argparse
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

SRC = Path(__file__).resolve().parent
sys.path.insert(0, str(SRC))
IS_WIN = sys.platform == "win32"
IS_LINUX = sys.platform.startswith("linux")
NAME = "Green Rook"
UNINSTALL_KEY = r"Software\Microsoft\Windows\CurrentVersion\Uninstall\GreenRook"
RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
FILES = ["*.py", "greenrook.png", "greenrook.ico", "requirements.txt", "MANIFEST.sha256", "OWNFILES.sha256", "README.md", "CHANGELOG.md", "LICENSE*"]
FOLDERS = ["samples", "tools", "icons"]
NO_WINDOW = 0x08000000


def version():
    try:
        import gr_core
        return gr_core.VERSION
    except Exception:
        return "3.1.4"


def default_target() -> Path:
    if IS_WIN:
        return Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local"))) / "Programs" / "GreenRook"
    return Path.home() / ".local" / "share" / "greenrook-app"


def step(n, total, text):
    print(f"\n[{n}/{total}] {text}")


# ------------------------------------------------------------------ copying
def is_installed_dir(target: Path) -> bool:
    """True only for a real installation (has its private environment). Protects an unzipped download from being deleted."""
    return (target / "venv").is_dir() and (target / "greenrook.py").is_file()


def copy_program(target: Path):
    target.mkdir(parents=True, exist_ok=True)
    if target.resolve() == SRC:
        return [f.name for f in SRC.glob("*.py")]          # already in place
    copied = []
    for pattern in FILES:
        for f in SRC.glob(pattern):
            if f.is_file():
                shutil.copy2(f, target / f.name)
                copied.append(f.name)
    for d in FOLDERS:
        if (SRC / d).is_dir():
            shutil.copytree(SRC / d, target / d, dirs_exist_ok=True, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    return copied


def venv_python(target: Path, console=False) -> Path:
    if IS_WIN:
        return target / "venv" / "Scripts" / ("python.exe" if console else "pythonw.exe")
    return target / "venv" / "bin" / "python"


ADDONS = [("psutil", "psutil>=5.9", "program, network and ransomware watching"),
          ("cryptography", "cryptography>=41", "stronger AES-GCM encryption for quarantine")]


def install_addons(py: Path):
    """Install optional add-ons one at a time using ready-made wheels. Green Rook still opens if one fails."""
    print(f"      Python in use: {sys.version.split()[0]} ({'64' if sys.maxsize > 2**32 else '32'}-bit)")
    subprocess.run([str(py), "-m", "pip", "install", "--quiet", "--disable-pip-version-check", "--upgrade", "pip"],
                   capture_output=True, text=True, timeout=300)
    missing = []
    for module, spec, purpose in ADDONS:
        if subprocess.run([str(py), "-c", f"import {module}"], capture_output=True).returncode == 0:
            continue
        r = subprocess.run([str(py), "-m", "pip", "install", "--disable-pip-version-check", "--prefer-binary",
                            "--only-binary", ":all:", spec], capture_output=True, text=True, timeout=600)
        if r.returncode == 0:
            print(f"      Installed {module}.")
            continue
        missing.append((module, purpose))
        lines = [ln for ln in (r.stderr or r.stdout or "").splitlines() if ln.strip()]
        print(f"      Could not install {module}. pip said: {lines[-1] if lines else 'no details'}")
    if missing:
        print("\n      Green Rook will still install and open. These extras are turned off for now:")
        for module, purpose in missing:
            print(f"        - {module}: {purpose}")
        print("      Common causes: no internet, a proxy/firewall blocking pypi.org, or a very new or 32-bit Python")
        print("      with no ready-made add-on yet. Python 3.12 or 3.13 (64-bit) from python.org works best.")
        print("      Run Install.bat again later to add them.\n")
    return [m for m, _ in missing]


def make_environment(target: Path):
    """Private Python environment so Green Rook never touches (or breaks) your other Python programs."""
    py = venv_python(target, console=True)
    if not py.exists():
        subprocess.run([sys.executable, "-m", "venv", str(target / "venv")], check=True)
    install_addons(py)
    t = subprocess.run([str(py), "-c", "import tkinter; r = tkinter.Tk(); r.withdraw(); r.update_idletasks(); r.destroy()"],
                       capture_output=True, text=True, timeout=60)
    if t.returncode != 0:
        detail = (t.stderr or t.stdout or "").strip().splitlines()[-1:] or ["no details"]
        print("      Window toolkit check failed: " + detail[0])
        raise RuntimeError("This Python was installed without Tk (the window toolkit). Re-run the Python installer, choose 'Modify', and tick "
                           "'tcl/tk and IDLE'. On Linux: sudo apt install python3-tk")


# ------------------------------------------------------------------ Windows shortcuts / registry
def lnk_run_as_admin(path: Path):
    """Mark a .lnk file 'Run as administrator' (LinkFlags bit RunAsUser, byte 0x15 bit 0x20)."""
    data = bytearray(Path(path).read_bytes())
    if len(data) < 0x4C or data[:4] != b"\x4c\x00\x00\x00":
        raise ValueError("not a Windows shortcut file")
    data[0x15] |= 0x20
    Path(path).write_bytes(bytes(data))


def make_lnk(lnk: Path, target: Path, args: str, workdir: Path, icon: Path, desc: str):
    lnk.parent.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, GR_LNK=str(lnk), GR_TARGET=str(target), GR_ARGS=args, GR_WD=str(workdir), GR_ICON=str(icon), GR_DESC=desc)
    ps = ("$s=(New-Object -ComObject WScript.Shell).CreateShortcut($env:GR_LNK);$s.TargetPath=$env:GR_TARGET;$s.Arguments=$env:GR_ARGS;"
          "$s.WorkingDirectory=$env:GR_WD;$s.IconLocation=$env:GR_ICON;$s.Description=$env:GR_DESC;$s.Save()")
    subprocess.run(["powershell", "-NoProfile", "-Command", ps], env=env, check=True,
                   capture_output=True, creationflags=NO_WINDOW)


def windows_desktop() -> Path:
    try:
        out = subprocess.check_output(["powershell", "-NoProfile", "-Command", "[Environment]::GetFolderPath('Desktop')"],
                                      text=True, creationflags=NO_WINDOW).strip()
        if out:
            return Path(out)
    except Exception:
        pass
    return Path.home() / "Desktop"


def start_menu_dir() -> Path:
    return Path(os.environ.get("APPDATA", str(Path.home()))) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Green Rook"


def windows_shortcuts(target: Path):
    pyw, py = venv_python(target), venv_python(target, console=True)
    app, icon = str(target / "greenrook.py"), target / "greenrook.ico"
    made = []
    menu = start_menu_dir()
    for folder in (windows_desktop(), menu):
        make_lnk(folder / "Green Rook.lnk", pyw, f'"{app}"', target, icon, "Green Rook antivirus")
        made.append(folder / "Green Rook.lnk")
    admin = menu / "Green Rook (Administrator).lnk"
    make_lnk(admin, pyw, f'"{app}" --admin-shortcut', target, icon, "Green Rook with administrator rights (can delete protected files)")
    lnk_run_as_admin(admin)
    made.append(admin)
    un = menu / "Uninstall Green Rook.lnk"
    make_lnk(un, py, f'"{target / "gr_setup.py"}" --uninstall', target, icon, "Remove Green Rook")
    made.append(un)
    return made


def windows_register(target: Path, autostart: bool):
    import winreg
    py, pyw = venv_python(target, console=True), venv_python(target)
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, UNINSTALL_KEY) as k:
        for name, val in (("DisplayName", NAME), ("DisplayVersion", version()), ("Publisher", "Green Rook"),
                          ("InstallLocation", str(target)), ("DisplayIcon", str(target / "greenrook.ico")),
                          ("UninstallString", f'"{py}" "{target / "gr_setup.py"}" --uninstall')):
            winreg.SetValueEx(k, name, 0, winreg.REG_SZ, val)
        winreg.SetValueEx(k, "NoModify", 0, winreg.REG_DWORD, 1)
        winreg.SetValueEx(k, "NoRepair", 0, winreg.REG_DWORD, 1)
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as k:
        if autostart:
            winreg.SetValueEx(k, "GreenRook", 0, winreg.REG_SZ, f'"{pyw}" "{target / "greenrook.py"}"')
        else:
            try:
                winreg.DeleteValue(k, "GreenRook")
            except OSError:
                pass


def windows_unregister():
    import winreg
    try:
        winreg.DeleteKey(winreg.HKEY_CURRENT_USER, UNINSTALL_KEY)
    except OSError:
        pass
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as k:
            winreg.DeleteValue(k, "GreenRook")
    except OSError:
        pass


# ------------------------------------------------------------------ Linux menu entry
def desktop_entry(target: Path) -> str:
    return ("[Desktop Entry]\nType=Application\nName=Green Rook\nComment=Antivirus\n"
            f"Exec=\"{venv_python(target)}\" \"{target / 'greenrook.py'}\"\nIcon={target / 'greenrook.png'}\n"
            "Terminal=false\nCategories=System;Security;\n")


def linux_menu_dir() -> Path:
    return Path(os.environ.get("XDG_DATA_HOME", str(Path.home() / ".local" / "share"))) / "applications"


# ------------------------------------------------------------------ stopping a running copy
def stop_running():
    """Ask Green Rook to exit cleanly (so its watchdog does not restart it), then end any leftover processes."""
    try:
        import gr_core
        d = gr_core.data_dir()
        d.mkdir(parents=True, exist_ok=True)
        (d / "clean_exit.flag").write_text("1")
    except Exception:
        pass
    time.sleep(1.5)
    try:
        if IS_WIN:
            ps = ("Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'greenrook\\.py' -and $_.CommandLine -notmatch 'gr_setup' }"
                  " | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }")
            ps += "; Stop-Process -Name GreenRook -Force -ErrorAction SilentlyContinue"      # the packaged .exe, if that is what runs
            subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, creationflags=NO_WINDOW, timeout=30)
        else:       # anchored: only "<python> .../greenrook.py", never a shell or editor that merely mentions the name
            subprocess.run(["pkill", "-f", r"^[^ ]*python[0-9.]* +[^ ]*greenrook\.py"], capture_output=True, timeout=15)
    except Exception:
        pass
    time.sleep(0.5)


# ------------------------------------------------------------------ install / uninstall
def install(target: Path, autostart=True, launch=True, quiet=False):
    total = 5
    step(1, total, "Stopping any running copy of Green Rook")
    stop_running()
    step(2, total, f"Copying the program to {target}")
    n = copy_program(target)
    print(f"      {len(n)} program files copied.")
    step(3, total, "Setting up Green Rook's private Python environment (about a minute the first time)")
    make_environment(target)
    step(4, total, "Adding icons" if IS_WIN else "Adding it to your applications menu")
    if IS_WIN:
        windows_shortcuts(target)
        windows_register(target, autostart)
    elif IS_LINUX:
        d = linux_menu_dir()
        d.mkdir(parents=True, exist_ok=True)
        (d / "greenrook.desktop").write_text(desktop_entry(target))
    else:
        print("      (no menu entry on this system; start it with:  " + f"{venv_python(target)} {target / 'greenrook.py'})")
    step(5, total, "Done")
    print(f"\n  {NAME} {version()} is installed.")
    if IS_WIN:
        print("  Find it on your Desktop and in the Start Menu (type 'Green Rook').")
        print("  Use 'Green Rook (Administrator)' in the Start Menu when you need it to delete protected files.")
        print("  To remove it: Settings > Apps > Green Rook > Uninstall.")
    if launch:
        kw = {"creationflags": 0x00000008 | NO_WINDOW} if IS_WIN else {"start_new_session": True}
        if IS_WIN:
            import secrets
            log_dir = Path(os.environ.get("APPDATA", str(Path.home() / "AppData" / "Roaming"))) / "GreenRook"
            log_dir.mkdir(parents=True, exist_ok=True)
            log_path = log_dir / "startup-error.log"
            ready_path = log_dir / ("startup-ready-" + secrets.token_hex(8) + ".txt")
            child_env = dict(os.environ, GREENROOK_STARTUP_READY=str(ready_path))
            with log_path.open("a", encoding="utf-8") as log:
                log.write("\n--- Installer launch " + time.strftime("%Y-%m-%d %H:%M:%S") + " ---\n")
                proc = subprocess.Popen([str(venv_python(target)), str(target / "greenrook.py")], cwd=str(target),
                                        stdin=subprocess.DEVNULL, stdout=log, stderr=log, env=child_env, **kw)
            print("  Waiting for Green Rook's window to finish opening...")
            deadline = time.monotonic() + 25
            while time.monotonic() < deadline and not ready_path.exists() and proc.poll() is None:
                time.sleep(0.25)
            if ready_path.exists():
                ready_path.unlink(missing_ok=True)
                print("  Green Rook opened successfully.")
                return True
            elif proc.poll() is not None:
                print("  Green Rook closed before its window opened. Startup details:")
                try:
                    print("\n".join(log_path.read_text(encoding="utf-8", errors="replace").splitlines()[-24:]))
                except OSError:
                    print(f"  Could not read the startup log. It should be at: {log_path}")
                print(f"\n  Full startup log: {log_path}")
                return False
            else:
                print("  Green Rook is still starting, but did not confirm its window in 25 seconds.")
                print(f"  Startup details are saved in: {log_path}")
                return False
        else:
            subprocess.Popen([str(venv_python(target)), str(target / "greenrook.py")], cwd=str(target),
                             stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **kw)
            print("  Starting Green Rook...")


def check_uninstall_pin(quiet=False) -> bool:
    """If you set a Green Rook PIN, malware cannot simply run the uninstaller: it asks for the PIN."""
    try:
        import gr_core
        import gr_guards
        pin = gr_core.Config(gr_core.data_dir() / "config.json").get("pin")
    except Exception:
        return True
    if not pin:
        return True
    import getpass
    for _ in range(3):
        if gr_guards.check_pin(pin, getpass.getpass("Green Rook PIN: ")):
            return True
        print("That PIN is not correct.")
    return False


def uninstall(target: Path, remove_data=False, assume_yes=False):
    if not assume_yes:
        if input(f"Remove {NAME} from this computer? [y/N] ").strip().lower() != "y":
            print("Nothing was changed.")
            return False
        if not check_uninstall_pin():
            print("Uninstall cancelled.")
            return False
        if not remove_data:
            remove_data = input("Also delete the quarantine and settings? (Quarantined files cannot be restored afterwards) [y/N] ").strip().lower() == "y"
    stop_running()
    if IS_WIN:
        for lnk in (windows_desktop() / "Green Rook.lnk",):
            lnk.unlink(missing_ok=True)
        shutil.rmtree(start_menu_dir(), ignore_errors=True)
        windows_unregister()
    elif IS_LINUX:
        (linux_menu_dir() / "greenrook.desktop").unlink(missing_ok=True)
    if remove_data:
        try:
            import gr_core
            shutil.rmtree(gr_core.data_dir(), ignore_errors=True)
        except Exception:
            pass
    installed = is_installed_dir(target)
    if not installed:
        print(f"{target} does not look like an installed copy, so its files were left alone.")
    elif IS_WIN:      # we are running from inside the folder, so let a helper delete it once we have exited
        subprocess.Popen(f'cmd /c "timeout /t 3 /nobreak >nul & rmdir /s /q "{target}""', shell=True, creationflags=0x00000008 | NO_WINDOW)
    else:
        shutil.rmtree(target, ignore_errors=True)
    if installed or IS_WIN:
        print(f"{NAME} has been removed." + ("" if remove_data else " Your quarantine and settings were kept."))
    else:
        print("Menu entries and registrations were cleaned up. No program files were deleted.")
    return True


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--uninstall", action="store_true")
    ap.add_argument("--yes", action="store_true")
    ap.add_argument("--no-autostart", action="store_true")
    ap.add_argument("--no-launch", action="store_true")
    ap.add_argument("--remove-data", action="store_true")
    ap.add_argument("--target")
    a = ap.parse_args(argv)
    target = Path(a.target) if a.target else (SRC if a.uninstall else default_target())
    if a.uninstall:
        target = Path(a.target) if a.target else SRC
        return 0 if uninstall(target, a.remove_data, a.yes) else 1
    print(f"\n{NAME} {version()} installer")
    if sys.version_info < (3, 9):
        print("Green Rook needs Python 3.9 or newer.")
        return 1
    # Keep the recommended login startup enabled by default without blocking the installer on console input.
    # Use --no-autostart when an unattended or manual-start-only install is wanted.
    autostart = not a.no_autostart
    try:
        opened = install(target, autostart, not a.no_launch)
    except (RuntimeError, subprocess.CalledProcessError, subprocess.TimeoutExpired, OSError) as e:
        print(f"\nInstall problem: {e}")
        return 1
    return 2 if opened is False else 0


if __name__ == "__main__":
    sys.exit(main())
