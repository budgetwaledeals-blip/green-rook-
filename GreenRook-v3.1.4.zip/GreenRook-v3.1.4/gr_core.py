"""
Green Rook core engine (no GUI code here).

Config (tamper-evident), event log, Aho-Corasick signature matcher, file analysis engine
(hashes, signatures, PE/ELF/script/archive heuristics, cloud hash reputation), encrypted
quarantine vault, URL analysis + hosts blocking, permission broker, and the file/camera guards.
"""
import copy
import hashlib
import hmac
import io
import json
import math
import os
import re
import secrets
import stat
import socket
import struct
import subprocess
import sys
import threading
import time
import urllib.request
import uuid
import zipfile
from collections import Counter, deque
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlparse

try:
    import psutil
except Exception:  # optional dependency
    psutil = None

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
except Exception:  # optional dependency
    AESGCM = None

import gr_trust  # noqa: E402  (digital-signature checks that stop false alarms on genuine software)
import gr_office  # noqa: E402  (macro analysis; pure Python, no extra dependencies)
from gr_intel import DEFAULT_FEEDS, IntelStore, PackError, fetch_hash_feed  # noqa: E402,F401

APP_NAME = "Green Rook"
VERSION = "3.1.4"
IS_WIN = os.name == "nt"
IS_MAC = sys.platform == "darwin"
IS_LINUX = sys.platform.startswith("linux")
APP_DIR = Path(__file__).resolve().parent        # where the program's resources are (a temp folder inside a packaged .exe)
# Where the program really lives on disk. Inside a packaged .exe APP_DIR is a temporary unpack folder, so protect this one too.
INSTALL_DIR = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else APP_DIR

CLEAN, SUSPICIOUS, MALICIOUS, SKIPPED, ERROR = "Clean", "Suspicious", "Malicious", "Skipped", "Error"
SUS_THRESHOLD, MAL_THRESHOLD = 30, 70


_hardened = False


def harden_dir(p: Path):
    """Restrict the data folder to the current user, SYSTEM and Administrators."""
    global _hardened
    if _hardened:
        return
    _hardened = True
    try:
        if IS_WIN:
            user = os.environ.get("USERNAME", "")
            dom = os.environ.get("USERDOMAIN", "")
            who = f"{dom}\\{user}" if dom and user else user
            if not who:
                return                      # never lock a folder when we cannot say who should keep access
            subprocess.run(["icacls", str(p), "/inheritance:r", "/grant:r", f"{who}:(OI)(CI)F",
                            "SYSTEM:(OI)(CI)F", "*S-1-5-32-544:(OI)(CI)F"], capture_output=True,
                           creationflags=0x08000000, timeout=20)
            probe = Path(p) / ".write_test"
            try:                            # if we locked ourselves out, undo it immediately
                probe.write_text("x")
                probe.unlink()
            except OSError:
                subprocess.run(["icacls", str(p), "/reset", "/T"], capture_output=True, creationflags=0x08000000, timeout=30)
        else:
            os.chmod(p, 0o700)
    except Exception:
        pass


def atomic_write(path: Path, data, binary=False):
    """Write to a temp file in the same folder, flush to disk, then rename over the target.
    A crash or power cut can never leave a half-written settings/index file behind."""
    path = Path(path)
    tmp = path.with_name(path.name + ".tmp")
    mode = "wb" if binary else "w"
    with open(tmp, mode, **({} if binary else {"encoding": "utf-8"})) as f:
        f.write(data)
        f.flush()
        try:
            os.fsync(f.fileno())
        except OSError:
            pass
    for attempt in range(6):
        try:
            os.replace(tmp, path)
            return
        except PermissionError:             # another program (often antivirus or the indexer) has the file open for a moment
            time.sleep(0.15 * (attempt + 1))
    try:                                    # last resort: write in place (not atomic, but better than losing the data)
        with open(path, "wb" if binary else "w", **({} if binary else {"encoding": "utf-8"})) as f:
            f.write(data)
        os.remove(tmp)
    except OSError:
        raise


def system_protected(path: str) -> bool:
    """Operating-system folders. Green Rook flags files here but NEVER removes them automatically:
    deleting the wrong file in these folders can make a PC unbootable."""
    p = os.path.abspath(path).lower().replace("/", "\\" if IS_WIN else "/")
    if IS_WIN:
        root = os.environ.get("SystemRoot", "C:\\Windows").lower()
        pf = [os.environ.get(v, "").lower() for v in ("ProgramFiles", "ProgramFiles(x86)")]
        if p.startswith(root + "\\"):               # all of C:\Windows (explorer.exe lives directly in it), except its Temp folder
            return not p.startswith(root + "\\temp\\")
        return any(p == x or p.startswith(x + "\\") for x in pf if x)
    pre = ("/usr/bin", "/usr/sbin", "/bin", "/sbin", "/lib", "/lib64", "/usr/lib", "/boot", "/etc", "/system", "/usr/libexec")
    return any(p == x or p.startswith(x + "/") for x in pre)


def _win_clear_attrs(path):
    try:
        import ctypes
        ctypes.windll.kernel32.SetFileAttributesW(path, 0x80)     # remove read-only / hidden / system flags
    except Exception:
        pass


def _win_long(path):
    """Very long paths need the \\\\?\\ prefix on Windows."""
    if IS_WIN and len(path) > 240 and not path.startswith("\\\\"):     # (network paths are left alone)
        return "\\\\?\\" + path
    return path


def file_holders(path, limit=4):
    """Names of programs that currently have this file open (best effort)."""
    names = []
    if not psutil:
        return names
    ap = os.path.normcase(os.path.abspath(path))
    t0 = time.time()
    for p in psutil.process_iter(["name"]):
        if time.time() - t0 > 3 or len(names) >= limit:
            break
        try:
            if any(os.path.normcase(f.path) == ap for f in p.open_files()):
                names.append(p.info["name"] or "?")
        except Exception:
            continue
    return names


def explain_block(path, exc):
    """Turn a Windows refusal into advice a person can act on."""
    code = getattr(exc, "winerror", None) or getattr(exc, "errno", None)
    if code in (32, 33):
        who = file_holders(path)
        return ("The file is in use" + (f" by {', '.join(who)}" if who else "") +
                ". Close that program (or stop it on the 'Running programs' page) and try again.")
    low = os.path.abspath(path).lower()
    cfa = any(f"\\{d}" in low for d in ("documents", "desktop", "pictures", "videos", "music", "downloads"))
    msg = "Windows refused access. Try: Settings > Restart as administrator (or right-click the Green Rook icon > Run as administrator)."
    if cfa and IS_WIN:
        msg += (" This file is in one of your personal folders. If it still fails, Windows Security > Ransomware protection > "
                "Controlled folder access may be blocking Green Rook: choose 'Allow an app through Controlled folder access' and add "
                "pythonw.exe (or GreenRook.exe).")
    if not IS_WIN:
        msg = f"Not allowed: {exc}. Try running with sudo."
    return msg


def _win_take_ownership(path):
    try:
        user = os.environ.get("USERNAME", "")
        dom = os.environ.get("USERDOMAIN", "")
        who = f"{dom}\\{user}" if dom and user else user
        subprocess.run(["takeown", "/f", path], capture_output=True, creationflags=0x08000000, timeout=15)
        if who:
            subprocess.run(["icacls", path, "/grant", f"{who}:F"], capture_output=True, creationflags=0x08000000, timeout=15)
        subprocess.run(["icacls", path, "/grant", "*S-1-5-32-544:F"], capture_output=True, creationflags=0x08000000, timeout=15)
    except Exception:
        pass


def _win_delete_on_reboot(path):
    try:
        import ctypes
        return bool(ctypes.windll.kernel32.MoveFileExW(path, None, 0x4))    # MOVEFILE_DELAY_UNTIL_REBOOT (needs administrator)
    except Exception:
        return False


def force_remove(path):
    """Remove one file as persistently as Windows allows. Returns (ok, pending_restart, message).
    Steps: clear read-only flags, retry (antivirus/indexer locks pass), take ownership, then schedule removal for the next restart."""
    ap = os.path.abspath(path)
    last = None
    for attempt in range(6):
        target = _win_long(ap)
        try:
            if IS_WIN:
                _win_clear_attrs(target)
            else:
                os.chmod(ap, stat.S_IWRITE | stat.S_IREAD)
        except OSError:
            pass
        try:
            os.remove(target)
            return True, False, "Removed."
        except FileNotFoundError:
            return True, False, "Already gone."
        except PermissionError as e:
            last = e
            if IS_WIN and attempt == 2:
                _win_take_ownership(ap)
        except OSError as e:
            last = e
        time.sleep(0.35)
    if IS_WIN and _win_delete_on_reboot(ap):
        return True, True, "Windows is using this file right now. It will be deleted automatically when you restart your PC."
    return False, False, explain_block(ap, last)


def safe_delete(path: str):
    """Permanently delete one file the user chose. Returns (ok, message). Never touches Green Rook's own files,
    never follows a link to somewhere else, and never removes folders."""
    try:
        ap = os.path.abspath(path)
        mine = [os.path.abspath(str(d)).lower() for d in (APP_DIR, INSTALL_DIR, data_dir())]
        if any(ap.lower() == m or ap.lower().startswith(m + os.sep) for m in mine):
            return False, "That file belongs to Green Rook itself, so it will not be deleted."
        if not os.path.lexists(ap):
            return True, "Already gone."
        if os.path.isdir(ap) and not os.path.islink(ap):
            return False, "Folders are not deleted here - only single files."
        ok, pending, msg = force_remove(ap)     # for a link this removes only the link, never its target
        return ok, ("Deleted." if ok and not pending else msg)
    except OSError as e:
        return False, str(e)


def data_dir() -> Path:
    base = os.environ.get("APPDATA") if IS_WIN else None
    p = Path(base) / "GreenRook" if base else Path.home() / ".greenrook"
    p.mkdir(parents=True, exist_ok=True)
    harden_dir(p)
    return p


# --------------------------------------------------------------------------- config
def default_watch_dirs():
    home = Path.home()
    dirs = [home / "Downloads", home / "Desktop"]
    if IS_WIN:
        tmp = os.environ.get("TEMP")
        if tmp:
            dirs.append(Path(tmp))
    else:
        dirs.append(Path("/tmp"))
    return [str(d) for d in dirs if d.exists()]


def default_protected_dirs():
    home = Path.home()
    return [str(home / n) for n in ("Documents", "Pictures", "Desktop") if (home / n).exists()]


DEFAULTS = {
    "watch_dirs": None, "protected_dirs": None,
    "realtime": True, "process_guard": True, "ransomware_guard": True, "persistence_guard": True,
    "usb_guard": True, "network_guard": True, "camera_guard": True, "tamper_protection": True,
    "cloud_lookup": True, "auto_quarantine": True, "prompt_timeout": 30,
    "scan_every_hours": 24, "last_auto_scan": 0, "pin": "",
    "rule_modes": {}, "allow_hashes": [], "camera_allowed": [], "proc_allowed": [], "net_allowed": [],
    "canaries": {}, "trusted_keys": [], "intel_serials": {}, "hash_feeds": list(DEFAULT_FEEDS), "last_feed_update": 0,
    "stats": {"files": 0, "threats": 0, "last_scan": "Never"},
    "ultra_profiles": [], "ultra_active": "", "ultra_want": False,
    "trust_signed": True, "shield_undo": {}, "shield_docs_seen": [],
    "app_icon": "green", "ultra_mode": "tor", "tor_want": False, "tor_proxy_set": False, "tor_prev_proxy": {}, "tor_set_proxy": True,
}


def _load_key(path: Path) -> bytes:
    if not path.exists():
        path.write_bytes(secrets.token_bytes(32))
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
    return path.read_bytes()


class Config:
    """Settings file protected by an HMAC: edits made behind our back are detected and discarded."""

    def __init__(self, path: Path):
        self.path = path
        self.lock = threading.RLock()
        self.tampered = False
        self.key = _load_key(path.parent / "integrity.key")
        self.data = copy.deepcopy(DEFAULTS)
        if path.exists():
            try:
                raw = json.loads(path.read_text("utf-8"))
                body, mac = raw["data"], raw["mac"]
                if hmac.compare_digest(mac, self._mac(body)):
                    self.data.update(body)
                else:
                    self.tampered = True
            except Exception:
                self.tampered = True
        if not self.data.get("watch_dirs"):
            self.data["watch_dirs"] = default_watch_dirs()
        if not self.data.get("protected_dirs"):
            self.data["protected_dirs"] = default_protected_dirs()
        self.save()

    def _mac(self, body):
        return hmac.new(self.key, json.dumps(body, sort_keys=True).encode(), hashlib.sha256).hexdigest()

    def get(self, k):
        with self.lock:
            return copy.deepcopy(self.data.get(k))

    def set(self, k, v):
        with self.lock:
            self.data[k] = v
            self.save()

    def append_unique(self, k, v):
        with self.lock:
            lst = self.data.setdefault(k, [])
            if v not in lst:
                lst.append(v)
                self.save()

    def save(self):
        with self.lock:
            try:
                atomic_write(self.path, json.dumps({"data": self.data, "mac": self._mac(self.data)}, indent=1))
            except OSError:
                pass

    def verify_disk(self) -> bool:
        """True if the file on disk is still ours. If not, rewrite it from memory (self-heal)."""
        with self.lock:
            try:
                raw = json.loads(self.path.read_text("utf-8"))
                if hmac.compare_digest(raw["mac"], self._mac(raw["data"])) and raw["data"] == json.loads(json.dumps(self.data)):
                    return True
            except Exception:
                pass
            self.save()
            return False


# --------------------------------------------------------------------------- events
class EventBus:
    def __init__(self, logfile: Path, ui_q):
        self.logfile = logfile
        self.ui_q = ui_q
        self.lock = threading.Lock()
        self.history = deque(maxlen=3000)
        try:
            if logfile.exists() and logfile.stat().st_size > 2_000_000:
                logfile.replace(logfile.with_suffix(".old"))
        except OSError:
            pass

    def emit(self, level, source, msg):
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        entry = (ts, level, source, msg)
        with self.lock:
            self.history.append(entry)
            try:
                with open(self.logfile, "a", encoding="utf-8") as f:
                    f.write(f"{ts} [{level}] {source}: {msg}\n")
            except OSError:
                pass
        self.ui_q.put(("log", entry))

    def notify(self, level, title, msg):
        now = time.time()                       # the same pop-up is shown at most once a minute (no warning spam)
        with self.lock:
            recent = self.__dict__.setdefault("_recent_notes", {})
            if now - recent.get((title, msg), 0) < 60:
                return
            if len(recent) > 500:
                recent.clear()
            recent[(title, msg)] = now
        self.ui_q.put(("notify", level, title, msg))


# --------------------------------------------------------------------------- permission broker
class Prompt:
    def __init__(self, key, title, headline, details, options, default, timeout):
        self.key, self.title, self.headline = key, title, headline
        self.details, self.options = details, options  # options: [(id, label, style)]
        self.default, self.timeout = default, timeout
        self.result = default
        self.fallback = default     # what happens if nobody answers
        self.answered = False       # True only when a person clicked a button
        self.event = threading.Event()


class Broker:
    """Thread-safe consent queue. Worker threads block on ask(); the UI answers."""

    def __init__(self, ui_q, cfg):
        self.ui_q, self.cfg = ui_q, cfg
        self.pending = set()
        self.lock = threading.Lock()
        self.shutdown = False

    REMEMBER = 600      # seconds: the same question is not asked again, your last answer is reused

    def ask(self, key, title, headline, details, options, default, on_timeout=None):
        """Ask the user. Two rules new in 3.0:
        - No answer never destroys anything: if nobody clicks, the gentle option ("once") is taken, unless the caller
          explicitly passes on_timeout (only the ransomware shield does, because waiting there costs files).
        - The same question (same title and headline) is asked once; for ten minutes the answer is reused."""
        ids = [o[0] for o in options]
        fallback = on_timeout if on_timeout is not None else ("once" if "once" in ids else default)
        sig, now = (title, headline), time.time()
        with self.lock:
            memo = self.__dict__.setdefault("recent", {})
            if sig in memo and now - memo[sig][1] < self.REMEMBER:
                return memo[sig][0]
            if key in self.pending:
                return fallback
            self.pending.add(key)
        p = Prompt(key, title, headline, details, options, default, int(self.cfg.get("prompt_timeout") or 30))
        p.fallback = p.result = fallback
        self.ui_q.put(("prompt", p))
        try:
            while not p.event.wait(0.5):
                if self.shutdown:
                    break
            with self.lock:
                if len(memo) > 300:
                    memo.clear()
                if p.result not in ("always", "once"):
                    memo[sig] = (p.result, time.time())
            return p.result
        finally:
            with self.lock:
                self.pending.discard(key)


# --------------------------------------------------------------------------- Aho-Corasick
class AhoCorasick:
    def __init__(self, patterns):
        self.goto, self.fail, self.out = [{}], [0], [[]]
        for pat, name in patterns.items():
            s = 0
            for b in pat:
                nxt = self.goto[s].get(b)
                if nxt is None:
                    self.goto.append({})
                    self.fail.append(0)
                    self.out.append([])
                    nxt = len(self.goto) - 1
                    self.goto[s][b] = nxt
                s = nxt
            self.out[s].append(name)
        q = deque(self.goto[0].values())
        while q:
            r = q.popleft()
            for b, s in self.goto[r].items():
                q.append(s)
                f = self.fail[r]
                while f and b not in self.goto[f]:
                    f = self.fail[f]
                fs = self.goto[f].get(b, 0)
                self.fail[s] = fs if fs != s else 0
                self.out[s] = self.out[s] + self.out[self.fail[s]]

    def search(self, data: bytes):
        found, s = set(), 0
        goto, fail, out = self.goto, self.fail, self.out
        for b in data:
            while s and b not in goto[s]:
                s = fail[s]
            s = goto[s].get(b, 0)
            o = out[s]
            if o:
                found.update(o)
        return found


def _p(*parts):
    return "".join(parts).lower().encode("latin-1")


# (name, weight, [patterns]).  Pattern text is assembled from fragments on purpose
# so that this source file does not itself look like malware to other scanners.
SIGNATURES = [
    ("EICAR antivirus test file", 100,
     [_p("x5o!p%@ap[4\\pzx54(p^)7cc)7}$", "eicar-standard-", "antivirus-test-file!$h+h*")]),
    ("Credential dumper command", 60, [_p("sekur", "lsa::"), _p("invoke-", "mimi", "katz")]),
    ("Credential-dumping tool name", 35, [_p("mimi", "katz")]),
    ("LSASS dump via comsvcs", 50, [_p("comsvcs.dll,", "minidump"), _p("comsvcs.dll, ", "minidump")]),
    ("AMSI bypass", 50, [_p("amsi", "initfailed")]),
    ("Disables Defender real-time protection", 50, [_p("set-mppreference -disable", "realtimemonitoring")]),
    ("Disables anti-spyware policy", 25, [_p("disable", "antispyware")]),
    ("Reverse shell (bash)", 60, [_p("bash -i >& /dev", "/tcp/")]),
    ("Reverse shell (netcat -e)", 40, [_p("nc -e /bin", "/sh"), _p("nc -e /bin", "/bash")]),
    ("Decode-and-pipe-to-shell", 40, [_p("base64 -d | ba", "sh"), _p("base64 -d|ba", "sh"), _p("base64 -d | s", "h")]),
    ("Shadow copy deletion (ransomware behaviour)", 45, [_p("vssadmin delete ", "shadows"), _p("wmic shadowcopy ", "delete")]),
    ("Backup catalog deletion", 35, [_p("wbadmin delete ", "catalog")]),
    ("Disables Windows recovery", 25, [_p("recoveryenabled ", "no")]),
    ("Ransom-note text", 40, [_p("your files have been ", "encrypted"), _p("all your files are ", "encrypted"),
                              _p("decrypt your ", "files")]),
    ("PowerShell encoded command", 15, [_p("-encoded", "command"), _p(" -en", "c ")]),
    ("PowerShell downloader", 15, [_p("download", "string("), _p("net.web", "client")]),
    ("PowerShell base64 decode", 12, [_p("frombase64", "string")]),
    ("PowerShell hidden window", 12, [_p("-windowstyle ", "hidden"), _p("-w hid", "den")]),
    ("PowerShell policy bypass", 10, [_p("-executionpolicy ", "bypass"), _p("-ep byp", "ass")]),
    ("PowerShell dynamic execution", 10, [_p("invoke-", "expression")]),
    ("certutil downloader", 30, [_p("certutil", " -urlcache"), _p("certutil.exe", " -urlcache")]),
    ("mshta remote script", 35, [_p("mshta ", "http"), _p("mshta.exe ", "http")]),
    ("regsvr32 remote scriptlet", 45, [_p("regsvr32 /s /n /u /i:", "http")]),
    ("rundll32 script execution", 40, [_p("rundll32 ", "javascript:")]),
    ("bitsadmin download", 25, [_p("bitsadmin /", "transfer")]),
    ("Creates scheduled task", 8, [_p("schtasks /", "create")]),
    ("Run-key persistence", 10, [_p("currentversion\\", "run")]),
    ("Windows script host shell", 8, [_p("wscript.", "shell")]),
    ("API: download-to-file helper", 20, [_p("urldownload", "tofile")]),
    ("Office macro auto-run", 8, [_p("auto", "open"), _p("document_", "open"), _p("workbook_", "open")]),
    ("API: remote thread creation", 8, [_p("createremote", "thread")]),
    ("API: remote memory write", 8, [_p("writeprocess", "memory")]),
    ("API: remote memory allocation", 8, [_p("virtualalloc", "ex\0"), _p("virtualalloc", "ex")]),
    ("API: section unmapping (process hollowing)", 15, [_p("ntunmapview", "ofsection")]),
    ("API: input hooking (keylogging)", 8, [_p("setwindows", "hookex")]),
    ("API: key-state polling (keylogging)", 8, [_p("getasync", "keystate")]),
    ("Debug privilege request", 10, [_p("sedebug", "privilege")]),
    ("PDF launch action", 20, [_p("/lau", "nch")]),
    ("PDF auto-run script", 10, [_p("/open", "action"), _p("/java", "script")]),
    ("Clears Windows event logs", 30, [_p("wevtutil", " cl ")]),
    ("Disables firewall", 30, [_p("advfirewall set allprofiles state ", "off")]),
    ("Stops Defender service", 35, [_p("sc stop win", "defend"), _p("net stop win", "defend")]),
    ("Dumps credential registry hives", 35, [_p("reg save hklm\\s", "am"), _p("reg save hklm\\sys", "tem")]),
    ("Remote process creation via WMI", 25, [_p("wmic process call ", "create")]),
    # -- script-worm / mass-mailer behaviour (Melissa, ILOVEYOU class of incident) --
    ("Script automates Outlook", 10, [_p("outlook.", "application")]),
    ("Script reads the Outlook address book", 12, [_p("address", "entries"), _p("address", "lists")]),
    ("Script writes to the registry", 8, [_p("reg", "write")]),
    ("Script copies itself (self-replication)", 8, [_p("scripting.file", "systemobject")]),
    ("Script hides its window when starting programs", 6, [_p("vb", "hide")]),
]
PATTERN_TO_NAME, NAME_TO_WEIGHT = {}, {}
for _name, _w, _pats in SIGNATURES:
    NAME_TO_WEIGHT[_name] = _w
    for _pt in _pats:
        PATTERN_TO_NAME[_pt] = _name
AC = AhoCorasick(PATTERN_TO_NAME)

EICAR_SHA256 = "275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f"
EXEC_EXTS = {".exe", ".scr", ".com", ".bat", ".cmd", ".ps1", ".vbs", ".vbe", ".js", ".jse", ".wsf", ".hta",
             ".lnk", ".msi", ".jar", ".pif", ".cpl", ".dll", ".sys", ".reg"}
SCAN_EXTS = EXEC_EXTS | {".psm1", ".msp", ".docm", ".xlsm", ".pptm", ".dotm", ".xlam", ".zip", ".7z", ".rar",
                         ".iso", ".img", ".sh", ".py", ".pl", ".rb", ".php", ".elf", ".so", ".bin", ".apk",
                         ".doc", ".xls", ".ppt", ".rtf", ".pdf", ".docx", ".xlsx", ".pptx", ".appimage", ".deb", ".rpm"}
MEDIA_EXTS = {".mp4", ".mkv", ".avi", ".mov", ".mp3", ".flac", ".wav", ".jpg", ".jpeg", ".png", ".gif", ".webp",
              ".bmp", ".ico", ".svg", ".ttf", ".otf", ".woff", ".woff2", ".webm", ".m4a", ".ogg", ".heic"}
ZIP_EXTS = {".zip", ".jar", ".docx", ".xlsx", ".pptx", ".docm", ".xlsm", ".pptm", ".apk", ".xlam", ".dotm"}
PACKER_SECTIONS = {"upx0", "upx1", "upx2", ".aspack", ".adata", ".themida", ".vmp0", ".vmp1", ".petite",
                   ".mpress1", ".mpress2", ".nsp0", ".nsp1", ".enigma1", ".boom", ".perplex"}
WEAK_IN_BINARY, WEAK_CAP = 20, 15   # in .exe/.dll files, low-weight text clues together count for at most 15 points
MAX_FILE = 200 * 1024 * 1024
FULL_READ = 24 * 1024 * 1024
EDGE = 4 * 1024 * 1024
DOUBLE_EXT = re.compile(r"\.(pdf|docx?|xlsx?|pptx?|jpe?g|png|gif|txt|mp3|mp4|zip)\s*\.(exe|scr|bat|cmd|com|js|vbs|ps1|lnk|hta|pif)$", re.I)


def entropy(data: bytes) -> float:
    if not data:
        return 0.0
    n = len(data)
    return -sum((c / n) * math.log2(c / n) for c in Counter(data).values())


@dataclass
class Findings:
    score: int = 0
    reasons: list = field(default_factory=list)
    meta: dict = field(default_factory=dict)
    confirmed: bool = False   # True only for hard evidence: known hash, cloud hit, EICAR, strong signature

    def add(self, n, why, confirmed=False):
        self.score += n
        self.reasons.append(f"{why} (+{n})")
        if confirmed:
            self.confirmed = True


@dataclass
class ScanResult:
    path: str
    verdict: str
    score: int = 0
    reasons: list = field(default_factory=list)
    sha256: str = ""
    size: int = 0
    confirmed: bool = False   # hard evidence (hash / cloud / signature) vs. behaviour-and-structure guesses

    @property
    def confidence(self) -> str:
        if self.verdict not in (MALICIOUS, SUSPICIOUS):
            return "n/a"
        return "High (hard evidence)" if self.confirmed else ("Medium (heuristics only)" if self.score >= MAL_THRESHOLD else "Low (heuristics only)")

    def explain(self) -> str:
        """Plain-English account of why this file was flagged and what Green Rook will / will not do."""
        if self.verdict == CLEAN:
            return "Nothing suspicious was found. This is not a guarantee of safety."
        if self.verdict in (SKIPPED, ERROR):
            return "; ".join(self.reasons) or self.verdict
        word = {MALICIOUS: "Dangerous", SUSPICIOUS: "Suspicious"}.get(self.verdict, self.verdict)
        lines = [f"Result: {word}      Risk: {self.score}/100      How sure: {self.confidence}", "", "Why it was flagged:"]
        lines += [f"  - {r}" for r in self.reasons] or ["  - (no detail recorded)"]
        lines.append("")
        if self.confirmed:
            lines.append("This match is based on hard evidence (a known-bad fingerprint or signature), so it is very unlikely to be a false alarm.")
        else:
            lines.append("This verdict is based on behaviour and file-structure clues only. Such clues can also appear in legitimate "
                         "software (installers, packers, admin scripts), so Green Rook will ask before removing it.")
        if system_protected(self.path):
            lines.append("The file sits in an operating-system folder, so Green Rook will never remove it automatically.")
        lines.append("Quarantine is reversible: the file is encrypted in the Vault and can be restored at any time.")
        return "\n".join(lines)

    @property
    def auto_safe(self) -> bool:
        """May Green Rook remove this without asking? Only for confirmed malware outside OS folders."""
        return self.verdict == MALICIOUS and self.confirmed and not system_protected(self.path)


# --------------------------------------------------------------------------- cloud reputation
class CloudLookup:
    """Hash-only reputation check against Team Cymru's Malware Hash Registry (DNS, no file is uploaded)."""

    def __init__(self):
        self.cache, self.lock = {}, threading.Lock()
        self.fail, self.backoff = 0, 0.0

    def check(self, sha: str, timeout=3.0):
        now = time.time()
        with self.lock:
            hit = self.cache.get(sha)
            if hit and now - hit[1] < (6 * 3600 if hit[0] else 1800):
                return hit[0]
            if now < self.backoff:
                return None
        host = f"{sha[:32]}.{sha[32:]}.hash.cymru.com"
        res = [None]

        def work():
            try:
                res[0] = socket.gethostbyname(host)
            except socket.gaierror:
                res[0] = ""
            except Exception:
                res[0] = None
        t = threading.Thread(target=work, daemon=True)
        t.start()
        t.join(timeout)
        with self.lock:
            if res[0] is None:
                self.fail += 1
                if self.fail >= 3:
                    self.backoff, self.fail = now + 300, 0
                return None
            self.fail = 0
            verdict = res[0] == "127.0.0.2"
            if len(self.cache) > 5000:
                self.cache.clear()
            self.cache[sha] = (verdict, now)
            return verdict


# --------------------------------------------------------------------------- engine
class Engine:
    def __init__(self, cfg: Config, bus: EventBus):
        self.cfg, self.bus = cfg, bus
        self.lock = threading.Lock()
        self.session = {"files": 0, "threats": 0}
        self.hash_file = data_dir() / "hashes.txt"
        self.feed_file = data_dir() / "feeds.txt"
        self.intel = IntelStore(data_dir(), cfg, bus)
        self.hashdb = {}
        self.exclude = [str(APP_DIR), str(INSTALL_DIR), str(data_dir())]
        self.rules_file = data_dir() / "rules.json"
        self.custom_ac, self.custom_w = None, {}
        self.cloud = CloudLookup()
        self._allow_cache = (None, frozenset())
        self.own_hashes = self._load_own_hashes()
        self.reload_hashes()
        self.reload_rules()

    @staticmethod
    def _load_own_hashes() -> frozenset:
        """SHA-256 of every file Green Rook ships (so a copy of Green Rook itself is never reported as a threat: its source code
        legitimately contains the words it hunts for). The list is trusted only if MANIFEST.sha256 vouches for it, so a stray edit is ignored."""
        try:
            own = APP_DIR / "OWNFILES.sha256"
            manifest = (APP_DIR / "MANIFEST.sha256").read_text("utf-8").splitlines()
            digest = hashlib.sha256(own.read_bytes()).hexdigest()
            if not any(ln.strip() == f"{digest}  OWNFILES.sha256" for ln in manifest):
                return frozenset()
            return frozenset(ln.split()[0].lower() for ln in own.read_text("utf-8").splitlines()
                             if re.fullmatch(r"[0-9a-fA-F]{64}\s+\S.*", ln.strip()))
        except OSError:
            return frozenset()

    def allowed(self, sha: str) -> bool:
        """Set lookup (rebuilt only when the allow-list changes) instead of copying the list for every file."""
        lst = self.cfg.get("allow_hashes") or []
        key = len(lst)
        if self._allow_cache[0] != key:
            self._allow_cache = (key, frozenset(lst))
        return sha in self._allow_cache[1]

    def reload_rules(self):
        """Optional user rules: [{"name": "...", "weight": 40, "any": ["text", ...]}, ...]"""
        pats, weights = {}, {}
        try:
            if not self.rules_file.exists():
                self.rules_file.write_text(json.dumps([{"name": "Example rule (edit me)", "weight": 40,
                                                        "any": []}], indent=2), "utf-8")
            for r in json.loads(self.rules_file.read_text("utf-8")):
                nm = "Custom rule: " + str(r["name"])
                weights[nm] = int(r.get("weight", 30))
                for t in r.get("any", []):
                    if t:
                        pats[str(t).lower().encode("utf-8")] = nm
        except Exception:
            pass
        try:
            for r in self.intel.load_all()["rules"]:      # rules from verified, signed packs
                nm = "Signed rule: " + r["name"]
                weights[nm] = int(r["weight"])
                for t in r["any"]:
                    pats[t.lower().encode("utf-8")] = nm
        except Exception:
            pass
        self.custom_w = weights
        self.custom_ac = AhoCorasick(pats) if pats else None
        return len(weights)

    def reload_hashes(self):
        db = {EICAR_SHA256: "EICAR antivirus test file"}
        try:
            for line in self.feed_file.read_text("utf-8", "ignore").splitlines():
                t = line.strip().lower()
                if re.fullmatch(r"[0-9a-f]{64}", t):
                    db[t] = "Public malware feed"
        except OSError:
            pass
        try:
            for line in self.hash_file.read_text("utf-8", "ignore").splitlines():
                parts = line.strip().split(None, 1)
                if parts and re.fullmatch(r"[0-9a-fA-F]{64}", parts[0]):
                    db[parts[0].lower()] = parts[1] if len(parts) > 1 else "Imported hash list"
        except OSError:
            pass
        try:
            db.update(self.intel.load_all()["hashes"])
        except Exception:
            pass
        self.hashdb = db
        return len(db)

    def update_hash_feeds(self):
        """Download the configured public SHA-256 feeds (HTTPS). Returns (new_hashes, total_in_feed_file)."""
        found, errors = set(), []
        for url in self.cfg.get("hash_feeds") or []:
            try:
                found |= fetch_hash_feed(url)
            except Exception as e:
                errors.append(f"{url}: {e}")
        if not found:
            raise PackError("; ".join(errors) or "No feeds are configured")
        before = len(self.hashdb)
        atomic_write(self.feed_file, "\n".join(sorted(found)) + "\n")
        self.cfg.set("last_feed_update", time.time())
        self.reload_hashes()
        return len(self.hashdb) - before, len(found)

    def install_pack(self, path):
        info = self.intel.install(path)
        self.reload_hashes()
        self.reload_rules()
        return info

    def import_hashes(self, src: str) -> int:
        added = 0
        existing = set(self.hashdb)
        lines = []
        for line in Path(src).read_text("utf-8", "ignore").splitlines():
            parts = line.strip().split(None, 1)
            if parts and re.fullmatch(r"[0-9a-fA-F]{64}", parts[0]) and parts[0].lower() not in existing:
                lines.append(line.strip())
                existing.add(parts[0].lower())
                added += 1
        if lines:
            with open(self.hash_file, "a", encoding="utf-8") as f:
                f.write("\n".join(lines) + "\n")
        self.reload_hashes()
        return added

    def is_excluded(self, path: str) -> bool:
        p = os.path.abspath(path)
        return any(p == e or p.startswith(e + os.sep) for e in self.exclude)

    def wants(self, path, st, risky_only):
        ext = os.path.splitext(path)[1].lower()
        if ext in MEDIA_EXTS:
            return False
        if risky_only:
            return ext in SCAN_EXTS or (not ext and not IS_WIN and bool(st.st_mode & 0o111))
        return True

    def _read(self, path, size):
        h = hashlib.sha256()
        with open(path, "rb") as f:
            if size <= FULL_READ:
                data = f.read()
                h.update(data)
                return h.hexdigest(), data, b""
            head = f.read(EDGE)
            h.update(head)
            while True:
                chunk = f.read(1024 * 1024)
                if not chunk:
                    break
                h.update(chunk)
            f.seek(max(size - EDGE, 0))
            return h.hexdigest(), head, f.read(EDGE)

    def scan_file(self, path, cloud=None) -> ScanResult:
        path = str(path)
        try:
            st = os.stat(path)
        except OSError as e:
            return ScanResult(path, ERROR, 0, [f"Cannot access file: {e.strerror}"])
        if not stat.S_ISREG(st.st_mode):
            return ScanResult(path, SKIPPED, 0, ["Not a regular file"])
        if st.st_size == 0:
            return ScanResult(path, CLEAN, 0, [], "", 0)
        if st.st_size > MAX_FILE:
            return ScanResult(path, SKIPPED, 0, ["Larger than 200 MB"], "", st.st_size)
        try:
            sha, head, tail = self._read(path, st.st_size)
        except OSError as e:
            return ScanResult(path, ERROR, 0, [f"Cannot read file: {e.strerror}"])
        with self.lock:
            self.session["files"] += 1
        if sha in self.own_hashes:
            return ScanResult(path, CLEAN, 0, ["Green Rook program file (identical to the shipped copy)"], sha, st.st_size)
        if self.allowed(sha):
            return ScanResult(path, CLEAN, 0, ["Allowed by user"], sha, st.st_size)
        f = Findings()
        if sha in self.hashdb:
            f.add(100, f"Known malware hash: {self.hashdb[sha]}", confirmed=True)
        name = os.path.basename(path)
        self._name_checks(name, f)
        self._analyze(name, head, tail, st.st_size, f, 0)
        use_cloud = self.cfg.get("cloud_lookup") if cloud is None else cloud
        if use_cloud and f.score < MAL_THRESHOLD and self._cloud_eligible(name, head, f, st.st_size):
            if self.cloud.check(sha) is True:
                f.add(100, "Known malware according to the Team Cymru Malware Hash Registry (cloud lookup)", confirmed=True)
        score = min(f.score, 100)
        verdict = MALICIOUS if score >= MAL_THRESHOLD else SUSPICIOUS if score >= SUS_THRESHOLD else CLEAN
        if verdict != CLEAN and not f.confirmed:
            note = self.trust_note(path)
            if note:                             # genuine, signed software (or an OS file we cannot verify): guesses are not shown
                with self.lock:
                    self.session["trusted"] = self.session.get("trusted", 0) + 1
                return ScanResult(path, CLEAN, 0, [note] + [f"(ignored) {r}" for r in f.reasons[:5]], sha, st.st_size)
        if verdict != CLEAN:
            with self.lock:
                self.session["threats"] += 1
        return ScanResult(path, verdict, score, f.reasons, sha, st.st_size, f.confirmed)

    def trust_note(self, path) -> str:
        """Why a guess about this file must NOT be reported ('' = report it). Hard evidence never comes through here."""
        if self.cfg.get("trust_signed") is False:
            return ""
        status, how = gr_trust.verify(path)
        if status == gr_trust.TRUSTED:
            return f"Genuine software - {how}. Guesses are not reported for signed files; only known-malware fingerprints are."
        if status == gr_trust.UNKNOWN and system_protected(path):
            return ("Operating-system file whose signature cannot be checked on this system. "
                    "Only known-malware fingerprints are reported in system folders, never guesses.")
        return ""

    @staticmethod
    def _cloud_eligible(name, head, f, size):
        if size > 100 * 1024 * 1024:
            return False
        ext = os.path.splitext(name)[1].lower()
        if f.meta.get("pe"):
            return not f.meta.get("signed")
        return head[:4] == b"\x7fELF" or ext in {".ps1", ".vbs", ".js", ".bat", ".cmd", ".hta", ".jar", ".msi", ".scr", ".sh", ".apk"}

    # -- heuristics ----------------------------------------------------------
    def _name_checks(self, name, f):
        if name.lower() == "autorun.inf":
            f.add(35, "autorun.inf can launch a program automatically when a drive is plugged in")
        if "\u202e" in name:
            f.add(40, "Filename uses right-to-left override to disguise its extension")
        if DOUBLE_EXT.search(name):
            f.add(40, "Double extension disguises an executable as a document/media file")

    def _analyze(self, name, head, tail, size, f, depth):
        ext = os.path.splitext(name)[1].lower()
        if depth == 0 and head[:2] == b"PK" and not tail and self.own_hashes and self._zip_all_own(head):
            return                                       # an archive made only of Green Rook's own files
        low = head.lower() + (b"\n" + tail.lower() if tail else b"")
        hits = AC.search(low)
        is_bin = head[:2] == b"MZ" or head[:4] == b"\x7fELF"
        weak = []
        for n in sorted(hits):
            if is_bin and NAME_TO_WEIGHT[n] <= WEAK_IN_BINARY:
                weak.append(n)                  # a compiled program merely *containing* such a word proves very little
                continue
            f.add(NAME_TO_WEIGHT[n], n, confirmed=NAME_TO_WEIGHT[n] >= 100)
        if weak:
            f.add(min(sum(NAME_TO_WEIGHT[n] for n in weak), WEAK_CAP),
                  "Common strings that also appear in normal programs: " + ", ".join(weak[:6]) + ("\u2026" if len(weak) > 6 else ""))
        if self.custom_ac:
            for n in sorted(self.custom_ac.search(low)):
                w = self.custom_w.get(n, 30)
                f.add(w, n, confirmed=w >= MAL_THRESHOLD)   # a rule you wrote yourself with a high weight is deliberate
        if {"API: remote thread creation", "API: remote memory write", "API: remote memory allocation"} <= hits:
            f.add(25, "Process-injection API combination")
        if {"API: input hooking (keylogging)", "API: key-state polling (keylogging)"} <= hits:
            f.add(20, "Keylogger API combination")
        if {"Script automates Outlook", "Script reads the Outlook address book"} <= hits:
            f.add(25, "Mass-mailer worm combination: drives Outlook and reads the address book (Melissa / ILOVEYOU style)")
            if ext in {".vbs", ".vbe", ".js", ".jse", ".wsf"} and {"Windows script host shell", "Script writes to the registry"} <= hits:
                f.add(15, "Script worm: registry persistence plus mass-mailing")
        if head[:2] == b"MZ":
            self._pe(head, f)
        elif head[:4] == b"\x7fELF":
            if b"upx!" in head[:8192] + tail:
                f.add(15, "ELF binary packed with UPX")
        if ext in {".ps1", ".js", ".vbs", ".bat", ".cmd", ".hta", ".sh", ".py", ".jse", ".vbe"} and len(head) > 10_000:
            avg_line = len(head) / (head.count(b"\n") + 1)
            if avg_line > 2000 and entropy(head[:200_000]) > 5.3:
                f.add(20, "Heavily obfuscated script (very long, high-entropy lines)")
        if ext in {".docm", ".xlsm", ".pptm", ".dotm", ".xlam"}:
            f.add(5, "Macro-enabled Office document")
        if gr_office.is_ole(head) and not tail:
            self._ole(name, head, f, ext, hits)
        if head[:2] == b"PK" and not tail and depth == 0:
            self._zip(head, f, ext)

    def _zip_all_own(self, data) -> bool:
        try:
            zf = zipfile.ZipFile(io.BytesIO(data))
            members = [zi for zi in zf.infolist()[:400] if not zi.is_dir()]
            return bool(members) and all(zi.file_size <= 10_000_000 and hashlib.sha256(zf.read(zi)).hexdigest() in self.own_hashes for zi in members)
        except Exception:
            return False

    def _ole(self, name, data, f, ext, seen=()):
        """Legacy Office / vbaProject.bin: decompress the VBA source and judge what the macro does."""
        mods = gr_office.vba_modules(data)
        if mods:
            f.meta["macros"] = True
            for w, why, conf in gr_office.analyze_macros(mods, ext):
                f.add(w, why, confirmed=conf)
            text = "\n".join(src for _, src in mods).lower().encode("latin-1", "ignore")
            for n in sorted(AC.search(text)):          # the normal signatures, now applied to the *readable* macro code
                if NAME_TO_WEIGHT[n] < 100 and n not in seen:     # don't count a signature twice
                    f.add(NAME_TO_WEIGHT[n], f"Inside macro: {n}")
            if ext in {".docx", ".xlsx", ".pptx"}:
                f.add(20, "Macro project inside a file whose extension says it has no macros")
        elif gr_office.has_vba_markers(data):
            f.meta["macros"] = True
            f.add(8, "Contains a VBA macro project that could not be read (damaged or protected)")
            if ext in {".docx", ".xlsx", ".pptx"}:
                f.add(20, "Macro project inside a file whose extension says it has no macros")

    def _pe(self, d, f):
        f.meta["pe"] = True
        try:
            if len(d) < 0x40:
                return
            pe = struct.unpack_from("<I", d, 0x3C)[0]
            if pe + 24 > len(d) or d[pe:pe + 4] != b"PE\0\0":
                f.add(10, "Malformed PE header")
                return
            nsec, = struct.unpack_from("<H", d, pe + 6)
            optsz, = struct.unpack_from("<H", d, pe + 20)
            opt = pe + 24
            magic, = struct.unpack_from("<H", d, opt)
            entry, = struct.unpack_from("<I", d, opt + 16)
            dd = opt + (112 if magic == 0x20B else 96)
            sec_table = opt + optsz
            secs = []
            for i in range(min(nsec, 96)):
                o = sec_table + i * 40
                if o + 40 > len(d):
                    break
                sname = d[o:o + 8].rstrip(b"\0").decode("latin-1").lower()
                vsize, vaddr, rsize, rptr = struct.unpack_from("<IIII", d, o + 8)
                chars, = struct.unpack_from("<I", d, o + 36)
                secs.append((sname, vsize, vaddr, rsize, rptr, chars))
            sig_size = struct.unpack_from("<I", d, dd + 4 * 8 + 4)[0] if dd + 40 <= len(d) else 0
            f.meta["signed"] = bool(sig_size)
            rwx = packer = hi_ent = False
            entry_sec = None
            for sname, vsize, vaddr, rsize, rptr, chars in secs:
                ex, wr = bool(chars & 0x20000000), bool(chars & 0x80000000)
                if ex and wr:
                    rwx = True
                if sname in PACKER_SECTIONS:
                    packer = True
                if ex and rsize and rptr + rsize <= len(d) and rsize > 1024:
                    if entropy(d[rptr:rptr + min(rsize, 400_000)]) > 7.2:
                        hi_ent = True
                if vaddr <= entry < vaddr + max(vsize, rsize):
                    entry_sec = sname
            if rwx:
                f.add(15, "Section is both writable and executable (RWX)")
            if packer:
                f.add(15, "Known packer/protector section names")
            if hi_ent:
                f.add(20, "Executable section has very high entropy (packed or encrypted)")
            if secs and entry_sec is None and entry:
                f.add(15, "Entry point lies outside every section")
            if secs and entry_sec == secs[-1][0] and len(secs) > 2:
                f.add(8, "Entry point is in the last section")
            if not sig_size and (packer or hi_ent):
                f.add(5, "Packed and not digitally signed")
        except (struct.error, IndexError):
            f.add(10, "Corrupt PE structure")

    def _zip(self, data, f, outer_ext=""):
        try:
            zf = zipfile.ZipFile(io.BytesIO(data))
        except Exception:
            return
        total, best, enc_exec = 0, None, False
        for zi in zf.infolist()[:300]:
            if zi.is_dir():
                continue
            base = os.path.basename(zi.filename)
            ext = os.path.splitext(base)[1].lower()
            if base.lower() == "vbaproject.bin" and outer_ext in {".docx", ".xlsx", ".pptx"}:
                f.add(20, "Macro project hidden inside a file whose extension says it has no macros")
            sub = Findings()
            self._name_checks(base, sub)
            if zi.flag_bits & 1:
                if ext in EXEC_EXTS:
                    enc_exec = True
            elif 0 < zi.file_size <= 10 * 1024 * 1024 and total < 100 * 1024 * 1024:
                try:
                    content = zf.read(zi)
                    total += len(content)
                    sha = hashlib.sha256(content).hexdigest()
                    if sha in self.own_hashes:
                        continue                                     # a Green Rook file inside a zip of Green Rook
                    if sha in self.hashdb:
                        sub.add(100, f"Known malware hash: {self.hashdb[sha]}", confirmed=True)
                    self._analyze(base, content, b"", len(content), sub, 1)
                except Exception:
                    pass
            if sub.score >= 20 and (best is None or sub.score > best[0]):
                best = (sub.score, zi.filename, sub.reasons, sub.confirmed)
        if enc_exec:
            f.add(15, "Password-protected archive containing an executable")
        if best:
            f.add(min(best[0], 100), f"Inside archive: {best[1]} -> {'; '.join(best[2][:2])}", confirmed=best[3])


# --------------------------------------------------------------------------- quarantine
class Vault:
    def __init__(self, folder: Path, cfg: Config, bus: EventBus):
        self.dir = folder / "quarantine"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.index_path = self.dir / "index.json"
        self.key_path = folder / "vault.key"
        self.cfg, self.bus = cfg, bus
        self.lock = threading.RLock()
        if not self.key_path.exists():
            self.key_path.write_bytes(secrets.token_bytes(32))
            try:
                os.chmod(self.key_path, 0o600)
            except OSError:
                pass
        self.key = self.key_path.read_bytes()
        try:
            self.index = json.loads(self.index_path.read_text("utf-8"))
        except FileNotFoundError:
            self.index = {}
        except Exception:
            # Damaged index: keep a copy for forensics and carry on. The encrypted blobs stay untouched on disk.
            self.index = {}
            try:
                self.index_path.replace(self.index_path.with_name("index.corrupt.json"))
            except OSError:
                pass
            self.bus.emit("ERROR", "Quarantine", "Vault index was damaged; a copy was kept as index.corrupt.json")

    def _save(self):
        atomic_write(self.index_path, json.dumps(self.index, indent=1))

    # AES-256-GCM when `cryptography` is available, otherwise HMAC-SHA256 CTR + MAC.
    def encrypt(self, data: bytes) -> bytes:
        if AESGCM:
            nonce = secrets.token_bytes(12)
            return b"SGQ1" + nonce + AESGCM(self.key).encrypt(nonce, data, None)
        nonce = secrets.token_bytes(16)
        ct = self._ctr(nonce, data)
        tag = hmac.new(hashlib.sha256(self.key + b"mac").digest(), nonce + ct, hashlib.sha256).digest()
        return b"SGQ0" + nonce + tag + ct

    def decrypt(self, blob: bytes) -> bytes:
        if blob[:4] == b"SGQ1":
            if not AESGCM:
                raise RuntimeError("Install the 'cryptography' package to restore this file.")
            return AESGCM(self.key).decrypt(blob[4:16], blob[16:], None)
        if blob[:4] == b"SGQ0":
            nonce, tag, ct = blob[4:20], blob[20:52], blob[52:]
            good = hmac.new(hashlib.sha256(self.key + b"mac").digest(), nonce + ct, hashlib.sha256).digest()
            if not hmac.compare_digest(tag, good):
                raise ValueError("Quarantine file failed integrity check")
            return self._ctr(nonce, ct)
        raise ValueError("Unknown quarantine format")

    def _ctr(self, nonce, data):
        out = bytearray(len(data))
        for i in range(0, len(data), 32):
            ks = hmac.new(self.key, nonce + (i // 32).to_bytes(8, "big"), hashlib.sha256).digest()
            blk = data[i:i + 32]
            out[i:i + len(blk)] = bytes(a ^ b for a, b in zip(blk, ks))
        return bytes(out)

    def quarantine(self, res: ScanResult) -> str:
        if not res.confirmed and (system_protected(res.path) or gr_trust.is_trusted(res.path)):
            raise PermissionError("Green Rook will not remove this: it is a Windows / system file or a genuine signed program, and there is "
                                  "no hard evidence against it (only a guess). Removing such files can break the PC.")
        with self.lock:
            data, err = None, None
            for attempt in range(5):                 # antivirus / indexer may hold a new file for a moment
                try:
                    data = Path(res.path).read_bytes()
                    break
                except FileNotFoundError:
                    raise
                except OSError as e:
                    err = e
                    time.sleep(0.4)
            if data is None:
                raise OSError(explain_block(res.path, err))
            qid = uuid.uuid4().hex[:12]
            blob_path = self.dir / f"{qid}.sgq"
            atomic_write(blob_path, self.encrypt(data), binary=True)
            ok, pending, msg = force_remove(res.path)
            if not ok:
                blob_path.unlink(missing_ok=True)       # nothing was changed; the file is still where it was
                raise OSError(msg)
            if not res.sha256:
                res.sha256 = hashlib.sha256(data).hexdigest()
            self.index[qid] = {"original": res.path, "sha256": res.sha256, "verdict": res.verdict,
                               "score": res.score, "reasons": res.reasons[:6], "size": len(data),
                               "time": time.strftime("%Y-%m-%d %H:%M:%S")}
            if pending:
                self.index[qid]["note"] = "original will be removed at next restart"
            self._save()
        self.bus.emit("THREAT", "Quarantine", f"Isolated {res.path} ({res.verdict}, score {res.score})"
                      + (" - the original is locked and will be removed at the next restart" if pending else ""))
        return qid

    def restore(self, qid) -> str:
        with self.lock:
            meta = self.index[qid]
            data = self.decrypt((self.dir / f"{qid}.sgq").read_bytes())
            want = meta.get("sha256")
            if want and hashlib.sha256(data).hexdigest() != want:
                raise ValueError("Restored data does not match the original fingerprint - the vault item is damaged")
            dest = Path(meta["original"])
            n = 0
            while dest.exists():            # never overwrite an existing file
                n += 1
                dest = Path(meta["original"]).with_name(Path(meta["original"]).name + (".restored" if n == 1 else f".restored{n}"))
            dest.parent.mkdir(parents=True, exist_ok=True)
            atomic_write(dest, data, binary=True)
            self.cfg.append_unique("allow_hashes", meta["sha256"])
            (self.dir / f"{qid}.sgq").unlink(missing_ok=True)
            del self.index[qid]
            self._save()
        self.bus.emit("INFO", "Quarantine", f"Restored {dest}")
        return str(dest)

    def delete(self, qid):
        with self.lock:
            (self.dir / f"{qid}.sgq").unlink(missing_ok=True)
            self.index.pop(qid, None)
            self._save()
        self.bus.emit("INFO", "Quarantine", f"Permanently deleted item {qid}")

    def items(self):
        with self.lock:
            return sorted(self.index.items(), key=lambda kv: kv[1]["time"], reverse=True)


# --------------------------------------------------------------------------- web analysis
BRANDS = {
    "paypal": {"paypal.com", "paypal.me"}, "google": {"google.com", "google.co.in", "gmail.com", "goo.gl", "googleapis.com"},
    "microsoft": {"microsoft.com", "live.com", "office.com", "outlook.com", "microsoftonline.com", "windows.com", "azure.com", "bing.com", "msn.com"},
    "apple": {"apple.com", "icloud.com"}, "amazon": {"amazon.com", "amazon.in", "amazon.co.uk", "amazon.de", "amazonaws.com", "amazon.co.jp"},
    "netflix": {"netflix.com"}, "facebook": {"facebook.com", "fb.com"}, "instagram": {"instagram.com"},
    "whatsapp": {"whatsapp.com", "whatsapp.net"}, "binance": {"binance.com"}, "coinbase": {"coinbase.com"},
    "metamask": {"metamask.io"}, "dropbox": {"dropbox.com"}, "linkedin": {"linkedin.com"},
    "github": {"github.com", "github.io", "githubusercontent.com"}, "steam": {"steampowered.com", "steamcommunity.com"},
    "discord": {"discord.com", "discord.gg"}, "paytm": {"paytm.com"}, "phonepe": {"phonepe.com"},
    "flipkart": {"flipkart.com"}, "irctc": {"irctc.co.in"}, "sbi": {"sbi.co.in", "onlinesbi.sbi", "sbi.bank.in"},
    "hdfcbank": {"hdfcbank.com"}, "icicibank": {"icicibank.com"}, "telegram": {"telegram.org", "t.me"},
    "yahoo": {"yahoo.com"}, "adobe": {"adobe.com"},
}
LONG_BRANDS = {b for b in BRANDS if len(b) >= 6}
SUS_TLDS = {"zip", "mov", "tk", "ml", "ga", "cf", "gq", "xyz", "top", "click", "work", "support", "rest", "country",
            "kim", "loan", "icu", "cyou", "buzz", "monster", "sbs", "cfd", "lol", "men"}
SHORTENERS = {"bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "cutt.ly", "rb.gy", "shorturl.at", "tiny.cc"}
KEYWORDS = ["login", "signin", "verify", "secure", "account", "update", "wallet", "suspend", "confirm", "password",
            "invoice", "otp", "kyc", "prize", "giveaway", "claim", "refund", "recover", "unlock", "billing"]
TWO_LEVEL = {"co.uk", "org.uk", "ac.uk", "gov.uk", "com.au", "co.in", "org.in", "gov.in", "net.in", "ac.in", "co.jp",
             "com.br", "co.za", "com.cn", "co.nz", "com.sg", "bank.in"}
LEET = str.maketrans({"0": "o", "1": "l", "3": "e", "4": "a", "5": "s", "$": "s", "@": "a"})


def registrable(host: str) -> str:
    parts = host.split(".")
    if len(parts) >= 3 and ".".join(parts[-2:]) in TWO_LEVEL:
        return ".".join(parts[-3:])
    return ".".join(parts[-2:])


def lev(a, b):
    if abs(len(a) - len(b)) > 2:
        return 3
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


class WebGuard:
    def __init__(self, intel=None):
        self.block_file = data_dir() / "blocklist.txt"
        self.intel = intel
        self.blocklist = set()
        self.reload()

    def reload(self):
        try:
            self.blocklist = {l.strip().lower() for l in self.block_file.read_text("utf-8", "ignore").splitlines()
                              if l.strip() and not l.startswith("#")}
        except OSError:
            self.blocklist = set()
        if self.intel:
            try:
                agg = self.intel.load_all()
                self.blocklist |= agg["domains"] | agg["ips"]
            except Exception:
                pass
        return len(self.blocklist)

    def import_list(self, src):
        new = {l.strip().lower() for l in Path(src).read_text("utf-8", "ignore").splitlines()
               if l.strip() and not l.startswith("#")}
        try:
            mine = {l.strip().lower() for l in self.block_file.read_text("utf-8", "ignore").splitlines() if l.strip()}
        except OSError:
            mine = set()
        before = len(self.blocklist)
        atomic_write(self.block_file, "\n".join(sorted(mine | new)) + "\n")
        self.reload()
        return len(self.blocklist) - before

    # -- OS-level blocking through the hosts file (needs administrator rights) ---------
    HOSTS_BEGIN, HOSTS_END = "# >>> GREEN ROOK BLOCKLIST >>>", "# <<< GREEN ROOK BLOCKLIST <<<"

    @staticmethod
    def hosts_path() -> Path:
        return Path(os.environ.get("SystemRoot", "C:\\Windows")) / "System32" / "drivers" / "etc" / "hosts" if IS_WIN else Path("/etc/hosts")

    def apply_hosts(self, enable=True):
        p = self.hosts_path()
        text = p.read_text("utf-8", "ignore")
        bak = data_dir() / "hosts.backup"
        if not bak.exists() and self.HOSTS_BEGIN not in text:   # keep the first pristine copy
            try:
                bak.write_text(text, "utf-8")
            except OSError:
                pass
        text = re.sub(re.escape(self.HOSTS_BEGIN) + r".*?" + re.escape(self.HOSTS_END) + r"\r?\n?", "", text, flags=re.S)
        n = 0
        if enable:
            doms = sorted(d for d in self.blocklist if re.fullmatch(r"[a-z0-9.-]+\.[a-z]{2,}", d))[:15000]
            n = len(doms)
            text = text.rstrip() + "\n" + self.HOSTS_BEGIN + "\n" + "\n".join(f"0.0.0.0 {d}" for d in doms) + "\n" + self.HOSTS_END + "\n"
        p.write_text(text, "utf-8")
        return n

    MIRRORS = ["https://curben.gitlab.io/malware-filter/urlhaus-filter-hosts-online.txt",
               "https://cdn.jsdelivr.net/gh/curbengh/urlhaus-filter/urlhaus-filter-hosts-online.txt"]

    def update_online(self):
        last = None
        for url in self.MIRRORS:
            try:
                req = urllib.request.Request(url, headers={"User-Agent": f"{APP_NAME}/{VERSION}"})
                with urllib.request.urlopen(req, timeout=25) as r:
                    raw = r.read(25 * 1024 * 1024).decode("utf-8", "ignore")
                doms = set()
                for line in raw.splitlines():
                    line = line.split("#", 1)[0].strip()
                    if not line:
                        continue
                    d = line.split()[-1].lower()
                    if d not in ("localhost", "0.0.0.0") and re.fullmatch(r"[a-z0-9._-]+\.[a-z0-9-]{2,}", d):
                        doms.add(d)
                before = len(self.blocklist)
                try:
                    mine = {l.strip().lower() for l in self.block_file.read_text("utf-8", "ignore").splitlines() if l.strip()}
                except OSError:
                    mine = set()
                atomic_write(self.block_file, "\n".join(sorted(doms | mine)) + "\n")
                self.reload()
                return len(self.blocklist) - before, len(self.blocklist)
            except Exception as e:
                last = e
        raise RuntimeError(f"Could not download the list ({last})")

    def analyze(self, url: str):
        url = url.strip()
        raw = url if "://" in url else "http://" + url
        try:
            u = urlparse(raw)
            host = (u.hostname or "").lower().rstrip(".")
        except ValueError:
            return 0, ["Could not parse URL"], "Invalid"
        if not host:
            return 0, ["No host name found"], "Invalid"
        score, why = 0, []

        def add(n, text):
            nonlocal score
            score += n
            why.append(f"{text} (+{n})")

        reg = registrable(host)
        if any(host == b or host.endswith("." + b) for b in self.blocklist):
            add(100, "Domain is on your blocklist")
        if re.fullmatch(r"(\d{1,3}\.){3}\d{1,3}", host) or re.fullmatch(r"0x[0-9a-f]+|\d{8,10}", host):
            add(30, "Uses a raw IP address instead of a domain name")
        if "@" in u.netloc:
            add(30, "Contains '@' - the real destination is hidden after it")
        if "xn--" in host:
            add(25, "Punycode domain (can imitate other alphabets)")
        tld = host.rsplit(".", 1)[-1]
        if tld in SUS_TLDS:
            add(15, f"Domain ending '.{tld}' is heavily abused for scams")
        labels = host.split(".")
        if len(labels) > 4:
            add(10, "Unusually many subdomains")
        if host.count("-") >= 3:
            add(10, "Many hyphens in domain")
        if len(url) > 100:
            add(8, "Very long URL")
        if reg in SHORTENERS:
            add(10, "Link shortener hides the real destination")
        if u.scheme == "http" and any(k in (u.path + (u.query or "")).lower() for k in ("login", "signin", "password", "verify")):
            add(15, "Sign-in page over unencrypted HTTP")
        kw = [k for k in KEYWORDS if k in host or k in u.path.lower()]
        if kw:
            add(min(8 * len(kw), 24), "Pressure/credential keywords: " + ", ".join(kw[:4]))
        main = labels[-2] if len(labels) >= 2 else labels[0]
        if len(main) > 12 and entropy(main.encode()) > 3.6 and not main.isalpha():
            add(10, "Random-looking domain name")
        tokens = [t for lab in labels[:-1] for t in re.split(r"-", lab) if t]
        for brand, official in BRANDS.items():
            if reg in official:
                continue
            hit = False
            for t in tokens:
                tn = t.translate(LEET).replace("rn", "m").replace("vv", "w")
                if t == brand or tn == brand or (brand in LONG_BRANDS and (brand in t or brand in tn)):
                    hit = True
                elif len(brand) >= 5 and len(t) >= 5 and lev(tn, brand) == 1:
                    hit = True
                if hit:
                    break
            if hit:
                add(45, f"Looks like it is imitating {brand.title()} (real site: {sorted(official)[0]})")
                break
        label = "Dangerous" if score >= 60 else "Suspicious" if score >= 30 else "Looks safe"
        return min(score, 100), why or ["No red flags found - this is not a guarantee of safety"], label


# --------------------------------------------------------------------------- guard services
class Service(threading.Thread):
    interval = 2.0

    def __init__(self, name, enabled):
        super().__init__(daemon=True, name=name)
        self.enabled = enabled
        self.alive = True

    def run(self):
        while self.alive:
            if self.enabled:
                try:
                    self.tick()
                except Exception as e:  # never let a guard die
                    self.on_error(e)
            time.sleep(self.interval)

    def tick(self):
        pass

    def on_error(self, e):
        pass

    def set_enabled(self, v):
        self.enabled = bool(v)
        self.reset()

    def reset(self):
        pass


def walk_limited(root, depth=3, cap=20000):
    out = []
    stack = [(root, 0)]
    while stack and len(out) < cap:
        d, lvl = stack.pop()
        try:
            with os.scandir(d) as it:
                for e in it:
                    try:
                        if e.is_symlink():
                            continue
                        if e.is_dir(follow_symlinks=False):
                            if lvl < depth:
                                stack.append((e.path, lvl + 1))
                        elif e.is_file(follow_symlinks=False):
                            st = e.stat()
                            # Include change time and inode as well as size/mtime. Fast same-size rewrites can
                            # preserve a coarse mtime on some filesystems; those are precisely what ransomware does.
                            out.append((e.path, (st.st_mtime_ns, getattr(st, "st_ctime_ns", 0), st.st_size, getattr(st, "st_ino", 0))))
                    except OSError:
                        continue
        except OSError:
            continue
    return out


def iter_files(engine, targets, risky_only, cancel, limit=None):
    """Yield scannable files below `targets`, skipping pseudo-filesystems and our own folders."""
    n = 0
    for t in targets:
        if os.path.isfile(t):
            yield t
            continue
        for root, dirs, names in os.walk(t, onerror=lambda e: None):
            if cancel.is_set():
                return
            low = root.lower()
            if IS_LINUX and root in ("/proc", "/sys", "/dev", "/run"):
                dirs[:] = []
                continue
            if IS_WIN and any(x in low for x in ("\\winsxs", "\\$recycle.bin", "\\system volume information")):
                dirs[:] = []
                continue
            dirs[:] = [d for d in dirs if not engine.is_excluded(os.path.join(root, d)) and not os.path.islink(os.path.join(root, d))]
            for nm in names:
                p = os.path.join(root, nm)
                try:
                    st = os.lstat(p)
                except OSError:
                    continue
                if stat.S_ISLNK(st.st_mode):
                    continue
                if engine.wants(p, st, risky_only):
                    yield p
                    n += 1
                    if limit and n >= limit:
                        return


class FileGuard(Service):
    """Watches folders; scans new/changed files as soon as they finish being written."""
    interval = 2.5
    SKIP = (".crdownload", ".part", ".partial", ".download", ".tmp", ".opdownload")

    def __init__(self, cfg, engine, vault, broker, bus, enabled):
        super().__init__("FileGuard", enabled)
        self.cfg, self.engine, self.vault, self.broker, self.bus = cfg, engine, vault, broker, bus
        self.slots = threading.BoundedSemaphore(4)     # at most 4 files judged at once; a prompt never freezes the watcher
        self.reset()

    def reset(self):
        self.snap, self.pending, self.baselined = {}, {}, False

    def tick(self):
        current = {}
        for d in self.cfg.get("watch_dirs") or []:
            for p, sig in walk_limited(d):
                current[p] = sig
        if not self.baselined:
            self.snap, self.baselined = current, True
            return
        for p, sig in current.items():
            if self.snap.get(p) == sig:
                continue
            if p.lower().endswith(self.SKIP) or self.engine.is_excluded(p):
                self.snap[p] = sig
                continue
            if self.pending.get(p) == sig:  # unchanged for one full cycle -> download finished
                self.pending.pop(p, None)
                self.snap[p] = sig
                self.dispatch(p)
            else:
                self.pending[p] = sig
        for p in list(self.snap):
            if p not in current:
                del self.snap[p]
        for p in list(self.pending):
            if p not in current:
                del self.pending[p]

    def dispatch(self, path):
        """Judge in a helper thread so that waiting for a person's answer never stops the folder watcher."""
        if not self.slots.acquire(blocking=False):
            self.snap.pop(path, None)       # all helpers busy: try this file again next cycle
            return

        def work():
            try:
                self.handle(path)
            except Exception as e:
                self.bus.emit("ERROR", "Real-time", f"Could not check {path}: {e}")
            finally:
                self.slots.release()
        threading.Thread(target=work, daemon=True, name="FileJudge").start()

    def handle(self, path):
        res = self.engine.scan_file(path)
        if res.verdict == CLEAN or res.verdict in (SKIPPED, ERROR):
            return
        self.bus.emit("THREAT", "Real-time", f"{res.verdict}: {path} (score {res.score}, {res.confidence})")
        if res.auto_safe and self.cfg.get("auto_quarantine"):
            self._quarantine(res)
            self.bus.notify("bad", "Threat blocked", f"{os.path.basename(path)} was quarantined.\n{res.reasons[0] if res.reasons else ''}")
            return
        choice = self.broker.ask(
            key="file:" + path, title="Green Rook - Suspicious file",
            headline=f"{os.path.basename(path)} looks {res.verdict.lower()}",
            details=[("Path", path), ("Risk score", f"{res.score}/100"), ("SHA-256", res.sha256[:32] + "..."),
                     ("Confidence", res.confidence), ("Why", "\n".join(res.reasons[:5]))],
            options=[("block", "Quarantine it", "danger"), ("once", "Allow once", "neutral"), ("always", "Always allow", "neutral")],
            default="block")
        if choice == "always":
            self.cfg.append_unique("allow_hashes", res.sha256)
            self.bus.emit("INFO", "Real-time", f"User allowed {path} permanently")
        elif choice == "once":
            self.bus.emit("INFO", "Real-time", f"User allowed {path} once")
        else:
            self._quarantine(res)

    def _quarantine(self, res):
        try:
            self.vault.quarantine(res)
        except OSError as e:
            self.bus.emit("ERROR", "Quarantine", f"Could not isolate {res.path}: {e}")


OFFICE = {"winword.exe", "excel.exe", "powerpnt.exe", "outlook.exe", "msaccess.exe", "onenote.exe", "acrord32.exe", "soffice.bin"}
SHELLS = {"cmd.exe", "powershell.exe", "pwsh.exe", "wscript.exe", "cscript.exe", "mshta.exe", "regsvr32.exe", "rundll32.exe", "bash", "sh"}
RISKY_DIRS = ["/tmp/", "/var/tmp/", "/dev/shm/", "\\appdata\\local\\temp\\", "\\downloads\\", "/downloads/", "\\temp\\", "\\appdata\\roaming\\"]


class CameraGuard(Service):
    """Alerts the moment an application starts using the webcam and lets you stop it."""
    interval = 1.5

    def __init__(self, cfg, broker, bus, enabled):
        super().__init__("CameraGuard", enabled)
        self.cfg, self.broker, self.bus = cfg, broker, bus
        self.active, self.handled = {}, set()
        self.supported = IS_WIN or IS_LINUX

    def reset(self):
        self.active, self.handled = {}, set()

    def users(self):
        """Return {identity: (display_name, pid_or_None, path)}."""
        out = {}
        if IS_LINUX:
            for pid in filter(str.isdigit, os.listdir("/proc")):
                try:
                    for fd in os.listdir(f"/proc/{pid}/fd"):
                        if os.readlink(f"/proc/{pid}/fd/{fd}").startswith("/dev/video"):
                            try:
                                exe = os.readlink(f"/proc/{pid}/exe")
                            except OSError:
                                exe = ""
                            nm = Path(f"/proc/{pid}/comm").read_text().strip()
                            out[exe or nm] = (nm, int(pid), exe)
                            break
                except OSError:
                    continue
        elif IS_WIN:
            import winreg
            base = r"Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\webcam"

            def scan(path, prefix=""):
                try:
                    k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, path)
                except OSError:
                    return
                i = 0
                while True:
                    try:
                        sub = winreg.EnumKey(k, i)
                    except OSError:
                        break
                    i += 1
                    if sub == "NonPackaged":
                        scan(path + "\\NonPackaged", "np")
                        continue
                    try:
                        sk = winreg.OpenKey(winreg.HKEY_CURRENT_USER, path + "\\" + sub)
                        start = winreg.QueryValueEx(sk, "LastUsedTimeStart")[0]
                        stop = winreg.QueryValueEx(sk, "LastUsedTimeStop")[0]
                    except OSError:
                        continue
                    if start and start > stop:
                        full = sub.replace("#", "\\")
                        out[full] = (os.path.basename(full) if prefix else sub.split("_")[0], None, full if prefix else "")
            scan(base)
        return out

    def tick(self):
        if not self.supported:
            return
        now = self.users()
        for ident in list(self.handled):
            if ident not in now:
                self.handled.discard(ident)
        for ident, (name, pid, path) in now.items():
            if ident in self.handled:
                continue
            self.handled.add(ident)
            if ident in (self.cfg.get("camera_allowed") or []):
                self.bus.emit("INFO", "Camera Guard", f"{name} is using the camera (trusted)")
                continue
            self.bus.emit("WARN", "Camera Guard", f"{name} is using the camera")
            threading.Thread(target=self.ask, args=(ident, name, pid, path), daemon=True).start()

    def ask(self, ident, name, pid, path):
        choice = self.broker.ask(
            key="cam:" + ident, title="Green Rook - Camera in use",
            headline=f"{name} is using your camera",
            details=[("Program", path or name), ("PID", str(pid) if pid else "n/a")],
            options=[("block", "Stop the app", "danger"), ("once", "Allow once", "neutral"), ("always", "Always allow", "neutral")],
            default="block")
        if choice == "always":
            self.cfg.append_unique("camera_allowed", ident)
        elif choice == "block":
            self.stop_app(name, pid, path)

    def stop_app(self, name, pid, path):
        killed = False
        if psutil:
            for p in psutil.process_iter(["pid", "name", "exe"]):
                try:
                    if (pid and p.info["pid"] == pid) or (path and p.info["exe"] and p.info["exe"].lower() == path.lower()) \
                            or (not path and not pid and p.info["name"] and p.info["name"].lower().startswith(name.lower())):
                        p.kill()
                        killed = True
                except Exception:
                    pass
        self.bus.emit("THREAT" if killed else "WARN", "Camera Guard",
                      f"{'Stopped' if killed else 'Could not stop'} {name}")
